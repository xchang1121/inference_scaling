from dataclasses import replace

import pytest

from test_online_is import Native, Facts, request
from inference_scaling.retrieval.cot_guidance import GuidanceConfig, search
from inference_scaling.retrieval.smart_online_is import (
    SmartOnlineLedger, boundary, clean_question, overlaps, retrieve_anchored,
)


def make(variant, stop=600, eos=False):
    b, f = Native(stop=stop, eos=eos), Facts()
    cfg = replace(GuidanceConfig(), thinking_tokens=640, answer_tokens=1024, context_tokens=8192)
    ledger = SmartOnlineLedger(b, b, (1, 2), (901,), 17, cfg, question='Original issue', facts=f,
                               variant=variant, mode='relevant')
    return b, f, ledger


@pytest.mark.parametrize('variant', ['resume', 'anchored', 'boundary', 'adaptive'])
def test_each_variant_preserves_tokens_branch_context_and_native_eos(variant):
    b, _, ledger = make(variant)
    sample, = ledger.sample_batch([request(ledger, count=640)])
    assert len(sample.token_ids) == 601 and sample.token_ids[-1] == 901
    assert ledger.work == 601 and len(ledger.statistics(sample.token_ids)['sc']) == 600
    physical, events = ledger.materialize(sample.token_ids, pending=False)
    assert len(physical) == 2+601+sum(len(ledger.events[i]['injected_ids']) for i in events)
    assert len(events) <= 2
    assert b.requests[0].prefix == (1, 2)
    for call in ledger.native_calls:
        expected, ids = ledger.materialize(call['logical_prefix_ids'][2:])
        assert tuple(call['prefix_ids']) == expected and call['event_ids'] == ids
    for e in ledger.events:
        assert len(e['packet']['ids']) == 256
        assert e['injected_ids'][256:] == list(ledger.resume_ids)


def test_short_terminal_prefix_never_retrieves_or_retries():
    _, f, ledger = make('adaptive', stop=40, eos=True)
    sample, = ledger.sample_batch([request(ledger, count=640)])
    assert sample.token_ids[-1] == 900 and ledger.work == 41
    assert not ledger.events and not f.queries


def test_adaptive_uses_only_measured_prefix_probabilities():
    _, _, ledger = make('adaptive')
    # Native supplies logprob -1, so uncertainty gate opens on late fallback.
    sample, = ledger.sample_batch([request(ledger, count=640)])
    _, ids = ledger.materialize(sample.token_ids)
    assert [ledger.events[i]['position'] for i in ids] == [160, 544]
    late = [d for d in ledger.decisions if d['surprisal_last32'] is not None]
    assert all(d['surprisal_last32'] == 1. for d in late)


def test_sibling_isolation_and_final_replay_do_not_retrieve_again():
    _, facts, ledger = make('anchored')
    samples = ledger.sample_batch([request(ledger, count=640, seed=1, name='a'),
                                   request(ledger, count=640, seed=2, name='b')])
    count = len(facts.queries)
    paths = [ledger.materialize(s.token_ids)[1] for s in samples]
    assert set(paths[0]).isdisjoint(paths[1])
    assert len(facts.queries) == count


def test_original_is_configuration_and_first_block_stay_unchanged():
    _, _, ledger = make('resume', stop=140)
    _, audit = search(ledger, 'is_block_sc')
    assert audit['steps'][0]['generated_length_before'] == 0
    assert audit['config']['candidate_count'] == 3
    assert audit['config']['rollout_count'] == 2
    assert audit['config']['block_size'] == 512
    assert audit['config']['reward_temperature'] == .25


def test_question_anchor_boundary_and_overlap_rules():
    assert clean_question('problem\n\nIn the final answer, please answer') == 'problem'
    assert boundary('Complete sentence.\n') and boundary('Complete step\n')
    assert not boundary('unfinished wor')
    assert overlaps('x@0-192', 'x@64-256')
    assert not overlaps('x@0-192', 'x@96-288')
    assert not overlaps('x@0-192', 'y@0-192')


def test_rank_fusion_prioritizes_question_without_dropping_branch_query():
    f = Facts()
    payload, log = retrieve_anchored(f, 'Original issue', 'a speculative different topic', set())
    assert len(log['searches']) == 2
    assert log['queries'][0] == 'Original issue'
    assert 'speculative' in log['queries'][1]
    assert payload['id'] == log['rank_lists'][0][0]
