#!/usr/bin/env bash
set -eu
export PYTHONPATH="/deployment/online-injection-scaling-20261109-a3/source/src:/deployment/online-injection-scaling-20261109-a3/source/scripts:${PYTHONPATH:-}"
exec python3 /deployment/online-injection-scaling-20261109-a3/source/scripts/benchmark_retrieval_scaling.py --settings /deployment/online-injection-scaling-20261109-a3/settings-a3.json --prepared /results/prepared-formal-v2.json --corpus /deployment/online-injection-scaling-20261109-a3/data/corpus.jsonl --output /results/formal.jsonl
