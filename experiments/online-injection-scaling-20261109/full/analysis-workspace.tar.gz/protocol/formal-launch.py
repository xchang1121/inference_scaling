stage='formal'

from pathlib import Path
import hashlib,json,subprocess,time
root=Path('/data/disk/changxiangyu/agentic_scaling');name='online-injection-scaling-20261109-a3';dep=root/'deployment/ascend'/name;out=root/'results'/name;c='agentic-scaling-changxiangyu-injection-scaling-a3'
status=1;started=time.time()
try:
 frozen=json.loads((dep/(stage.upper()+'-FROZEN.json')).read_text())
 for n,h in {**frozen['source_files'],**frozen['hashes']}.items():assert hashlib.sha256((dep/n).read_bytes()).hexdigest()==h,n
 assert hashlib.sha256((out/frozen['prepared_file']).read_bytes()).hexdigest()==frozen['prepared_sha256']
 assert 'No running processes found in NPU 3' in subprocess.check_output(['/usr/local/bin/npu-smi','info'],text=True)
 subprocess.run(['docker','start',c],check=True,capture_output=True)
 if not (out/'runtime-versions.json').exists():
  code="import importlib.metadata as m,json,platform;print(json.dumps({'python':platform.python_version(),'packages':{p:m.version(p) for p in ['vllm','vllm-ascend','torch','torch-npu','transformers','tokenizers']}}))"
  (out/'runtime-versions.json').write_bytes(subprocess.check_output(['docker','exec',c,'bash','/deployment/env.sh','python3','-c',code]))
 with (out/(stage+'.log')).open('wb') as log:
  result=subprocess.run(['docker','exec',c,'bash','/deployment/env.sh','bash','/deployment/'+name+'/'+stage+'-start.sh'],stdout=log,stderr=subprocess.STDOUT)
 status=result.returncode
finally:
 (out/(stage+'.exit')).write_text(str(status)+'\n')
 subprocess.run(['docker','stop',c],capture_output=True,timeout=45)
 d=json.loads(subprocess.check_output(['docker','inspect',c],text=True))[0]
 (out/(stage+'-finish.json')).write_text(json.dumps({'generation_exit':status,'started':started,'finished':time.time(),'running':d['State']['Running'],'state':d['State'],'image':d['Image'],'devices':d['HostConfig']['Devices']},indent=2)+'\n')
