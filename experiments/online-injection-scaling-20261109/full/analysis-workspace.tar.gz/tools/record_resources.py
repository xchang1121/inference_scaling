"""Deduplicate real execution units; report startup and model work separately."""
from pathlib import Path
import hashlib
import importlib.metadata
import json
import platform

BASE=Path(__file__).resolve().parent
REPO=BASE.parent/'online_injection_20261109/source'
REPORT=BASE.parents[1]/'outputs/online-injection-scaling-20261109'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    stages=[]
    for name in ['smoke','formal']:
        path=BASE/'snapshot'/(name+'.jsonl')
        rows=[json.loads(l) for l in path.read_text(encoding='utf-8').splitlines()]
        units=[r for r in rows if r['kind']=='execution_unit']
        warm=[r for r in rows if r['kind']=='warmup']
        finish=json.loads((BASE/'provenance'/(name+'-finish.json')).read_text(encoding='utf-8'))
        assert finish['generation_exit']==0 and not finish['running'] and not finish['state']['OOMKilled']
        calls=[c for u in units for c in u['calls']]
        unit_seconds=sum(u['seconds'] for u in units)
        warm_seconds=sum(u['seconds'] for u in warm)
        wall=finish['finished']-finish['started']
        stages.append({'stage':name,'raw_sha256':digest(path),'condition_outcomes':sum(r['kind']=='measurement' for r in rows),
            'unique_execution_units':len(units),'model_requests':len(calls),
            'work_tokens':sum(len(c['token_ids']) for c in calls if c['purpose']!='answer'),
            'auxiliary_tokens':sum(len(c['token_ids']) for c in calls if c['purpose'] in {'gap_plan','support_check'}),
            'answer_tokens':sum(len(c['token_ids']) for c in calls if c['purpose']=='answer'),
            'warmup_tokens':sum(len(w['token_ids']) for w in warm),
            'unit_seconds':unit_seconds,'warmup_seconds':warm_seconds,'stage_wall_seconds':wall,
            'setup_teardown_seconds':wall-unit_seconds-warm_seconds,
            'unit_native_padded_dense_pflops':sum(u.get('graph_execution',{}).get('estimated_dense_padded_flops',0) for u in units)/1e15,
            'warmup_native_padded_dense_pflops':sum(u.get('graph_execution',{}).get('estimated_dense_padded_flops',0) for u in warm)/1e15,
            'generation_exit':finish['generation_exit'],'container_base_process_exit':finish['state']['ExitCode'],'oom_killed':finish['state']['OOMKilled']})
    receipt={'stages':stages,'scope':'Actual unique execution units, not duplicated logical real/noise or method views.',
        'device':'A 27.106.124.198 physical NPU3 only, TP1; B CPU mirror only.',
        'limits':'Graph FLOPs are dense-padded estimates, not all-operation hardware counters. Initialization profiling FLOPs uninstrumented. Static packets/index are prepared offline; online dynamic lookup is included in unit wall time.'}
    REPORT.mkdir(parents=True,exist_ok=True)
    (REPORT/'RESOURCE_RECEIPTS.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
    frozen=json.loads((BASE/'provenance/FORMAL-FROZEN.json').read_text(encoding='utf-8'))
    engine=next(r for r in [json.loads(l) for l in (BASE/'snapshot/formal.jsonl').read_text(encoding='utf-8').splitlines()] if r['kind']=='engine')
    metadata={'generation_source_commit':frozen['source_commit'],'generation_files':len(frozen['source_files']),
        'formal_prepared_sha256':digest(BASE/'snapshot/prepared-formal-v2.json'),'formal_raw_sha256':digest(BASE/'snapshot/formal.jsonl'),
        'gold_offline_sha256':digest(BASE/'data/gold.jsonl'),'data_manifest_sha256':digest(BASE/'data/manifest.json'),
        'model_id':engine['model_id'],'parameter_count':engine['parameter_count'],
        'runtime_versions':json.loads((BASE/'snapshot/runtime-versions.json').read_text(encoding='utf-8')),
        'analysis_runtime':{'python':platform.python_version(),'packages':{n:importlib.metadata.version(n) for n in ['numpy','matplotlib','pillow']}},
        'analysis_scripts':{n:digest(REPO/'scripts'/n) for n in ['summarize_retrieval_scaling.py','summarize_flare_gap.py','plot_retrieval_scaling.py','export_retrieval_scaling.py']},
        'gold_runtime_visibility':False,'cpu_tests':51,'generation_changes_after_freeze':False}
    (REPORT/'ANALYSIS_METADATA.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps({'stages':len(stages),'formal_conditions':stages[-1]['condition_outcomes'],'formal_native_pflops':stages[-1]['unit_native_padded_dense_pflops']}))


if __name__=='__main__':
    main()
