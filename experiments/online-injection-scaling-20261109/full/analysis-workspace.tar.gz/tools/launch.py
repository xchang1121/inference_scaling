"""Launch a frozen stage; the host finally block stops only this task's container."""
from pathlib import Path
import argparse
import json
import subprocess
import sys

base=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('stage',choices=['smoke','formal']);a=p.parse_args()
script='stage='+repr(a.stage)+r'''
from pathlib import Path
import hashlib,json,subprocess,time
root=Path('/data/disk/changxiangyu/agentic_scaling');name='online-injection-scaling-20261109-a3'
dep=root/'deployment/ascend'/name;out=root/'results'/name;c='agentic-scaling-changxiangyu-injection-scaling-a3'
assert (out/'prepare.exit').read_text().strip()=='0'
assert not (out/(stage+'.jsonl')).exists() and not (out/(stage+'.exit')).exists()
frozen=json.loads((dep/'PREPARE-PROTOCOL.json').read_text())
for n,h in {**frozen['source_files'],**frozen['hashes']}.items():assert hashlib.sha256((dep/n).read_bytes()).hexdigest()==h,n
assert 'No running processes found in NPU 3' in subprocess.check_output(['/usr/local/bin/npu-smi','info'],text=True)
if stage=='formal':
 assert (out/'smoke.exit').read_text().strip()=='0'
 correction=json.loads((dep/'FORMAL-INPUT-CORRECTION.json').read_text())
 frozen['hashes'].update({n:h for n,h in correction['hashes'].items() if n.startswith('data/')})
 frozen['input_correction']=correction
frozen.update(stage=stage,stage_frozen=time.time(),prepared_file='prepared-'+stage+('-v2' if stage=='formal' else '')+'.json')
frozen['prepared_sha256']=hashlib.sha256((out/frozen['prepared_file']).read_bytes()).hexdigest()
(dep/(stage.upper()+'-FROZEN.json')).write_text(json.dumps(frozen,indent=2)+'\n')
start='#!/usr/bin/env bash\nset -eu\nexport PYTHONPATH="/deployment/'+name+'/source/src:/deployment/'+name+'/source/scripts:${PYTHONPATH:-}"\nexec python3 /deployment/'+name+'/source/scripts/benchmark_retrieval_scaling.py --settings /deployment/'+name+'/settings-a3.json --prepared /results/'+frozen['prepared_file']+' --corpus /deployment/'+name+'/data/corpus.jsonl --output /results/'+stage+'.jsonl'+(' --contexts closed dynamic' if stage=='smoke' else '')+'\n'
(dep/(stage+'-start.sh')).write_text(start)
launch='stage='+repr(stage)+'\n'+r"""
from pathlib import Path
import hashlib,json,subprocess,time
root=Path('/data/disk/changxiangyu/agentic_scaling');name='online-injection-scaling-20261109-a3';dep=root/'deployment/ascend'/name;out=root/'results'/name;c='agentic-scaling-changxiangyu-injection-scaling-a3'
status=1;started=time.time()
try:
 frozen=json.loads((dep/(stage.upper()+'-FROZEN.json')).read_text())
 for n,h in {**frozen['source_files'],**frozen['hashes']}.items():assert hashlib.sha256((dep/n).read_bytes()).hexdigest()==h,n
 assert hashlib.sha256((out/frozen['prepared_file']).read_bytes()).hexdigest()==frozen['prepared_sha256']
 assert 'No running processes found in NPU 3' in subprocess.check_output(['/usr/local/bin/npu-smi','info'],text=True)
 subprocess.run(['docker','start',c],check=True,capture_output=True)
 if not (out/'runtime-versions.json').exists():
  code="import importlib.metadata as m,json,platform;print(json.dumps({'python':platform.python_version(),'packages':{p:m.version(p) for p in ['vllm','vllm-ascend','torch','torch-npu','transformers','tokenizers']}}))"
  (out/'runtime-versions.json').write_bytes(subprocess.check_output(['docker','exec',c,'bash','/deployment/env.sh','python3','-c',code]))
 with (out/(stage+'.log')).open('wb') as log:
  result=subprocess.run(['docker','exec',c,'bash','/deployment/env.sh','bash','/deployment/'+name+'/'+stage+'-start.sh'],stdout=log,stderr=subprocess.STDOUT)
 status=result.returncode
finally:
 (out/(stage+'.exit')).write_text(str(status)+'\n')
 subprocess.run(['docker','stop',c],capture_output=True,timeout=45)
 d=json.loads(subprocess.check_output(['docker','inspect',c],text=True))[0]
 (out/(stage+'-finish.json')).write_text(json.dumps({'generation_exit':status,'started':started,'finished':time.time(),'running':d['State']['Running'],'state':d['State'],'image':d['Image'],'devices':d['HostConfig']['Devices']},indent=2)+'\n')
"""
(dep/(stage+'-launch.py')).write_text(launch)
with (out/(stage+'-launch.log')).open('wb') as log:proc=subprocess.Popen(['python3',str(dep/(stage+'-launch.py'))],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
print(json.dumps({'stage':stage,'pid':proc.pid,'source_commit':frozen['source_commit'],'prepared_sha256':frozen['prepared_sha256']}))
'''
(base/(a.stage+'-launch-remote.py')).write_text(script,encoding='utf-8',newline='\n')
r=subprocess.run([sys.executable,'-X','utf8',str(base/'remote.py'),'a','--via-jump','--timeout','90','--file',str(base/(a.stage+'-launch-remote.py'))],capture_output=True,timeout=100)
(base/(a.stage+'-launch-result.txt')).write_bytes(r.stdout+r.stderr)
print(r.stdout.decode());print(r.stderr.decode());raise SystemExit(r.returncode)
