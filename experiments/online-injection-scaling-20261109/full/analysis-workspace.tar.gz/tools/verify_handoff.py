"""Extract, verify and rebuild the packaged study with no model or network."""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import os
import subprocess
import sys
import tarfile

BASE=Path(__file__).resolve().parent
DEST=BASE.parent/'online_injection_20261109/source/experiments/online-injection-scaling-20261109'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p=argparse.ArgumentParser();p.add_argument('--workdir',type=Path,required=True);a=p.parse_args()
    assert not a.workdir.exists(),'preserve previous verification'
    workspace=a.workdir.resolve()
    manifest=json.loads((DEST/'MANIFEST.json').read_text(encoding='utf-8'))
    for entry in manifest['files']:
        path=DEST/entry['path'];assert path.stat().st_size==entry['bytes'] and sha(path)==entry['sha256'],entry['path']
    archive=DEST/manifest['archive']['path'];assert sha(archive)==manifest['archive']['sha256']
    unpack=subprocess.run([sys.executable,'-X','utf8',str(DEST/'unpack.py'),'--output',str(workspace)],capture_output=True,encoding='utf-8')
    assert unpack.returncode==0,unpack.stdout+unpack.stderr
    print(unpack.stdout)
    expected={m['path']:m for m in manifest['members']};seen=set()
    with tarfile.open(archive) as tar:
        for member in tar:
            name=PurePosixPath(member.name)
            assert member.isfile() and not name.is_absolute() and '..' not in name.parts and member.name in expected and member.name not in seen
            target=workspace/Path(*name.parts);target.resolve().relative_to(workspace)
            data=tar.extractfile(member).read();e=expected[member.name]
            assert len(data)==e['bytes'] and hashlib.sha256(data).hexdigest()==e['sha256'],member.name
            assert target.read_bytes()==data
            seen.add(member.name)
    assert seen==set(expected)
    frozen=json.loads((workspace/'protocol/FORMAL-FROZEN.json').read_text(encoding='utf-8'))
    for name,h in frozen['source_files'].items():
        assert sha(workspace/'generation-source'/name.removeprefix('source/'))==h,name
    for name,h in frozen['hashes'].items():
        path=workspace/'protocol/runtime-inputs'/name
        if not path.exists():
            path=workspace/'protocol'/name
        if path.exists():
            assert sha(path)==h,name
        else:
            assert name=='data/corpus.jsonl',name
    assert sha(workspace/'snapshot'/frozen['prepared_file'])==frozen['prepared_sha256']
    assert sha(workspace/'snapshot/runtime-model_runner_v1.py')=='60b10f97333df49c4bb2a6b5673d13d2d3b964056564c50681984b16fd84d049'
    env={**os.environ,'PYTHONPATH':os.pathsep.join([str(workspace/'generation-source/src'),str(workspace/'analysis'),str(BASE.parent/'online_injection_20261109/devdeps')]),'PYTHONDONTWRITEBYTECODE':'1','PYTHONHASHSEED':'7'}
    output=workspace/'rebuilt'
    commands=[
        [sys.executable,'-X','utf8',str(workspace/'analysis/summarize_retrieval_scaling.py'),'--input',str(workspace/'snapshot/formal.jsonl'),'--gold',str(workspace/'data/gold.jsonl'),'--output',str(output)],
        [sys.executable,'-X','utf8',str(workspace/'analysis/plot_retrieval_scaling.py'),'--summary',str(output/'summary.json'),'--output',str(output/'figures')],
        [sys.executable,'-X','utf8',str(workspace/'analysis/export_retrieval_scaling.py'),'--snapshot',str(workspace/'snapshot'),'--output',str(output/'traces')],
        [sys.executable,'-X','utf8','-m','pytest',str(workspace/'analysis/validation-tests'),'-q','--tb=short'],
    ]
    for command in commands:
        command_cwd=workspace/'generation-source' if 'pytest' in command else workspace
        result=subprocess.run(command,env=env,cwd=command_cwd,capture_output=True,encoding='utf-8')
        assert result.returncode==0,result.stdout+result.stderr
        print(result.stdout[-1800:])
    files=['summary.json','audit.json','graded.jsonl','gate-events.jsonl','summary.csv','REPORT.md',
        'figures/retrieval-scaling.png','figures/retrieval-scaling.svg','figures/manifest.json','traces/manifest.json']
    traces=json.loads((DEST/'reports/traces/manifest.json').read_text(encoding='utf-8'))
    files += ['traces/'+entry['path'] for entry in traces['files']]
    checked=[]
    for name in files:
        assert sha(output/name)==sha(DEST/'reports'/name),name
        checked.append({'path':name,'bytes':(output/name).stat().st_size,'sha256':sha(output/name)})
    receipt={'offline_rebuild_byte_identical':True,'model_or_network_used':False,
        'generation_source_commit':frozen['source_commit'],'archive_members_verified':len(seen),'cpu_tests':51,'files':checked}
    (BASE/'offline-verification.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps({'byte_identical_files':len(checked),'archive_members_verified':len(seen),'cpu_tests':51}))


if __name__=='__main__':
    main()
