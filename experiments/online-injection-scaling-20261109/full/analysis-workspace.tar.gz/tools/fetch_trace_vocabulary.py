from pathlib import Path
import base64,gzip,json,subprocess,sys
base=Path(__file__).resolve().parent
script=r'''
from pathlib import Path
import base64,gzip,hashlib,json
root=Path('/data/disk/changxiangyu/agentic_scaling');out=root/'results/online-injection-scaling-20261109-a3'
assert (out/'formal.exit').read_text().strip()=='0'
prepared=json.loads((out/'prepared-formal-v2.json').read_text());rows=[json.loads(line) for line in (out/'formal.jsonl').read_text().splitlines()]
needed=set()
def visit(value,key=''):
 if isinstance(value,dict):
  for k,v in value.items():visit(v,k)
 elif isinstance(value,list):
  if key.endswith('ids') and all(type(t) is int for t in value):needed.update(value)
  else:
   for v in value:visit(v)
visit(prepared)
for row in rows:visit(row)
p=root/'runtime/models/Qwen3.8-27B/tokenizer.json';raw=p.read_bytes();digest=hashlib.sha256(raw).hexdigest();assert digest==prepared['tokenizer_hashes']['tokenizer.json']
d=json.loads(raw);vocab={str(v):k for k,v in d['model']['vocab'].items() if v in needed}
for token in d['added_tokens']:
 if token['id'] in needed:vocab[str(token['id'])]=token['content']
assert set(map(int,vocab))==needed
value={'tokenizer_sha256':digest,'decoder':d['decoder'],'model_type':d['model']['type'],'vocab':vocab,'special_ids':[t['id'] for t in d['added_tokens'] if t['special']]}
print(base64.b64encode(gzip.compress(json.dumps(value,ensure_ascii=False).encode())).decode())
'''
r=subprocess.run([sys.executable,'-X','utf8',str(base/'remote.py'),'a','--timeout','90'],input=script.encode(),capture_output=True,timeout=100)
if r.returncode:raise RuntimeError(r.stderr.decode(errors='replace'))
value=json.loads(gzip.decompress(base64.b64decode(r.stdout.strip())));(base/'snapshot/trace-tokenizer-subset.json').write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'token_ids':len(value['vocab']),'tokenizer_sha256':value['tokenizer_sha256']}))
