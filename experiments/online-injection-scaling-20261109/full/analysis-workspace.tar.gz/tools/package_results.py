"""Package the completed pilot with byte-verifiable offline reproduction inputs."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import shutil
import tarfile

BASE=Path(__file__).resolve().parent
PILOT=BASE.parent/'online_injection_20261109'
REPO=PILOT/'source'
REPORT=BASE.parents[1]/'outputs/online-injection-scaling-20261109'
DEST=REPO/'experiments/online-injection-scaling-20261109'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    summary=json.loads((REPORT/'summary.json').read_text(encoding='utf-8'))
    assert summary['complete'] and summary['conditions']==summary['expected_conditions']==120 and not summary['audit_failures']
    state=json.loads((BASE/'snapshot/state-formal.json').read_text(encoding='utf-8'))
    assert state['exit']=='0' and not state['changed_files'] and not state['changed_inputs'] and state['prepared_matches_frozen'] and state['runtime_runner_matches_frozen'] and not state['gold_deployment_files']
    assert not DEST.exists(),'preserve an existing canonical package'
    entries={}

    def add(name,path):
        data=path.read_bytes()
        if name in entries:
            assert entries[name]==data,name
        else:
            entries[name]=data

    for folder,prefix in [('snapshot','snapshot'),('provenance','protocol'),('smoke-audit','validation/smoke-audit')]:
        for path in (BASE/folder).rglob('*'):
            if path.is_file():
                add(prefix+'/'+path.relative_to(BASE/folder).as_posix(),path)
    for path in (BASE/'data').iterdir():
        if path.is_file():
            add('data/'+path.name,path)
    for name in ['unrelated-prose.txt','settings-a3.json']:
        add('protocol/'+name,BASE/name)
    for name,path in [
        ('data/questions.jsonl',BASE/'data/questions-initial.jsonl'),
        ('data/manifest.json',BASE/'data/manifest-initial.json'),
        ('data/questions-v2.jsonl',BASE/'data/questions.jsonl'),
        ('data/manifest-v2.json',BASE/'data/manifest.json'),
        ('data/smoke-questions.jsonl',BASE/'data/smoke-questions.jsonl'),
    ]:
        add('protocol/runtime-inputs/'+name,path)
    add('data/DATASET_CARD.md',PILOT/'techqa_raw/README.md')
    add('data/LICENSE-Apache-2.0.txt',PILOT/'NVIDIA-LICENSE-Apache-2.0.txt')
    add('protocol/source-frozen.tgz',BASE/'source-frozen.tgz')
    with tarfile.open(BASE/'source-frozen.tgz') as tar:
        for member in tar:
            if member.isfile():
                assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
                entries['generation-source/'+member.name]=tar.extractfile(member).read()
    for name in ['summarize_retrieval_scaling.py','summarize_flare_gap.py','plot_retrieval_scaling.py','export_retrieval_scaling.py']:
        add('analysis/'+name,REPO/'scripts'/name)
    add('analysis/PROTOCOL.md',REPO/'docs/reports/RETRIEVAL_SCALING_PROTOCOL.md')
    for name in ['test_retrieval_scaling.py','test_stepwise_injection.py','test_conditional_is.py','test_rewards.py']:
        add('analysis/validation-tests/'+name,REPO/'tests'/name)
    entries['analysis/validation-tests/tests/__init__.py']=b'"""Portable CPU validation support."""\n'
    add('analysis/validation-tests/tests/tabular.py',REPO/'tests/tabular.py')
    for name in ['deploy.py','launch.py','collect.py','monitor.py','remote.py','ssh_socket.py','package_results.py','record_resources.py','fetch_trace_vocabulary.py','verify_handoff.py']:
        if (BASE/name).exists():
            add('tools/'+name,BASE/name)
    for path in REPORT.rglob('*'):
        if path.is_file():
            add('reports/'+path.relative_to(REPORT).as_posix(),path)
    needed=set()

    def walk(x):
        if isinstance(x,dict):
            for k,v in x.items():
                if k=='parent_ids':
                    needed.update(v)
                else:
                    walk(v)
        elif isinstance(x,list):
            for v in x:
                walk(v)
    for name in ['prepared-formal-v2.json','prepared-smoke.json']:
        walk(json.loads((BASE/'snapshot'/name).read_text(encoding='utf-8')))
    for name in ['formal.jsonl','smoke.jsonl']:
        for line in (BASE/'snapshot'/name).read_text(encoding='utf-8').splitlines():
            walk(json.loads(line))
    for line in (BASE/'data/gold.jsonl').read_text(encoding='utf-8').splitlines():
        needed.update(json.loads(line)['document_ids'])
    documents=[]
    for line in (PILOT/'data/techqa/corpus.jsonl').read_text(encoding='utf-8').splitlines():
        if json.loads(line)['id'] in needed:
            documents.append(line)
    assert len(documents)==len(needed)
    entries['data/retrieved-and-gold-documents.jsonl']=('\n'.join(documents)+'\n').encode()
    frozen=json.loads((BASE/'provenance/FORMAL-FROZEN.json').read_text(encoding='utf-8'))
    for name,h in frozen['source_files'].items():
        assert sha(entries['generation-source/'+name.removeprefix('source/')])==h,name
    (DEST/'full').mkdir(parents=True)
    archive=DEST/'full/analysis-workspace.tar.gz'
    members=[]
    with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,filename='',mode='wb',mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w') as tar:
        for name,data in sorted(entries.items()):
            members.append({'path':name,'bytes':len(data),'sha256':sha(data)})
            member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644
            tar.addfile(member,io.BytesIO(data))
    for path in REPORT.rglob('*'):
        if path.is_file():
            dest=DEST/'reports'/path.relative_to(REPORT)
            dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,dest)
    shutil.copyfile(REPO/'scripts/unpack_retrieval_scaling.py',DEST/'unpack.py')
    readme='''# Retrieval + inference scaling pilot

See `reports/OBSERVATIONS.md` for conclusions and `reports/REPORT.md` for all
numbers. The archive contains frozen generation source, raw native generation,
all candidates and scores, protocol/input hashes, both TRAIN smoke questions,
offline gold and all retrieved/gold parent documents needed to inspect evidence.
Full BM25 re-retrieval requires the pinned public corpus; the included parent
subset is for inspection, not a replacement full-corpus ranking index.

Run `python unpack.py --output NEW_DIRECTORY` to extract and verify every archive
member. Python 3.12+ with
NumPy and Matplotlib suffices for offline audits, grading and figures. No model,
network, tokenizer or accelerator is used by these analysis commands. On Windows
set `PYTHONPATH` to `generation-source/src;analysis`; on POSIX use
`generation-source/src:analysis`. Run from the extracted root:

```sh
python analysis/summarize_retrieval_scaling.py --input snapshot/formal.jsonl --gold data/gold.jsonl --output rebuilt
python analysis/plot_retrieval_scaling.py --summary rebuilt/summary.json --output rebuilt/figures
python analysis/export_retrieval_scaling.py --snapshot snapshot --output rebuilt/traces
```

`MANIFEST.json` records every archive member's length and SHA256. Generation
source and model/runtime pins are in `protocol/FORMAL-FROZEN.json` and the
prepared inputs. Native re-execution is separate from the offline reproduction.
The native run used A physical NPU3, TP1; each stage stops its own container on exit.
'''
    (DEST/'README.md').write_text(readme,encoding='utf-8',newline='\n')
    manifest={'generation_source_commit':frozen['source_commit'],'archive':{'path':archive.relative_to(DEST).as_posix(),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},'members':members,'included_parent_documents':len(needed),'files':[]}
    for path in sorted(DEST.rglob('*')):
        if path.is_file():
            manifest['files'].append({'path':path.relative_to(DEST).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())})
    (DEST/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps({'archive':manifest['archive'],'members':len(members),'parent_documents':len(needed)}))


if __name__=='__main__':
    main()
