"""Compact read-only progress; no model inspection or scheduling."""
from pathlib import Path
import argparse,json,subprocess,sys,time
base=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--once',action='store_true');a=p.parse_args()
script=r'''
from pathlib import Path
import json,re,time
out=Path('/data/disk/changxiangyu/agentic_scaling/results/online-injection-scaling-20261109-a3');p=out/'formal.jsonl';raw=p.read_bytes() if p.exists() else b'';lines=raw.splitlines();last={}
if lines:
 try:last=json.loads(lines[-1] if raw.endswith(b'\n') else lines[-2])
 except (ValueError,IndexError):pass
code=(out/'formal.exit').read_text().strip() if (out/'formal.exit').exists() else None
info={'time':time.time(),'conditions':len(re.findall(rb'^\{"kind": "measurement",',raw,re.M)),'units':len(re.findall(rb'^\{"kind": "execution_unit",',raw,re.M)),'last':{k:last.get(k) for k in ['kind','question_id','policy','arm','unit_id','error']},'exit':code}
if code is not None and code!='0':info['log_tail']=(out/'formal.log').read_text(errors='replace')[-2500:]
print(json.dumps(info))
'''
while True:
 r=subprocess.run([sys.executable,'-X','utf8',str(base/'remote.py'),'a','--timeout','45'],input=script.encode(),capture_output=True,timeout=55)
 if r.returncode:print(json.dumps({'monitor_error':r.stderr.decode(errors='replace')[-600:]}),flush=True)
 else:
  val=json.loads(r.stdout);print(json.dumps(val),flush=True)
  if val['exit'] is not None:break
 if a.once:break
 time.sleep(30)
