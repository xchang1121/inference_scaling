"""Create an isolated, pinned NPU3-only deployment, preserving all old runs."""
from pathlib import Path
import base64
import hashlib
import json
import subprocess
import sys

base=Path(__file__).resolve().parent
repo=base.parent/'online_injection_20261109/source'
head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
paths=['src','settings','pyproject.toml','scripts/benchmark_is_gpu.py','scripts/benchmark_flare_gap.py',
       'scripts/benchmark_retrieval_scaling.py','tests/test_retrieval_scaling.py','docs/reports/RETRIEVAL_SCALING_PROTOCOL.md']
source=subprocess.check_output(['git','-C',str(repo),'archive','--format=tar.gz','HEAD',*paths])
(base/'source-frozen.tgz').write_bytes(source)
files={'source-frozen.tgz':source,**{n:(base/n).read_bytes() for n in ['settings-a3.json','unrelated-prose.txt','data/questions.jsonl','data/smoke-questions.jsonl','data/manifest.json']}}
payload={'head':head,'files':{n:base64.b64encode(b).decode() for n,b in files.items()},'hashes':{n:hashlib.sha256(b).hexdigest() for n,b in files.items()}}
script='payload='+repr(payload)+r'''
from pathlib import Path
import base64,hashlib,io,json,shutil,subprocess,tarfile,time
root=Path('/data/disk/changxiangyu/agentic_scaling');name='online-injection-scaling-20261109-a3'
dep=root/'deployment/ascend'/name;out=root/'results'/name;c='agentic-scaling-changxiangyu-injection-scaling-a3'
assert not dep.exists() and not out.exists(),'preserve previous attempts'
old=json.loads(subprocess.check_output(['docker','inspect','agentic-scaling-changxiangyu-injection-flare-gap-a3'],text=True))[0]
assert not old['State']['Running']
assert old['Image']=='sha256:e288ad4ffb99e8d956a241c5489ad526f33741a16faa5783763a7e63a624b525'
assert 'No running processes found in NPU 3' in subprocess.check_output(['/usr/local/bin/npu-smi','info'],text=True)
dep.mkdir();out.mkdir()
for n,b64 in payload['files'].items():
 data=base64.b64decode(b64);assert hashlib.sha256(data).hexdigest()==payload['hashes'][n]
 p=dep/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
with tarfile.open(dep/'source-frozen.tgz') as tar:
 for m in tar:
  assert not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  if m.isfile():
   p=dep/'source'/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(tar.extractfile(m).read())
  elif not m.isdir():raise RuntimeError('unexpected archive member')
shutil.copyfile(root/'deployment/ascend/online-injection-flare-gap-20261109-a3/data/corpus.jsonl',dep/'data/corpus.jsonl')
command=['docker','create','--name',c,'--user',old['Config']['User'],'--group-add','1001','--shm-size',str(old['HostConfig']['ShmSize']),'-e','OMP_NUM_THREADS=4','-e','VLLM_WORKER_MULTIPROC_METHOD=spawn']
for device in old['HostConfig']['Devices']:
 assert device['PathOnHost'] in {'/dev/davinci3','/dev/davinci_manager','/dev/devmm_svm','/dev/hisi_hdc'}
 command+=['--device',device['PathOnHost']+':'+device['PathInContainer']]
assert any(d['PathOnHost']=='/dev/davinci3' for d in old['HostConfig']['Devices'])
for mount in old['Mounts']:
 source=str(out) if mount['Destination']=='/results' else mount['Source']
 value='type=bind,source='+source+',target='+mount['Destination']
 if not mount['RW']:value+=',readonly'
 command+=['--mount',value]
command += [old['Image'],'sleep','infinity'];subprocess.run(command,check=True,capture_output=True)
runner=subprocess.check_output(['docker','cp',c+':/vllm-workspace/vllm-ascend/vllm_ascend/worker/model_runner_v1.py','-'])
with tarfile.open(fileobj=io.BytesIO(runner)) as tar:
 members=[m for m in tar if m.isfile()];assert len(members)==1;runner=tar.extractfile(members[0]).read()
assert hashlib.sha256(runner).hexdigest()=='60b10f97333df49c4bb2a6b5673d13d2d3b964056564c50681984b16fd84d049'
(out/'runtime-model_runner_v1.py').write_bytes(runner)
frozen={'source_commit':payload['head'],'created':time.time(),'container':c,'image':old['Image'],'devices':[3],'tp':1,
 'hashes':{**payload['hashes'],'data/corpus.jsonl':hashlib.sha256((dep/'data/corpus.jsonl').read_bytes()).hexdigest()},
 'source_files':{p.relative_to(dep).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (dep/'source').rglob('*') if p.is_file()}}
(dep/'PREPARE-PROTOCOL.json').write_text(json.dumps(frozen,indent=2)+'\n')
commands=[]
for stage,qfile in [('formal','questions.jsonl'),('smoke','smoke-questions.jsonl')]:
 commands.append('python3 /deployment/'+name+'/source/scripts/benchmark_retrieval_scaling.py --settings /deployment/'+name+'/settings-a3.json --corpus /deployment/'+name+'/data/corpus.jsonl --questions /deployment/'+name+'/data/'+qfile+' --noise /deployment/'+name+'/unrelated-prose.txt --prepared /results/prepared-'+stage+'.json --prepare-only')
start='#!/usr/bin/env bash\nset -eu\nexport PYTHONPATH="/deployment/'+name+'/source/src:/deployment/'+name+'/source/scripts:${PYTHONPATH:-}"\n'+'\n'.join(commands)+'\n'
(dep/'prepare.sh').write_text(start.replace('\\n','\n'))
subprocess.run(['docker','start',c],check=True,capture_output=True)
with (out/'prepare.log').open('wb') as log:
 result=subprocess.run(['docker','exec',c,'bash','/deployment/env.sh','bash','/deployment/'+name+'/prepare.sh'],stdout=log,stderr=subprocess.STDOUT,timeout=300)
(out/'prepare.exit').write_text(str(result.returncode)+'\n')
print(json.dumps({'prepare_exit':result.returncode,'source_commit':payload['head'],'prepared':[p.name for p in out.glob('prepared-*')],'log_tail':(out/'prepare.log').read_text()[-1500:]}))
'''
# Use real newlines inside the remote Python string literals.
script=script.replace("\\\\n", "\\n")
(base/'bootstrap-remote.py').write_text(script,encoding='utf-8',newline='\n')
r=subprocess.run([sys.executable,'-X','utf8',str(base/'remote.py'),'a','--via-jump','--timeout','360','--file',str(base/'bootstrap-remote.py')],capture_output=True,timeout=380)
(base/'bootstrap-result.txt').write_bytes(r.stdout+r.stderr)
print(r.stdout.decode());print(r.stderr.decode());raise SystemExit(r.returncode)
