# Retrieval + inference scaling pilot

Completed: True; 18/18 conditions; 14 unique execution units; 1778 checks, 0 failures.

F1 is normalized answer token F1 (%), not exact-answer accuracy. Question counts: smoke=2; one seed. Equal generated-token caps do not imply equal realized work or FLOPs. Normalized EM is in summary.csv.

Times cover measured execution units, including online dynamic lookup. Model startup, corpus-index construction and offline static-packet preparation are excluded. PFLOPs are native dense-padded graph estimates, not hardware-counter measurements of every operation.

| Cohort | Evidence / method | F1 % | Mean work | Mean s | Mean PFLOPs | Empty | Thinking EOS | Forced close |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| smoke | closed.none/block_met_sc | not scored | 4626.0 | 98.21 | 1.025 | 0 | 0 | 0 |
| smoke | closed.none/sc_bon | not scored | 4799.5 | 94.42 | 0.721 | 0 | 0 | 0 |
| smoke | closed.none/single | not scored | 533.5 | 44.29 | 0.446 | 0 | 0 | 0 |
| smoke | dynamic.relevant/block_met_sc | not scored | 4156.5 | 103.01 | 1.422 | 0 | 0 | 0 |
| smoke | dynamic.relevant/sc_bon | not scored | 3351.0 | 82.09 | 0.901 | 0 | 0 | 0 |
| smoke | dynamic.relevant/single | not scored | 671.5 | 52.65 | 0.527 | 0 | 0 | 0 |
| smoke | dynamic.unrelated/block_met_sc | not scored | 4156.5 | 103.01 | 1.422 | 0 | 0 | 0 |
| smoke | dynamic.unrelated/sc_bon | not scored | 3351.0 | 82.09 | 0.901 | 0 | 0 | 0 |
| smoke | dynamic.unrelated/single | not scored | 671.5 | 52.65 | 0.527 | 0 | 0 | 0 |

Paired question-bootstrap contrasts (percentage points):

