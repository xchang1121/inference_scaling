"""Wait for the assigned idle accelerator pair; launch only this frozen experiment."""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
import re
import subprocess
import time
from pathlib import Path

ROOT = Path('/data/disk/changxiangyu/agentic_scaling')
DEP = ROOT / 'deployment/ascend/coding-bench-20261104'
OUT = ROOT / 'results/coding-bench-20261104'


def command(args, timeout=45):
    return subprocess.check_output(args, text=True, timeout=timeout)


def status(path, state, **extra):
    value = {'state': state, 'time': time.time(), 'pid': os.getpid(), **extra}
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)
    return value


def verify():
    frozen = json.loads((DEP / 'FROZEN.json').read_text())
    for name, expected in frozen['files'].items():
        actual = hashlib.sha256((DEP / name).read_bytes()).hexdigest()
        if actual != expected:
            raise RuntimeError(f'frozen file changed: {name}')
    return frozen


def available(devices):
    text = command(['/usr/local/bin/npu-smi', 'info'])
    lines = text.splitlines()
    usage = {}
    for index, line in enumerate(lines[:-1]):
        match = re.match(r'\|\s*(\d+)\s+910B\d+\s+\|\s*OK\s*\|', line)
        if match:
            memory = re.search(r'(\d+)\s*/\s*(\d+)\s*\|\s*$', lines[index + 1])
            if memory:
                usage[int(match[1])] = int(memory[1])
    free = all(usage.get(device, 100000) < 8192 and
               f'No running processes found in NPU {device}' in text for device in devices)
    return free, {str(device): usage.get(device) for device in devices}


def judge_command(config, *, self_test=False):
    output = OUT / 'evaluation'
    output.mkdir(parents=True, exist_ok=True)
    inputs = OUT / 'generation'
    inputs.mkdir(parents=True, exist_ok=True)
    args = ['docker', 'run', '--rm', '--name', config['judge_container'],
            '--label', 'inference_scaling.owner=changxiangyu', '--network', 'none', '--read-only',
            '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges', '--pids-limit', '512',
            '--cpus', '4', '--memory', '8g', '--shm-size', '1g', '--tmpfs', '/tmp:rw,size=2g',
            '--user', config['user'], '--mount', f'type=bind,src={DEP},dst=/study,readonly',
            '--mount', f'type=bind,src={output},dst=/out',
            '--mount', f'type=bind,src={inputs},dst=/inputs,readonly',
            '-e', 'PYTHONDONTWRITEBYTECODE=1', '-e', 'OMP_NUM_THREADS=1', '-e', 'OPENBLAS_NUM_THREADS=1',
            '-e', 'PYTHONPATH=/study/source/src:/study/source/scripts:/study/vendor/evalplus:/study/vendor/LiveCodeBench',
            config['image_id'], 'python3', '/study/source/scripts/judge_coding.py',
            '--data', '/study/frozen/judge-data.json', '--manifest', '/study/frozen/public-manifest.json']
    if self_test:
        return args + ['--self-test', '--output', '/out/self-test.json']
    return args + ['--inputs', f"/inputs/{config['replica']}.jsonl", '--output',
                   f"/out/{config['replica']}-judgments.jsonl", '--follow']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    replica = config['replica']
    OUT.mkdir(parents=True, exist_ok=True)
    state_path = OUT / f'{replica}-queue.json'
    with (OUT / f'{replica}-queue.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            frozen = verify()
            status(state_path, 'preflight', source_commit=frozen['source_commit'])
            with (OUT / f'{replica}-judge-selftest.log').open('a') as log:
                tested = subprocess.run(judge_command(config, self_test=True), stdout=log, stderr=log, timeout=180)
            if tested.returncode:
                raise RuntimeError(f'judge self-test failed: {tested.returncode}')
            stable = 0
            while stable < 2:
                free, usage = available(config['devices'])
                top = command(['docker', 'top', config['generation_container'], '-eo', 'comm']).splitlines()[1:]
                idle = bool(top) and all(name.strip() == 'sleep' for name in top)
                stable = stable + 1 if free and idle else 0
                status(state_path, 'waiting_for_devices', devices=config['devices'], hbm_mib=usage,
                       container_idle=idle, consecutive_free_checks=stable)
                if stable < 2:
                    time.sleep(10 if stable else 60)
            verify()
            prefix = '/deployment/coding-bench-20261104'
            py_path = prefix + '/source/src'
            if config['replica'] == 'b':
                py_path = '/cache/engine/vllm:/cache/engine/vllm-ascend:' + py_path
            gen_command = ['docker', 'exec', '-e', 'VLLM_USE_V2_MODEL_RUNNER=0', '-e', 'PYTHONPATH=' + py_path,
                           '-w', prefix + '/source', config['generation_container'], 'bash', '/deployment/env.sh',
                           '/cache/venv/bin/python', '-u', 'scripts/benchmark_coding.py',
                           '--settings', prefix + '/settings-' + replica + '.json',
                           '--manifest', prefix + '/frozen/public-manifest.json',
                           '--output', '/results/coding-bench-20261104/generation/' + replica + '.jsonl',
                           '--shard', str(config['shard']), '--shards', '2']
            (OUT / 'generation').mkdir(exist_ok=True)
            with (OUT / f'{replica}-judge.log').open('a') as judge_log, (OUT / f'{replica}-generation.log').open('a') as gen_log:
                judge = subprocess.Popen(judge_command(config), stdout=judge_log, stderr=judge_log)
                generation = subprocess.Popen(gen_command, stdout=gen_log, stderr=gen_log)
                status(state_path, 'running', devices=config['devices'], generation_pid=generation.pid,
                       judge_pid=judge.pid, source_commit=frozen['source_commit'])
                code = generation.wait()
                (OUT / f'{replica}-generation.exit').write_text(str(code) + '\n')
                if code:
                    status(state_path, 'generation_failed', exit_code=code, judge_pid=judge.pid)
                    return code
                status(state_path, 'grading_remaining', judge_pid=judge.pid)
                code = judge.wait()
                (OUT / f'{replica}-judge.exit').write_text(str(code) + '\n')
                status(state_path, 'complete' if code == 0 else 'judge_failed', exit_code=code)
                return code
        except BaseException as error:
            status(state_path, 'queue_error', error=f'{type(error).__name__}: {error}')
            raise


if __name__ == '__main__':
    raise SystemExit(main())
