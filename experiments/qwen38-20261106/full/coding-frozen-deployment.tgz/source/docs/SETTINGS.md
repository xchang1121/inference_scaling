# 设置文件

所有入口从仓库根目录读取 `settings/inference.json`。模型、长度、奖励和执行参数共用同一来源。
[`app/settings.py`](../src/inference_scaling/app/settings.py) 严格校验字段名称与类型，错误在加载模型前报出。
标注为“对象”的字段原样传给对应库。
下表中的数值是仓库提供的文件中的取值。

单条 AR 生成总长在 `ar.max_new_tokens` 定义，thinking 预算在 `ar.thinking` 定义；上下文容量由
`ar.engine.context_window` 控制。前两种长度均以单条轨迹计，全部候选的累计计算量另行统计。
`max_new_tokens=null` 使用剩余上下文，`context_window=null` 读取模型/引擎配置。
服务与评测共用这些设置、采样策略和根种子。

## 性能评测

`scripts/benchmark_is_gpu.py` 配对测量同题 Base 思考采样与当前快速 IS。模型、采样、奖励、M/K/B 和硬件设置
继承该文件，要求异步 vLLM、`workers=1`、thinking 范围及 `exploration_schedule="two_stage"`。
`selection_ready` 由同一配置控制。默认 `--study latency` 的 IS 奖励读取 `run.reward`；该入口不运行固定块 IS 对照。

```bash
python scripts/benchmark_is_gpu.py --settings settings/inference.json \
  --dataset math500 --questions 2 --repeats 1 --effort low --max-tokens 8192 \
  --label tp2-fast --output results/tp2-fast.jsonl
python scripts/benchmark_is_gpu.py --summary results/tp2-fast.jsonl
```

短负载示例显式使用 4096 thinking / 8192 总长；省略预算参数则继承配置。硬件和算法在配置中调整，CLI 不再重复
暴露历史开关。每题每次重复派生独立根种子，两种方法使用同一根种子及各自的算法子流；运行顺序逐对交替。
两种方法各用独立的 64 token 请求预热，计时前清空前缀缓存。时延包含最终内容生成，排除加载、预热、判题和写入。

主指标 `latency_ratio_is_over_base` 为 IS 总时延除以 Base 总时延；另报逐题比值 p50/p95、正确率、长度耗尽、
实际生成量与含填充前向 FLOPs。出现取消或抢占时，普通完成计数仅作为已观测量，完整生成量标为 `null`；
原生执行计数仍记录已执行的计算。失败和缺失配对不产生完整时延比，判题失败不计为已知正确率。
`sample_quality_gate` 只表示样本中 IS 正确数不少于 Base 且至少有一道正确，不代表总体非劣性。
`is_single_admitted_seconds` 记录搜索阶段仅一条请求已准入的累计时间，区别于设备空闲时间。
`is_search_seconds` 记录整个 IS 搜索，`is_first_commit_seconds` 记录搜索开始至首次固定非空前缀的时间；
`is_commits` 只保存各次固定前缀的相对时间和累计长度，可区分首轮与后续更新，不保存历史 token。
这些时间不含 HTTP 传输，客户端 TTFT 由服务性能入口测量。观测通过原有 `on_commit` 回调完成，不参与选择。
完整设置、代码版本和顺序保存在 JSONL；`--summary` 只读汇总，不加载模型。

`--study selection` 在同一入口增加完整等待的 SIR、逐条 Metropolized 选择（K=1、2）及按块 Metropolized
选择（K=2），保留 Base 与快速 Consilience IS。该历史对照显式使用 Consilience，不随 `run.reward` 改变。要求配置为 M=4、K=1、`two_stage`、`selection_ready=true`；各对照只覆盖
K、选择核与提前选择开关，实际生效配置逐条记录。方法顺序逐题轮换，判题在生成后执行，标准答案不参与选择。
相同长度上限不代表相同总计算量；汇总同时给出正确率、配对答对/答错变化、时延与 FLOPs，评估质量与成本的取舍。
K=1 且候选块互异时，逐条与按块 Metropolized 完全相同，故不重复设组。

`--study rewards` 对比 Base、快速 Consilience IS、`bon-consilience`（四条完整候选中取思考段 Consilience
最高者）及 `is-self-certainty`（IS 改用思考段平均全词表 KL）。后两项分别固定 N=4、评分范围为 thinking；
其余参数继承设置，实际算法和奖励配置逐条记录。Best-of-4 为四条候选都生成最终内容，IS 选定思考后只续写一份
最终内容；因此按各自实际计算量比较。`--modes` 可指定该 study 的子集，补测无需重跑已有方法：

```bash
python scripts/benchmark_is_gpu.py --settings settings/inference.json --study rewards \
  --modes bon-consilience is-self-certainty --dataset math500 --questions 2 --repeats 1 \
  --effort low --max-tokens 8192 --label rewards --output results/rewards.jsonl
```

Ascend 的 `ar.engine.vllm.scalar_self_certainty` 默认开启；采样与评分温度须相同且使用完整支持集。
Self-Certainty 奖励温度沿用配置（默认 0.25），Consilience 默认 2；不按评测答案选择温度。
独立补测按题目 ID 与已有 Base/IS 配对，注明运行环境和统计来源。

一次推理只读取与所选组合相关的部分：`run.seed`、`datasets.<数据集>`、`rewards.<奖励>`（仅使用奖励的算法）、
`ar` 中除 `algorithms` 外的全部字段，以及 `ar.algorithms.<算法>`。这些“有效设置”连同模型与数据的
哈希、包源码哈希一起决定结果目录的指纹；修改无关部分（例如未使用的奖励）不会使已有结果失效，
`run.draws` 与 `run.hash_cache_dir` 也不参与指纹。

## `settings/inference.json`

### `run`

| 字段 | 类型 | 含义 |
| --- | --- | --- |
| `reward` | `self_certainty` \| `consilience` \| `verifier` | 通用默认奖励，当前为 `self_certainty`。CLI 未传 `--reward`、HTTP 服务及默认性能评测共同读取；与数据集无关。服务支持前两种，verifier 由评测入口提供数据集。旧配置省略此字段时按 `self_certainty` 读取 |
| `seed` | 整数 | 所有随机流的根种子；每题每次抽取的种子由它、抽取序号、算法名和题目 ID 派生 |
| `draws` | 整数 | 每题独立重复次数；大于 1 时汇总报告 pass@k。增加它会在同一目录续跑 |
| `hash_cache_dir` | 字符串 | 大文件 SHA-256 缓存目录（按路径、大小和修改时间失效） |

### `datasets.gsm8k`

| 字段 | 类型 | 含义 |
| --- | --- | --- |
| `path` | 字符串 | 本地 JSONL 路径 |
| `download` | 布尔 | 文件缺失或校验不符时从 `source.url` 下载 |
| `source.url` / `source.sha256` / `source.rows` | 字符串 / 字符串 / 整数 | 官方拆分的地址、SHA-256 与行数；三者都会校验 |
| `selection.count` | 整数或 `null` | 在推理前按种子抽取的题数（保持数据集顺序）；`null` 为全部 |
| `selection.seed` | 整数 | 抽题种子 |
| `prompt_template` | 字符串 | 用户消息模板，`{question}` 恰好出现一次；其余字符（包括 LaTeX 花括号）原样保留 |

评测取最终答案文本中的数值（`####`、`\boxed{}`、“answer is”，否则最后一个数），与参考值按分数比较。

### `datasets.math500`

| 字段 | 类型 | 含义 |
| --- | --- | --- |
| `path` / `download` | 字符串 / 布尔 | 本地文件；缺失时从固定版本下载 |
| `source.repository` / `source.revision` / `source.filename` | 字符串 | Hugging Face 数据集、提交与文件名 |
| `selection.seed` | 整数 | 分层顺序的种子：按学科×难度分组，组内与组间打乱后轮流取题，与答案无关 |
| `selection.minimum_level` | 整数 | 只保留不低于该难度的题 |
| `selection.excluded_ids` | 字符串数组 | 事先排除的题目 ID（如开发时看过的题） |
| `selection.skip` / `selection.count` | 整数 | 跳过顺序中的前 `skip` 题（留作开发），评测随后的 `count` 题 |
| `prompt_template` | 字符串 | 同 GSM8K |
| `judge_timeout_seconds` | 数 | Math-Verify 工作进程单次判定的超时 |

载入时会检查每道题的参考答案能被判定器识别。

### `rewards`

奖励 $`r(x,y)`$ 是逐序列的固定分数；温度 $`\tau`$ 定义目标 $`p(y\mid x)\exp\{r/\tau\}`$。
`best_of_n` 只用奖励排序，因此不读取温度。

| 字段 | 类型 | 含义 |
| --- | --- | --- |
| `verifier.temperature` | 数 | verifier 的温度，两种来源共用 |
| `verifier.source` | `dataset` \| `vote` | `dataset`：数据集判定器对照参考答案（oracle），正确为 1，否则为 0；数据集没有参考答案时改为 `vote`。`vote`：与模型自身答案一致的比例，不读参考答案 |
| `verifier.pool_size` | 整数 | 投票时 `is`/`mh` 的冻结样本池大小；奖励为池中与该答案一致的比例。`best_of_n` 不用池：候选之间投票，得票最多的答案胜出，平票在最高票候选中按种子随机选一个 |
| `self_certainty.temperature` / `score_temperature` / `scope` | 数 / 数 / `thinking` \| `full` | 奖励温度；评分分布温度；评分范围（默认 `thinking`，缺少完整思考段时回退到全序列并记录原因）。取评分段上全词表 $`D_{\mathrm{KL}}(U\Vert p_t)`$ 的均值。vLLM 使用下述 Ascend 标量路径、GPU 融合路径或 `exact_scoring = "transformers"` |
| `consilience.temperature` / `score_temperature` | 数 | 奖励温度；计算 top-$`K`$ 置信度所用的温度 |
| `consilience.scope` | `thinking` \| `full` | 只评思考段（缺少完整思考段时回退到全序列并记录原因）或评全序列 |
| `consilience.top_k` / `window_fraction` / `window_tokens` / `skip_fraction` / `initial_penalty` | 整数 / 数 / 整数或 `null` / 数 / 数 | 置信度窗口：跳过开头 `skip_fraction`，首段与末段各取 `window_fraction`（或固定 `window_tokens`），分数为末段均值减 `initial_penalty` 倍首段均值 |

`self_certainty` 与 `consilience` 读取自回归模型的概率，只用于 `--model ar`。

### `ar.thinking`

思考档位和预算采用 [Qwen3.8-27B 的官方服务规则](https://www.alibabacloud.com/help/zh/model-studio/qwen-api-via-openai-chat-completions)。
配置位于 `settings/inference.json`，CLI 与服务共用；`ar.thinking=null` 表示模型没有这套档位/预算配置。

| 字段 | 当前值 | 含义 |
| --- | --- | --- |
| `reasoning_effort` | `null` | 显式选择档位，与 `budget_tokens` 互斥 |
| `budget_tokens` | `null` | 显式指定 thinking token 上限，按档位阈值选择模板强度 |
| `default_effort` / `default_budget_tokens` | `xhigh` / 131072 | 两项选择均未设置时使用 |
| `effort_budgets` | `low: 4096, medium: 16384, xhigh: 262144` | 显式选择档位时使用的思考预算；按预算反查档位时，取上限不小于预算的最低档 |
| `effort_aliases` | `minimal → low, high/max → xhigh, none → null` | `null` 目标表示关闭思考；预算为 0 也关闭思考生成 |

服务可通过 `reasoning_effort` 或 `thinking_budget` 覆盖配置选择，两者互斥；Anthropic 接口对应
`output_config.effort` 或 `thinking.budget_tokens`。`enable_thinking=false`、`thinking.type=disabled` 和
`reasoning_effort=none` 关闭思考。参数冲突返回 HTTP 400。原始模板参数中的同名设置会被配置校验拒绝。

[模型生成配置](https://huggingface.co/Qwen/Qwen3.8-27B/blob/1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0/generation_config.json)
没有设置输出长度，因此 `ar.max_new_tokens` 默认为 `null`。
[模型配置](https://huggingface.co/Qwen/Qwen3.8-27B/blob/1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0/config.json)
声明原生上下文 262144；`ar.engine.context_window=null` 使用这一容量和引擎实际限制，不启用上下文扩展。
运行时生成总长取剩余上下文、显式配置上限和客户端上限中的最小值。thinking 预算受该总长约束，
显式 `xhigh=262144` 因而无法在原生上下文中完整占满这一额度并同时容纳输入与最终内容。
总长先耗尽时以 `length` 结束；思考预算先耗尽时关闭思考段，使用剩余总长继续最终内容。

实现位于 [`shared/model/thinking.py`](../src/inference_scaling/shared/model/thinking.py) 和
[`arllm/backends/thinking_budget.py`](../src/inference_scaling/arllm/backends/thinking_budget.py)：
预算从原始提示之后累计，包含 IS/MH 已固定的前缀；每次补全继续消耗同一条轨迹的剩余额度。
到限后加入确定性的结束标记，其采样与重评分对数概率均为 0；Consilience 排除标记，只读取思考 token 的统计量。
这定义了有预算约束的基础生成分布，Base、IS 与 MH 使用同一规则；它与无限制生成是不同的目标。
同步和流式生成共用该实现。独立预算要求能识别预填充的思考开始位置；其他格式可设置
`output.thinking_start_text`、`thinking_end_text`、`starts_in_thinking`，或将 `ar.thinking` 设为 `null`。
Transformers 与异步 vLLM 的 beam search 在每条 beam 上执行相同的边界约束。
同步 vLLM 的原生 beam 接口暂不支持该约束，使用该基线时选择上述后端或设置 `ar.thinking=null`。

`trace.generation_budget` / `scaling.generation_budget` 记录原始与有效的 thinking 预算、总长和上下文限制。
以上控制均不改变 M/K/B、奖励温度或词表惩罚。

### `ar.model`

| 字段 | 类型 | 含义 |
| --- | --- | --- |
| `path` | 字符串 | 本地目录或 Hub 模型 ID |
| `revision` | 字符串或 `null` | 固定的 Hub 提交 |
| `weight_sha256` | 对象或 `null` | 权重文件名到 SHA-256 的对象；非空时必须恰好列出检查点的全部权重文件并逐个校验 |
| `adapter` | `null` 或 `{path, revision}` | 叠加在基础模型上的 PEFT 适配器 |
| `tokenizer` / `tokenizer_revision` / `tokenizer_kwargs` | 字符串或 `null` / 字符串或 `null` / 对象 | 独立的 tokenizer 及其参数 |
| `cache_dir` / `local_files_only` / `trust_remote_code` | 字符串或 `null` / 布尔 / 布尔 | Hub 缓存与加载选项 |
| `token_penalty` | `null` 或 `{words, strength}` | 每个词前有空格的小写与首字母大写形式、以及行首的首字母大写形式（只取单个 token 的形式），其 logit 在温度之前减去 `strength`；惩罚后的分布就是模型本身，采样、参考概率与评分都用它（见[算法说明](methods/ALGORITHMS.md#token-penalty)）。vLLM 的原生评分与 `fused_logprobs` 读未惩罚的 logit，所以评分需要 `exact_scoring = "transformers"`，同步引擎也不能做 beam search；`null` 关闭 |

### `ar.engine`

| 字段 | 类型 | 含义 |
| --- | --- | --- |
| `backend` | `transformers` \| `vllm` | 执行引擎 |
| `device` / `dtype` | 字符串 | Transformers 设备与精度；vLLM 使用 `dtype`，精确评分后端同时使用两者 |
| `context_window` | 正整数或 `null` | 输入与输出合计的上下文上限，同时用作 vLLM 的 `max_model_len`；`null` 使用引擎/模型声明值。每个请求扣除实际输入长度后计算可生成空间 |

#### Transformers

下表字段位于 `ar.engine.transformers`。

| 字段 | 类型 | 含义 |
| --- | --- | --- |
| `attn_implementation` / `device_map` / `model_kwargs` | 字符串或 `null` / 字符串、对象或 `null` / 对象 | Transformers 加载选项 |
| `max_score_batch_size` | 整数 | 一个评分批次的最大序列数；批次的填充位置数也不超过它乘以 `score_chunk_size` |
| `score_chunk_size` | 整数 | 长序列评分与前缀预填充的分块长度 |
| `prefix_cache_mib` | 整数 | 前缀 KV 存储的容量（MiB，`0` 关闭）：结束的生成行保存 KV，后续请求从最长的已存前缀接着预填充；结果不变 |
| `in_place_kv` | 布尔 | 解码时把新位置写入预留缓冲区，而不是每步复制整层 KV；结果不变 |
| `cuda_graphs` | 布尔 | 解码步在固定形状上执行：KV 放入常驻缓冲区，行数与关注的位置数取整到 2 的幂，其余部分由掩码屏蔽；CUDA 上每种形状的第一步捕获为 CUDA graph，之后重放（CPU 上走同一路径但不捕获）。结果与动态解码相同，至多差浮点舍入；缓冲区保留到见过的最大批。需要模型在单一设备上、注意力为 `sdpa` 或 `eager` |

#### vLLM

下表字段位于 `ar.engine.vllm`。

| 字段 | 类型 | 含义 |
| --- | --- | --- |
| `asynchronous` | 布尔 | 异步引擎（原生连续批处理）或同步引擎 |
| `async_scheduling` | 布尔或 `null` | 引擎内部的 CPU/GPU 异步调度，与 `asynchronous` 接口选项分开；默认 `null`，由 vLLM 按模型和设备决定。融合统计模式要求 `false` 或 `null`，实际生效值记录在 `engine_execution` |
| `stream_interval` | 正整数 | 默认 `32`；vLLM 保留首 token 与完成通知，其余增量按此 token 间隔交付，减少 Python 输出开销。K>1 的前缀通知因分批最多额外等待 `stream_interval−1` 个 token（队列等待另计）；较短的块可设为 `1`。多 token 停止标记仍由外层增量检测，可能产生边界后的额外解码 |
| `flat_logprobs` | 布尔 | 默认 `true`；直接读取 vLLM 的扁平概率数组，避开逐 token 概率对象，Consilience 的 top-K 归约公式不变；`false` 使用原字典格式作对照 |
| `tensor_parallel_size` / `data_parallel_size` | 整数 | 模型切分卡数 / 引擎数据并行副本数 |
| `gpu_memory_utilization` | 数 | 引擎使用的设备内存比例 |
| `max_num_seqs` / `max_num_batched_tokens` | 整数 | 活跃序列上限 / 每次调度的 token 上限；上下文另由 `context_window` 控制 |
| `quantization` / `enforce_eager` / `max_lora_rank` | 字符串或 `null` / 布尔 / 整数 | 量化方案 / 强制 eager 执行 / 适配器最大秩 |
| `enable_prefix_caching` | 布尔 | 前缀缓存 |
| `fused_logprobs` | 布尔 | 在采样的同一步 logits 上另读出温度 1 的模型下选中 token 的对数概率与分布相对均匀分布的 KL 散度（见[算法说明](methods/ALGORITHMS.md#infra-fused-logprobs)）：`mh_power` 省去基础模型重评分，`self_certainty` 在生成时记录。支持 NVIDIA 的同步和异步接口；需要 vLLM 0.26.x，关闭 vLLM 的内部异步调度，不能与 `token_penalty` 同用；Ascend 不支持此融合 worker |
| `scalar_self_certainty` | 布尔 | 默认 `true`，用于当前昇腾配置。Ascend V1 在处理后的完整 log-probability 上计算全词表 KL，经原生异步输出返回标量；不增加模型前向，支持 token penalty。评分策略须与完整支持集采样一致；与 `fused_logprobs`、beam search 不兼容。硬掩码导致无限 KL 时显式报错；当前适配要求 `enable_reduce_sample=false`。CUDA 或 beam search 需显式关闭此项并选择支持所需统计量的后端 |
| `exact_scoring` | `none` \| `transformers` | 用同一份权重的 Transformers 副本精确评分（生成时读不到的 Consilience 统计量与其他策略的对数概率需要） |
| `parameter_count` | 整数或 `null` | 计算量统计用的参数量；`null` 时从本地 safetensors 读取，跳过纯文本生成不运行的视觉编码器与多 token 预测（MTP）头 |
| `engine_kwargs` | 对象 | 其他引擎参数；不能覆盖上述字段，也不能开启 speculative decoding 或关闭引擎统计（`disable_log_stats`，抢占计数依赖它） |

#### 合批与准入

以下字段位于 `ar.engine`。

| 字段 | 类型 | 含义 |
| --- | --- | --- |
| `continuous_batching.workers` | 整数 | 同时求解的题数；大于 1 时 `is` 的后端按请求归属前向 token 开销，逐题成本仍然保留，其余算法的逐题成本为 `null` |
| `continuous_batching.max_batch_size` / `max_batch_tokens` / `batch_wait_seconds` | 整数 / 整数 / 数 | 合并批的上限与等待时间 |
| `rollout_scheduler.enabled` | 布尔 | 默认 `true`；异步 vLLM 共用一个准入队列，IS 在候选前缀就绪时释放分支。`fused_logprobs = true` 时保留批次生成、仍限制准入；同步 vLLM 与 Transformers 保留原路径。实际路径记录为 `rollout_scheduler = streaming/batch`；详见[调度说明](methods/ROLLOUT_SCHEDULING.md) |
| `rollout_scheduler.max_in_flight` | 正整数 | 默认 `32`；所有调用者共用的原生请求上限，加载时再取它与非空 `vllm.max_num_seqs` 的较小值 |
| `rollout_scheduler.max_prefill_tokens` | 正整数 | 默认 `16384`；尚未产生首 token 的准入请求，其完整提示长度之和的保守预算；超大提示可单独预填充，避免永久饥饿 |
| `rollout_scheduler.kv_high_watermark` | `(0, 1]` | 默认 `0.9`；KV 使用率达到水位后暂缓新请求。它是软限，正在解码的请求继续；空闲时允许一条请求进入，避免陈旧指标阻止进展 |
| `rollout_scheduler.policy` | `fair_lpt` \| `fifo` | 默认 `fair_lpt`：优先等待过久的任务，否则先平衡各题活动请求数、再推进候选前缀，再按预计剩余长度从长到短准入；预测只使用长度上限与已完成请求的长度历史 |
| `rollout_scheduler.aging_seconds` | 正数 | 默认 `2.0`；等待超过此时间后按等待先后准入，并允许突破长尾预填充保护；不突破并发上限或丢弃样本 |
| `rollout_scheduler.tail_prefill_tokens` | 正整数 | 默认 `4096`；一轮已释放所有分支、没有待准入请求且仅余至多两条活动请求时，暂缓其他题超过此提示长度的新预填充，直到尾部完成或待办老化 |

生成概率固定使用 `processed_logprobs`，包含采样温度、词表惩罚及 top-k/top-p 的处理。
Ascend 后端在 V1 worker 初始化时同步两级采样器的概率模式，保留原生生成路径和自定义 `worker_extension_cls`。
该适配要求 V1 `AscendSampler` 且 `enable_reduce_sample=false`；不兼容的配置显式报错。
提示词概率仍为原始模型概率，其他策略的精确重评分沿用 `exact_scoring` 设置。

### `ar.prompt`、`ar.output`、`ar.sampling`

| 字段 | 类型 | 含义 |
| --- | --- | --- |
| `prompt.system` | 字符串或 `null` | 系统消息 |
| `prompt.format` | `auto` \| `chat` \| `plain` | 使用 chat template、强制使用，或直接用用户文本 |
| `prompt.chat_template_kwargs` | 对象 | 传给 chat template 的其他参数；启用 `ar.thinking` 时，effort 与预算在该节设置，思考开关在 `output.thinking_mode` 设置 |
| `output.thinking_mode` | `auto` \| `enabled` \| `disabled` | 思考模式；`enabled` 时未完成的思考没有最终答案（评测文本为空） |
| `output.thinking_start_text` / `thinking_end_text` / `starts_in_thinking` | 字符串或 `null` / 字符串或 `null` / 布尔或 `null` | 显式的思考段标记；为 `null` 时从 tokenizer 词表与 chat template 识别 |
| `output.sampling_scope` | `full` \| `thinking` | `mh`、`mh_power`、`is` 在完整输出或思考段上采样；思考段结束后由基础模型生成最终内容。读取答案文本的 `verifier` 会回退到 `full` 并记录原因 |
| `sampling.temperature` / `top_p` / `top_k` | 数 / 数 / 整数或 `null` | 基础策略。`mh`、`mh_power`、`is` 的目标需要完整支持集（`top_p = 1`、`top_k = null`） |

### `ar.algorithms`

| 字段 | 含义 |
| --- | --- |
| `sample`、`greedy` | 无参数：单次采样；贪心解码 |
| `beam.num_beams` | beam 宽度 |
| `best_of_n.samples` | 候选数 |
| `mh_power.alpha` | 幂目标 $`p^\alpha`$ 的指数 |
| `mh_power.proposal_temperature` | 后缀 proposal 相对基础策略的温度（常用 $`1/\alpha`$） |
| `mh_power.block_size` / `steps_per_block` / `iterations` | 分段延长的块长与每段更新数；`iterations` 非空时在完整长度上做固定次数更新 |
| `mh_power.suffix_schedule` | `uniform` \| `inverse_length` \| `multiscale` \| `log_uniform`；分别为均匀、长度倒数、偏向 2 的幂长度、按 2 的幂区间等量分配概率 |
| `mh.block_size` / `steps_per_block` / `iterations` / `suffix_schedule` | 同上，目标为 $`p\exp\{r/\tau\}`$ |
| `mh.ensemble_size` | 默认 `1`，保持单链 MH。大于 `1` 时保留该数量的完整序列，每轮更新全部候选的后缀，最后按权重抽样；要求显式设置 `iterations`、`proposal = "base"`、`suffix_replay = false`。`iterations` 是整池更新轮数，总生成阶段数为 `1 + iterations`，此时 `block_size` 与 `steps_per_block` 不分配更新预算。见[完整候选池](methods/ALGORITHMS.md#ensemble-mh) |
| `mh.execution` | 默认 `batch`，逐轮批量生成。`pipeline` 在流式后端中重叠已确定源状态的跨轮请求，保持相同逻辑更新；要求 `ensemble_size > 1`、`initialization = "iid"`，关闭 `stratified_updates` 和 `nonself_updates`。非流式后端继续使用 `batch`，实际方式写入 trace；[调度条件与收益来源](methods/ALGORITHMS.md#ensemble-pipeline) |
| `mh.initialization` | 默认 `iid`，首轮候选独立采样。`stratified` 将序列累计概率区间等分，每层独立生成一条，再随机排列槽位；后续 MH 不变。要求 `ensemble_size > 1` 和 vLLM Ascend 后端，其他后端显式拒绝；样本均值方差不增、候选覆盖概率不降，不保证每例输出误差或耗时更低。见[分层初始化](methods/ALGORITHMS.md#ensemble-initial-strata) |
| `mh.stratified_updates` | 默认 `false`。要求 `initialization = "stratified"` 和 `ensemble_size > 1`；每层固定一个槽位，后续从同层整条重生成，或从区间约束已解除的前缀开始局部更新，使用修正后的切点概率。最终输出的平稳目标不变，有限预算误差与耗时可能增减。见[持续分层](methods/ALGORITHMS.md#ensemble-persistent-strata) |
| `mh.nonself_updates` | 默认 `false`。要求 `ensemble_size > 1`、`stratified_updates = false` 及 vLLM Ascend 采样适配；后缀 proposal 排除原序列，直接抽取第一次分歧，使用正反条件概率修正接受率。可与首轮分层结合，保持同一平稳目标；[算法及有限预算边界](methods/ALGORITHMS.md#ensemble-nonself) |
| `mh.proposal` | `base`（基础策略后缀）或 `frozen_history`（冻结历史混合 proposal） |
| `mh.frozen_history.samples` / `mixture` | 历史样本数；从历史后缀提议的概率 |
| `mh_power.early_rejection` | 先抽接受用的均匀数，proposal 一旦不可能被接受就停止生成（见[算法说明](methods/ALGORITHMS.md#mh-early-rejection)）：链与关闭时逐步相同，被拒 proposal 的尾部不再生成；要求 `proposal_temperature` 在 $`[1/\alpha,1]`$ 内，需要 `ar.engine.backend = transformers` |
| `mh.suffix_replay` / `mh_power.suffix_replay` | 把当前后缀作为草稿交给后端重放（见[算法说明](methods/ALGORITHMS.md#mh-suffix-replay)）：proposal 与关闭时逐 token 相同，与当前后缀相同的开头部分不调用模型；需要 `ar.engine.backend = transformers` |
| `is.candidate_count` / `rollout_count` / `block_size` | 首轮候选数 M、每候选补全数 K 与块长 B，默认 4 / 1 / 1024；两阶段模式在后续轮次重分配探索预算。块长在输出上限处截短 |
| `is.exploration_schedule` | 默认 `two_stage`：将首轮后的探索合并为一个完整后缀池，按未选 rollout 的长度与权重分配预算，并限制并发容量及长度区间。`fixed` 保留为显式选项与 CPU 参考。[100 题对照](reports/QWEN38_IS_SELECTION.md)用于默认方案选择，未建立跨任务及长预算的普遍优势。见[两阶段探索](methods/ALGORITHMS.md#is-two-stage) |
| `is.selection_ready` | 默认 `true`：首轮以完整组权重和固定随机优先级提前选择，末轮复用固定 SIR 随机数；未完成权重由缓存前缀估计，存在选择偏差。仅支持流式 `two_stage`、`block_first=false` 和可读取缓存前缀分数的奖励。`false` 等待完整权重；非流式后端、verifier 或完整池选择核需关闭此项。见[选择条件](methods/ALGORITHMS.md#is-selection-ready) |
| `is.selection` | 默认 `sir`；`metropolized` 对完整 rollout 索引做一次 Metropolized 更新，`block_metropolized` 先合并同块质量再选择补全。两个可选核均要求 `selection_ready=false`，不额外生成或评分；端到端成本仍会因后续选中轨迹改变。见[选择核](methods/ALGORITHMS.md#is-metropolized)。旧设置文件省略此字段时按 `sir` 读取 |
| `is.block_first` | 新候选先只生成一块，再发第一条续写请求（见[算法说明](methods/ALGORITHMS.md#alg-conditional-is)）。默认 `false` 配合流式调度即可在 B 处释放其他分支，原请求继续为第零条补全；调度器不会更改此设置或重置原请求随机流 |

<a id="ar-defaults"></a>
### 默认 AR 配置

仅预设 [Qwen3.8-27B](https://huggingface.co/Qwen/Qwen3.8-27B)，当前取值如下。同组字段省略重复前缀；
详细含义与后端约束见上文，默认算法的选择依据见[100 题对照](reports/QWEN38_IS_SELECTION.md)。

| 设置 | 当前值 |
| --- | --- |
| `run.reward` | `self_certainty`；思考段均值，奖励温度 0.25、评分温度 1 |
| `ar.model` | 固定权重版本，BF16；首次下载约 55.6 GB |
| `ar.model.token_penalty` | wait、hmm、alternatively、actually、however、but、maybe、perhaps，强度 1 |
| `ar.engine.backend` / `device` / `dtype` | `vllm` / `npu` / `bfloat16` |
| `ar.engine.vllm` | 内存比例 0.92、最多 32 条序列、调度 token 上限 16384；Ascend 全词表标量统计开启 |
| `ar.engine.continuous_batching.workers` | 1；并发 IS 使用请求级成本归属 |
| `ar.engine.context_window` / `ar.max_new_tokens` | 均为 `null`，分别读取原生上下文与剩余生成空间 |
| `ar.thinking` / `ar.output` | 默认 xhigh、131072 思考预算；启用思考、IS/MH 作用于思考段 |
| `ar.sampling` | 温度 1、完整支持集 |
| `ar.algorithms.is` | M=4、K=1、B=1024；`two_stage`、`selection_ready=true`、`sir`、`block_first=false` |
| `ar.algorithms.mh` / `mh_power` | 块长 1024，每块 3 次更新，均匀后缀；重放与提前拒绝关闭 |

部署时按设备容量设置 TP/DP，校验权重、缓存、原生上下文与并发的总内存需求。
`language_model_only=true` 只加载文本部分；FLOPs 按实际运行的 26,895,998,464 个参数估算。
混合模型前缀缓存的兼容性异常需关闭 `enable_prefix_caching` 并复核输出。
词表惩罚作用于思考和最终内容，其独立质量与速度收益尚未在该模型上验证。

### `serve`

位于同一个 `settings/inference.json`；只配置 HTTP 服务行为。生成参数继承 `ar` 与 `rewards[run.reward]`，
随机流使用 `run.seed`。思考设置继承 `ar.thinking`，没有另一套服务默认值。

| 字段 | 类型 | 含义 |
| --- | --- | --- |
| `server.host` / `port` / `served_model_name` | 字符串 / 整数 / 字符串 | 监听地址与 `/v1/models` 报告的模型名（请求里的模型名不做校验） |
| `server.max_concurrent_requests` | 整数 | 同时推理的请求数；各请求共用一个引擎的连续批处理，超出的请求排队 |
| `server.keepalive_seconds` | 数 | 流式请求在搜索期间发送 keep-alive 的间隔 |
| `max_seconds` | 正数或 `null` | 默认 `null`，只按逻辑长度、EOS/思考边界完成。设为数值后，超时不再开始新的 IS 步，至少完成第一步，进行中的一步与答案仍完成；不是请求总时长硬限，启用后可能改变有限步输出分布 |

请求的 `max_tokens` 或 `max_completion_tokens` 限制 thinking 与内容的合计长度；受显式配置上限和剩余上下文约束。
两者同时传入时须相等，非正整数返回 HTTP 400。独立思考预算与别名见 [`ar.thinking`](#arthinking)。
