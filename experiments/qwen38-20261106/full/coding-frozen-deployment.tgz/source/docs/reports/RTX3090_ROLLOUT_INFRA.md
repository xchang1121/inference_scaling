# 推理成本与执行效率：RTX 3090 与 CPU 调度验证

本报告比较批处理、rollout 复用、MH proposal、奖励调度与固定采样树调度的执行成本；准确率见
[算法质量报告](GSM8K_3090_ALIGNED_RESULTS.md)，机制与成本口径见[算法文档](../methods/ALGORITHMS.md#alg-runtime)。
第 1–5 节记录统一入口之前的 RTX 3090 实验，数字按当时的实现测得。标注“旧方法”
的机制已归档，保留其结论；第 7 节说明当前入口的机制重测方式。
第 6 节记录 2026-10-16 实现的 rollout 调度，以及 CPU 上的分布验证和虚拟时延实验。

RTX 3090 实验的主模型为 Qwen2.5-1.5B-Instruct，旧方法的辅助模型为 Qwen2.5-0.5B-Instruct，硬件为单张 RTX 3090 24 GiB，
后端为 Transformers。其成本比统一为“实验路径 / 本组基线”，小于 1 表示成本下降；墙钟不含模型与数据加载，建库与后台
收尾单列。FLOPs 按“2 × 参数量 × 实际前向 token 位置数”估算，覆盖预填充、生成、重评分与草稿验证，不含注意力的
长度平方项；“±”为三个随机种子的样本标准差。

<a id="infra-report-batching"></a>
## 1. 连续批处理

32 道题、同一方法与请求种子，比较逐题执行与 8 个题目并发共享后端。

- **连续批处理主要提高设备利用率。** 基础采样的墙钟下降 79%（每秒完成题目数约为 4.85 倍），多数投票-8 下降 50%，
  条件 IS 只下降 13%（0.5B 补全的旧方法下降 5%），受候选、补全与选择之间的阶段依赖限制。
- 填充增加参与前向的 token 位置数，墙钟下降可能伴随 FLOPs 上升（基础采样为 1.18 倍）。

<a id="infra-report-warm-replay"></a>
## 2. 旧方法：IS 的历史复用与候选缓存

replay 从历史库读取与当前条件匹配的 rollout（每条最终估计记录只用一次），再加入新样本校正；候选缓存直接复用建库时
已生成的同一组基础模型候选。

- **已有匹配历史时在线成本下降，为当前请求新建历史则更贵。** 32 题上，已有历史时在线 FLOPs 下降 23%、墙钟下降 14%；
  建库加首次查询的 FLOPs 为纯新生成的 2.34 倍、墙钟 1.81 倍。
- **候选缓存与批处理可以叠加。** 4 题组合实验中，候选缓存相对逐题 replay 的墙钟比为 0.70，完整组合相对批处理纯新
  生成的在线墙钟比为 0.75、1.5B FLOPs 比为 0.74，平均 rollout 复用率 31.6%；计入建库后首次查询的墙钟比为 1.36、
  总 FLOPs 比为 1.94。各组对照逐 token 一致。

<a id="infra-report-mh"></a>
## 3. MH 后缀与冻结历史 proposal

- **短后缀减少串行生成。** 32 题 × 4 次、最长 128 token 的幂目标 MH 中，相对均匀后缀，长度倒数与多尺度后缀分别
  减少 50% 与 32% 的生成 token，墙钟降为 0.54 与 0.59 倍。当时每次提议都重新预填充保留的前缀，FLOPs 基本不变；
  当前的前缀 KV 存储复用这部分计算。
- **冻结历史 proposal 以评分替代部分后缀生成。** 1 题、4 条链、30% 基础模型加 70% 冻结历史的混合 proposal（正反
  混合概率都进入 Hastings 比）：与多尺度后缀组合时，在线墙钟为“基础模型 / 均匀后缀”的 0.36 倍，主模型 FLOPs
  基本不变，接受率从 61% 升至 80%；建库平均 0.66 s，计入后首次查询墙钟仍低于基线，计算量略高。

<a id="infra-report-streaming"></a>
## 4. 奖励调度与补全复用

![IS 与 MH 复用优化的墙钟比和主模型 FLOPs 比](../assets/rtx3090_is_mh_reuse.svg)

图 1：左侧为墙钟比，右侧为主模型 FLOPs 比，均为三个随机种子的成对比值均值，虚线 1 表示本组基线。除冻结历史 MH
外，各行均为旧方法：部分续跑对比从头生成，流式 IS 对比整批生成后评分，历史草稿对比普通解码，MH 各行对比同设置下
的基础模型 proposal。

单题 BF16 诊断，奖励为人工 token 判定；延迟由奖励计算后人工等待 0.2 s 构造。

- **旧方法：奖励重叠。** 流式 IS 在 0.2 s 延迟下墙钟比为 0.67，计算量不变；近零延迟时为 1.03。收益来自隐藏评分等待。
- **旧方法：MH 预取。** 有延迟时墙钟比 0.82，但 FLOPs 增加 27%；近零延迟时墙钟与 FLOPs 均增加。
- **旧方法：两阶段接受。** 墙钟比 0.83，精确奖励调用降至 0.56 倍；该结果依赖理想近似奖励。
- **旧方法：部分续跑。** 新生成 token 减少 23%，却因重复预填充使 FLOPs 增至 3.35 倍。
- **历史复用。** 旧方法随机历史草稿的墙钟比为 0.98，收益很小；冻结历史 MH 的在线墙钟比为 0.53、FLOPs 比 1.00，
  计入建库后墙钟比 0.59、FLOPs 比 1.07。

![历史草稿、分阶段估计与 SMC 后缀复用的在线墙钟](../assets/rtx3090_rollout_infra.svg)

图 2：柱高为三个种子的平均在线墙钟，误差线为样本标准差。左侧以普通解码为基线；右侧比较固定条件 IS 与两阶段估计，
以及同一 SMC 的纯新生成与条件后缀复用。以下均为旧方法（1 题、BF16、最长 64 token、块长 16）。

- **历史 token 树草稿需要按负载启用。** 始终使用时墙钟从 3.84 s 增至 8.30 s、FLOPs 1.66 倍；只在批量 1 时启用为
  3.78 s、FLOPs 1.01 倍。
- **两阶段估计没有收益。** 先用独立初始样本分配预算的两阶段估计为 5.31 s，高于固定 IS 的 3.44 s，FLOPs 1.55 倍；
  加入流式与预生成为 5.60 s。
- **SMC 后缀复用略有收益。** 复用匹配前缀的补全后在线墙钟从 2.99 s 降至 2.57 s（成对比 0.86），FLOPs 比 0.96。
- **0.5B 草稿模型未取得加速。** 草稿长 2 时接受率 86.5%，相对普通 1.5B 生成的墙钟比 1.06、FLOPs 比 1.44。

## 5. 算法配置的成本分解

<a id="infra-report-rescoring"></a>
- **旧方法：0.5B 补全与主模型重评分。** 省略 1.5B 重评分后，自一致性组与正确性组的 FLOPs 分别降至 23.9% 与 26.0%，
  同时改变条件权重的目标；正确性组成对运行的墙钟反而从 476.5 s 增至 556.2 s，因为生成 token 增加而批量评分的并行度
  高于逐 token 生成。
- <a id="infra-report-dynamic"></a><a id="infra-report-budget"></a>**旧方法：动态候选与方差—成本分配。** 已有历史时，
  动态候选相对基础候选的在线 FLOPs 比为 0.92、墙钟比 1.00；方差—成本分配的设计阶段开销大，最终 rollout 复用率只有
  5.7%（动态固定组 34.9%）。
- <a id="infra-report-training"></a>**训练与推理成本需要一并比较。** 该 GRPO 检查点训练消耗 15.6 PFLOPs、500 万个前向
  等价 token 位置和 9,545 s；32 题单次评测中，GRPO 随机采样、基础采样、条件 IS 与幂目标 MH 的推理计算量分别为 0.025、
  0.028、1.37、1.31 PFLOPs。条件 IS 的单次准确率点估计接近 GRPO，对应约 54 倍的训练后推理 FLOPs。

总体上，连续批处理主要提高设备利用率，候选缓存与已有历史减少在线生成，冻结历史 MH 以评分替代部分串行生成，奖励
调度的收益依赖可重叠的等待时间。选择方案时应同时比较墙钟、各模型的 FLOPs 以及当前请求实际承担的建库与设计成本。

<a id="infra-report-rollout-scheduling"></a>
## 6. 固定采样树的 rollout 调度

本组使用完整候选池、关闭提前选择。异步 vLLM 的准入队列保持 M/K/B、请求编号与种子、奖励及选择规则，
在前缀就绪时释放补全分支，通过安排执行顺序减少等待。

- **前缀就绪即释放分支。** 新候选生成到 B 个 token 后立即提交 K−1 条补全，原生请求持续生成第零条补全；
  保留候选的额外补全在本轮开始时提交。所有规定叶子完成后，按固定候选与叶子编号计算权重和选择。
- **共享资源准入。** 同一引擎的多个调用者、候选、补全和评分共用原生请求上限；预填充 token 预算和 KV 高水位
  控制新请求进入。加载时将配置上限与 vLLM 的 `max_num_seqs` 对齐。
- **长尾与公平调度。** 先平衡各题活动请求数，再推进候选前缀，并把预计较长的请求提前。长度预测使用请求上限和
  已完成请求的长度历史；等待老化保障队列推进，尾部保护暂缓其他题的大预填充，让最后几条 rollout 完成解码。
- **流式统计与评分。** 前缀统计随事件更新，叶子完成即可评分，保留叶子奖励直接复用。实现覆盖思考边界、EOS、
  同一引擎上的生成与评分，以及错误时的取消和资源释放。
- **逻辑停止。** 服务档位默认 `max_seconds = null`，按长度、EOS 和思考边界停止。运行记录与服务响应通过
  `rollout_scheduler = streaming/batch` 标明实际路径，服务响应另用 `stopping_policy = logical/wall_clock` 标明停止方式。

`ar.engine.rollout_scheduler` 默认启用：`max_in_flight = 32`、`max_prefill_tokens = 16384`、
`kv_high_watermark = 0.9`、`aging_seconds = 2.0`、`tail_prefill_tokens = 4096`、`policy = fair_lpt`。
异步 vLLM 的常规统计模式使用流式路径，融合统计模式使用批次路径和共享准入。
完整配置见[设置说明](../SETTINGS.md#arengine)，执行过程与分布推导见[调度说明](../methods/ROLLOUT_SCHEDULING.md)。

CPU 模拟复用生产实现的准入队列，比较完整算法的候选、叶子、奖励、权重、选择和最终序列：

| 检查 | 规模 | 结果 |
| --- | --- | --- |
| 完整生成配对 | 两种 `block_first` × 并发 1/2/8 × FIFO/fair-LPT × 500 个种子，共 6,000 组 | 逐次完全相同，输出直方图 TV=0；覆盖服务时间与生成内容相关的场景 |
| 条件转移核穷举 | 二 token、二元词表、M=K=2，6 种调度 | 调度前后矩阵最大差 0，`max(abs(πP−π)) = 1.11×10⁻¹⁶` |
| 从精确目标初始化的完整 IS | 三 token、二元词表、M=K=2，6,000 组配对 | 逐次完全相同，经验分布与枚举目标 TV≈0.00697 |
| 时延实验配对 | 两种负载 × 五种并发 × 64 个种子，共 640 组 | 结果全部相同，峰值并发满足配置上限 |

合计 12,640 组配对结果完全一致，穷举检查验证原条件核的目标不变性。

虚拟时延比较一轮 M=6、K=4、B=8 的采样树：基线等待全部候选完成后再提交额外补全，新路径在前缀就绪时提交补全。
固定长度负载为每条序列 64 token；长尾负载按首 token 选择 EOS 概率 0.008 或 0.08，长度上限 192。
每 token 解码为 1 ms，每个提示 token 预填充为 0.02 ms。表中加速为同一组 64 个种子的“基线平均时延 / 调度后平均时延”。

| 并发上限 | 固定长度平均加速 | 长尾平均加速 | 长尾基线 P95 / s | 长尾调度后 P95 / s |
| ---: | ---: | ---: | ---: | ---: |
| 1 | 1.000× | 1.000× | 1.07331 | 1.07331 |
| 2 | 1.000× | 1.087× | 0.56668 | 0.54229 |
| 4 | 1.159× | 1.276× | 0.40777 | 0.33964 |
| 8 | 1.317× | 1.489× | 0.37616 | 0.21502 |
| 16 | 1.465× | 1.553× | 0.37616 | 0.19216 |

本次 640 棵树的完成时间全部持平或缩短。完整数据、实验环境与集成覆盖见
[CPU 验证报告](ROLLOUT_SCHEDULING_CPU.md)及其 [JSON 数据](ROLLOUT_SCHEDULING_CPU.json)。

<a id="infra-cpu-output"></a>
### 6.1 CPU 输出层开销

2026-10-18 在 Windows、i7-12700K、Python 3.12.5 上比较原字典/逐 token 输出与紧凑输出，均不加载模型、不执行 GPU 前向。
概率构造与解析使用 8,192 个位置、top-K=5，覆盖采样 token 位于 top-K 内外；请求交付使用同一组
8,192 / 4,096 / 2,048 / 1,024 token 的四条请求。表中时间为预热后 5 次运行的中位数，
内存为单独运行时 `tracemalloc` 测得的峰值 Python 分配。

| 指标 | 原输出路径 | 紧凑输出路径 | 变化 |
| --- | ---: | ---: | ---: |
| 概率数据构造与解析 | 25.04 ms | 9.08 ms | 2.76× |
| 概率处理峰值 Python 分配 | 6.42 MiB | 2.51 MiB | −60.9% |
| 四请求模拟、交付与解析 | 295.71 ms | 100.28 ms | 2.95× |
| 引擎输出增量数 | 15,360 | 484 | −96.8% |
| 向外层交付的事件数 | 480 | 4 | −99.2% |
| 请求 token 总数 | 15,360 | 15,360 | 相同 |

生成 token、采样概率、逐 token 统计量、Consilience 算术结果及请求成本计数逐项一致。
K=1/2/4 的完整 IS 对照覆盖两种分块方式；thinking 对照覆盖单 token、多 token 标记、空块后继续生成和统计量复用。
首 token 通知仍释放预填充额度，终态交付不使多请求退化为串行。
另用 vLLM 0.25.0/0.26.0 的原始 `FlatLogprobs` 容器检查 top-K=1/2/5，合计 6,144 个位置及
192 份 32-token 分块的采样概率和统计量与字典路径精确一致；该检查只执行容器代码，无模型加载。

这些数据衡量 CPU 输出处理开销。完整模型的墙钟时间还包含前向计算，实际 GPU 加速比例、低并发解码速度与
P95 长尾时延需要在部署机器测量。算法仍等待全部规定的完整 rollout，目标分布和有限步 IS 选择规则沿用原实现。
原理与代码索引见[输出交付与概率处理](../methods/ROLLOUT_SCHEDULING.md#compact-output)。

安装仓库的 `[dev]` 依赖后运行 `python scripts/benchmark_vllm_output.py --tokens 8192 --repeats 5`。
脚本复用 CPU 测试后端，只向终端输出结果，不产生原始数据文件。

## 7. 复现

每条记录的 `cost` 按阶段给出前向 token 位置数与 FLOPs，结果目录的 `summary.json` 汇总墙钟与成本。模型、引擎与
长度先按[算法质量报告第 6 节](GSM8K_3090_ALIGNED_RESULTS.md#quality-reproduction)改回。旧方法没有对应命令。

| 机制 | 命令 | 设置改动 |
| --- | --- | --- |
| 连续批处理 | `python -m inference_scaling --algorithm sample`（或 `best_of_n`、`is`，加 `--reward verifier`） | `ar.engine.continuous_batching.workers = 8`，对照为 1；多数投票设 `rewards.verifier.source = "vote"` |
| 后缀长度分布 | `--algorithm mh_power` | `suffix_schedule` 三选一；`ar.max_new_tokens = 128`、`block_size = 16`、`steps_per_block = 2`、`run.draws = 4` |
| 冻结历史 proposal | `--algorithm mh --reward verifier` | `ar.algorithms.mh.proposal = "frozen_history"`，对照为 `"base"`；组合时再设 `suffix_schedule = "multiscale"` |
| 训练成本 | [归档训练入口](https://github.com/xchang1121/inference_scaling/tree/archive/legacy-dllm-training-is) | 读取训练输出中的 `training_cost.json` |

Rollout 调度的 CPU 模拟和集成测试：

```bash
python scripts/simulate_rollout_scheduling.py --trials 500 --stationary-trials 6000 --latency-trials 64
python -m pytest tests/test_rollout_scheduler.py tests/test_streaming_vllm.py tests/test_backend_loader.py tests/test_serve.py -q
```

异步 vLLM 的 IS 入口为 `python -m inference_scaling --algorithm is --reward consilience`；
设 `selection_ready=false`、`exploration_schedule="fixed"`，用 `ar.engine.rollout_scheduler.enabled` 切换流式调度，
用 `policy=fifo/fair_lpt` 比较准入策略。Consilience 的评分温度与采样温度保持一致。

与当时实现的差异：冻结历史与后缀对照当时用人工奖励（末 token 奇偶）在单题上测成本，当前命令用正式奖励在 GSM8K 上
测量同一机制。
