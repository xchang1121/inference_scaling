#!/usr/bin/env bash
set -euo pipefail
replica=$1
expected=$2
case "$replica" in
  a) old_skip=20; new_skip=50 ;;
  b) old_skip=35; new_skip=85 ;;
  *) exit 2 ;;
esac
code=/deployment/selection-met-sc-20261103/source
out=/results/selection-met-sc-20261103
cd "$code"
test "$(git rev-parse HEAD)" = "$expected"
test -z "$(git status --porcelain)"
test ! -e "$out/$replica-old.jsonl"
test ! -e "$out/$replica-new.jsonl"
export PYTHONPATH="$code/src:${PYTHONPATH:-}"
if [ "$replica" = b ]; then
  export PYTHONPATH="/cache/engine/vllm:/cache/engine/vllm-ascend:$PYTHONPATH"
fi
export VLLM_USE_V2_MODEL_RUNNER=0
mkdir -p "$out"
mkdir "$out/$replica.started"
finish() { status=$?; printf '%s\n' "$status" > "$out/$replica.exit"; }
trap finish EXIT
for cohort in old new; do
  if [ "$cohort" = old ]; then skip=$old_skip; count=15; else skip=$new_skip; count=35; fi
  test ! -e "$out/$replica-$cohort.jsonl"
  set +e
  /cache/venv/bin/python -u scripts/benchmark_is_gpu.py \
    --settings "/deployment/selection-rewards-20261103/settings-$replica.json" \
    --study selection-self-certainty \
    --modes met-k1-self-certainty met-k2-self-certainty block-met-k2-self-certainty \
    --dataset math500 --questions "$count" --selection-skip "$skip" --repeats 1 \
    --label "selection-sc-tp2-$replica-$cohort" --output "$out/$replica-$cohort.jsonl" \
    > "$out/$replica-$cohort.log" 2>&1
  status=$?
  set -e
  printf '%s\n' "$status" > "$out/$replica-$cohort.exit"
  if [ "$status" -ne 0 ]; then exit "$status"; fi
done
