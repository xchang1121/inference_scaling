"""Validate frozen settings, source and native engine paths without loading weights."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

replica, expected = sys.argv[1:]
source = Path('/deployment/selection-met-sc-20261103/source')
sys.path[:0] = (["/cache/engine/vllm", "/cache/engine/vllm-ascend"] if replica == 'b' else []) + [str(source), str(source/'src')]
os.chdir(source)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == expected
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
settings_path = Path('/deployment/selection-rewards-20261103') / f'settings-{replica}.json'
digests = {'a': '5dc7de5810eca6a5e19f8294e6e3fb60ac8c2e4b94c0b386036a505387264527',
           'b': 'fc7b4493daba0b12e869645b0707c266cec908673909fac51ba68bb91d14127e'}
assert hashlib.sha256(settings_path.read_bytes()).hexdigest() == digests[replica]
engines = {}
for module, commit in [('vllm', '0fc695fc6d1d82e9a5ac6835ac8e4e1c83703665'),
                       ('vllm_ascend', '5cb98caaadeff42b5b62b996e34bb2aaa29d20fd')]:
    spec = importlib.util.find_spec(module)
    assert spec is not None and spec.origin is not None
    root = Path(spec.origin).parent.parent
    if replica == 'a':
        found = subprocess.check_output(['git', '-c', f'safe.directory={root}', '-C', str(root),
                                         'rev-parse', 'HEAD'], text=True).strip()
        assert found == commit, (module, root, found)
    else:
        assert str(root) == ('/cache/engine/vllm' if module == 'vllm' else '/cache/engine/vllm-ascend')
    files = ({'vllm/v1/worker/gpu_model_runner.py': '6250ca0670c4593aa2f7c4567c9c71d6cb3d8182624a985d4d4e33d5bf054666',
              'vllm/v1/sample/sampler.py': '9ca3253163a1698764c599386c68e71962d2654427d0c50bc5c519384347b465'}
             if module == 'vllm' else
             {'vllm_ascend/sample/sampler.py': 'f1b6155f9ae25678705cba9fe639283c48e15882c1e4aa722ae06dce68991d54'})
    assert all(hashlib.sha256((root/file).read_bytes()).hexdigest() == digest for file,digest in files.items())
    engines[module] = {'path': str(root), 'source_revision': commit,
                       'verification': 'git and file hashes' if replica == 'a' else 'exported source file hashes'}

from inference_scaling.app.settings import load_settings
from scripts.benchmark_is_gpu import select_mode
from types import SimpleNamespace
settings = load_settings(settings_path)
assert settings['ar']['engine']['vllm']['scalar_self_certainty']
assert settings['ar']['engine']['vllm']['asynchronous']
assert settings['ar']['engine']['vllm']['tensor_parallel_size'] == 2
family = SimpleNamespace(ar=settings['ar'])
for mode, k, selector in [('met-k1-self-certainty', 1, 'metropolized'),
                          ('met-k2-self-certainty', 2, 'metropolized'),
                          ('block-met-k2-self-certainty', 2, 'block_metropolized')]:
    select_mode(family, mode, settings)
    assert family.config['rollout_count'] == k and family.config['selection'] == selector
    assert family.config['candidate_count'] == 4 and family.config['block_size'] == 1024
    assert not family.config['selection_ready']
    assert family.choices.reward == 'self_certainty'
    assert family.reward_settings == {'temperature': .25, 'score_temperature': 1, 'scope': 'thinking'}
print(json.dumps({'preflight': 'passed', 'replica': replica, 'source': expected,
                  'settings_sha256': digests[replica], 'engines': engines,
                  'model_loaded': False}))
