
import base64,json,subprocess
from pathlib import Path
root=Path('/data/disk/changxiangyu/agentic_scaling')
dep=root/'deployment/ascend/coding-bench-20261104'
cmd=['docker','exec','-e','PYTHONPATH=/deployment/coding-bench-20261104/source/src','-w','/deployment/coding-bench-20261104/source','agentic-scaling-changxiangyu-selection-b','/cache/venv/bin/python','-m','pytest','tests/test_coding_benchmark.py','tests/test_compute_accounting.py','-q']
p=subprocess.run(cmd,text=True,capture_output=True,timeout=100)
(dep/'preflight-pytest.txt').write_text(p.stdout+p.stderr);print(json.dumps({'pytest_exit':p.returncode,'summary':p.stdout[-400:]}))
out=root/'results/coding-bench-20261104/evaluation';out.mkdir(parents=True,exist_ok=True)
cmd=['docker','run','--rm','--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges','--pids-limit','512','--cpus','4','--memory','8g','--shm-size','1g','--tmpfs','/tmp:rw,size=2g','--user','1002:1002','--mount',f'type=bind,src={dep},dst=/study,readonly','--mount',f'type=bind,src={out},dst=/out','-e','PYTHONDONTWRITEBYTECODE=1','-e','OMP_NUM_THREADS=1','-e','OPENBLAS_NUM_THREADS=1','-e','PYTHONPATH=/study/source/src:/study/source/scripts:/study/vendor/evalplus:/study/vendor/LiveCodeBench','agentic-scaling-qwen38-runtime:20261102','python3','/study/source/scripts/judge_coding.py','--data','/study/frozen/judge-data.json','--manifest','/study/frozen/public-manifest.json','--output','/out/self-test.json','--self-test']
p=subprocess.run(cmd,text=True,capture_output=True,timeout=180)
(dep/'preflight-judge.txt').write_text(p.stdout+p.stderr);print(json.dumps({'judge_exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr[-1800:]}))
