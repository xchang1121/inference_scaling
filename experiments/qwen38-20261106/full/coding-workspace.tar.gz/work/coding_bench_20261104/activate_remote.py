"""Install the frozen bundle and start one host's resource-aware experiment queue."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import tarfile

root = Path('/data/disk/changxiangyu/agentic_scaling')
replica = {1006: 'a', 1002: 'b'}[os.getuid()]
dep = root / 'deployment/ascend/coding-bench-20261104'
out = root / 'results/coding-bench-20261104'
bundle = root / 'deployment/ascend/coding-bench-20261104-frozen.tgz'
assert hashlib.sha256(bundle.read_bytes()).hexdigest() == 'dede3f7528f6466126e2ce320b562e324fbddb9077e85572e8cd3a5d56785a21'
if not (dep / 'FROZEN.json').exists():
    assert not list((out / 'generation').glob('*.jsonl'))
    dep.mkdir(parents=True, exist_ok=True)
    with tarfile.open(bundle) as tar:
        for member in tar.getmembers():
            target = (dep / member.name).resolve()
            assert target.is_relative_to(dep) and member.isfile()
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(tar.extractfile(member).read())
frozen = json.loads((dep / 'FROZEN.json').read_text())
for name, sha in frozen['files'].items():
    assert hashlib.sha256((dep / name).read_bytes()).hexdigest() == sha, name
config = json.loads((dep / f'deployment/config-{replica}.json').read_text())
if replica == 'a':
    name = config['generation_container']
    old = json.loads(subprocess.check_output(['docker', 'inspect', 'agentic-scaling-changxiangyu-ascend-pair'], text=True))[0]
    existing = subprocess.run(['docker', 'inspect', name], capture_output=True, text=True)
    if existing.returncode:
        args = ['docker', 'run', '-d', '--name', name, '--pull', 'never',
                '--label', 'inference_scaling.owner=changxiangyu', '--label', 'inference_scaling.study=coding-bench-20261104',
                '--user', config['user'], '--group-add', '1001', '--cpus', '16', '--memory', '64g', '--shm-size', '4g']
        for device in config['devices']:
            args += ['--device', '/dev/davinci' + str(device)]
        for name_device in ['davinci_manager', 'devmm_svm', 'hisi_hdc']:
            args += ['--device', '/dev/' + name_device]
        for mount in old['Mounts']:
            assert mount['Type'] == 'bind'
            args += ['--mount', f"type=bind,src={mount['Source']},dst={mount['Destination']}" + (',readonly' if not mount['RW'] else '')]
        for setting in ['PYTHONPYCACHEPREFIX=/cache/pycache', 'OMP_NUM_THREADS=4', 'VLLM_WORKER_MULTIPROC_METHOD=spawn']:
            args += ['-e', setting]
        args += ['-w', '/workspace', config['image_id'], 'sleep', 'infinity']
        subprocess.run(args, check=True)
    else:
        own = json.loads(existing.stdout)[0]
        assert own['Config']['Labels'].get('inference_scaling.study') == 'coding-bench-20261104'
        assert own['State']['Running']
    for kind, identity, create in [('group', str(os.getgid()), ['groupadd', '--gid', str(os.getgid()), 'changxiangyu']),
                                  ('passwd', str(os.getuid()), ['useradd', '--uid', str(os.getuid()), '--gid', str(os.getgid()),
                                                              '--home-dir', '/cache', '--shell', '/usr/sbin/nologin',
                                                              '--no-create-home', '--no-log-init', 'changxiangyu'])]:
        if subprocess.run(['docker', 'exec', name, 'getent', kind, identity], capture_output=True).returncode:
            subprocess.run(['docker', 'exec', '-u', '0', name, *create], check=True)
    custom_ops = '/vllm-workspace/vllm-ascend/vllm_ascend/_cann_ops_custom/vendors'
    subprocess.run(['docker', 'exec', '-u', '0', name, 'chgrp', '-R', '1001', custom_ops], check=True)
    subprocess.run(['docker', 'exec', '-u', '0', name, 'chmod', '-R', 'g+rX', custom_ops], check=True)
out.mkdir(parents=True, exist_ok=True)
pidfile = out / f'{replica}-queue.pid'
if pidfile.exists():
    pid = int(pidfile.read_text())
    proc = Path('/proc') / str(pid) / 'cmdline'
    if proc.exists() and b'coding-bench-20261104/deployment/queue.py' in proc.read_bytes():
        print(json.dumps({'already_running': pid, 'replica': replica}))
        raise SystemExit(0)
with (out / f'{replica}-queue.log').open('a') as log:
    process = subprocess.Popen(['python3', '-u', str(dep / 'deployment/queue.py'), '--config',
                                str(dep / f'deployment/config-{replica}.json')],
                               stdin=subprocess.DEVNULL, stdout=log, stderr=log, start_new_session=True)
pidfile.write_text(str(process.pid) + '\n')
print(json.dumps({'replica': replica, 'queue_pid': process.pid, 'source_commit': frozen['source_commit'],
                  'devices': config['devices'], 'verified_files': len(frozen['files'])}))
