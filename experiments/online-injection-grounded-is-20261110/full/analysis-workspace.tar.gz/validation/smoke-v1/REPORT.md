# Grounded retrieval / IS: complete results

F1 is lexical overlap, not factual accuracy. Question means average seeds; regression and fresh cohorts remain separate.

| Cohort | Arm | Questions | F1 % | Work | Total generated | Seconds | PFLOPs | Empty | Forced close |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| smoke | dynamic_anchor_sc | 2 | 26.746 | 2004.2 | 2202.8 | 70.87 | 0.859 | 0 | 0 |
| smoke | dynamic_legacy_sc | 2 | 17.404 | 4383.0 | 4602.5 | 140.50 | 1.118 | 0 | 0 |
| smoke | dynamic_verified_is | 2 | 27.470 | 2943.5 | 2943.5 | 83.35 | 0.895 | 0 | 0 |
| smoke | dynamic_verified_noise | 2 | 19.122 | 4287.0 | 4287.0 | 105.86 | 1.171 | 0 | 0 |
| smoke | static_anchor_sc | 2 | 37.027 | 2154.5 | 2411.5 | 95.60 | 0.848 | 0 | 0 |
| smoke | static_legacy_sc | 2 | 32.216 | 2288.0 | 2506.0 | 95.20 | 0.839 | 0 | 0 |
| smoke | static_verified_is | 2 | 33.646 | 3198.0 | 3198.0 | 98.94 | 0.767 | 0 | 0 |
| smoke | static_verified_noise | 2 | 20.721 | 4789.5 | 4789.5 | 132.85 | 1.113 | 0 | 1 |

## Realized token allocation

Per-condition means. Probe tokens include main drafts and retrieval auxiliaries, so this column overlaps retrieval auxiliaries; do not sum those two columns. Candidate answers and verifiers are paid inside verified-IS work.

| Cohort | Arm | Probe total | Search thinking | Candidate answers | Verifiers | Retrieval auxiliaries | Discarded confirmed prefix |
|---|---|---:|---:|---:|---:|---:|---:|
| smoke | dynamic_anchor_sc | 366.5 | 1637.8 | 0.0 | 0.0 | 270.5 | 22.5 |
| smoke | dynamic_legacy_sc | 174.5 | 4208.5 | 0.0 | 0.0 | 46.5 | 0.0 |
| smoke | dynamic_verified_is | 366.5 | 1285.5 | 1171.5 | 120.0 | 270.5 | 22.5 |
| smoke | dynamic_verified_noise | 366.5 | 2298.8 | 1477.8 | 144.0 | 270.5 | 22.5 |
| smoke | static_anchor_sc | 173.0 | 1981.5 | 0.0 | 0.0 | 173.0 | 0.0 |
| smoke | static_legacy_sc | 0.0 | 2288.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| smoke | static_verified_is | 173.0 | 1763.5 | 1127.5 | 134.0 | 173.0 | 0.0 |
| smoke | static_verified_noise | 173.0 | 2975.2 | 1497.2 | 144.0 | 173.0 | 0.0 |

## Paired question bootstrap

Differences and 95% intervals are F1 percentage points, descriptive and unadjusted.

- smoke: dynamic_verified_is − dynamic_legacy_sc: +10.066 [+5.278, +14.855], n=2.
- smoke: dynamic_verified_is − dynamic_anchor_sc: +0.725 [-2.862, +4.312], n=2.
- smoke: dynamic_verified_is − static_verified_is: -6.176 [-11.803, -0.549], n=2.
- smoke: dynamic_verified_is − static_legacy_sc: -4.746 [-19.256, +9.764], n=2.
- smoke: dynamic_anchor_sc − dynamic_legacy_sc: +9.341 [+0.966, +17.717], n=2.
- smoke: static_verified_is − static_anchor_sc: -3.381 [-9.135, +2.373], n=2.
- smoke: dynamic_verified_is − dynamic_verified_noise: +8.349 [+0.000, +16.698], n=2.
- smoke: static_verified_is − static_verified_noise: +12.926 [+0.000, +25.852], n=2.

## Stops in all executed calls

Each native execution unit is counted once, including unselected candidates. A first-token close in a later search call may follow a long existing prefix. The injected-root subset starts exactly at the immutable evidence/search boundary; it also includes static reference roots. Candidate-answer truncation is the deliberate answer cap, not thinking EOS. These are call diagnostics, not independent trials.

| Diagnostic | Count |
|---|---:|
| thinking_search_calls | 308 |
| thinking_search_calls_with_eos | 0 |
| search_calls_first_close | 8 |
| search_calls_first_eos | 0 |
| injected_root_search_calls | 52 |
| injected_root_first_close | 0 |
| injected_root_first_eos | 0 |
| candidate_answer_calls | 60 |
| empty_candidate_answer_calls | 0 |
| truncated_candidate_answer_calls | 0 |

Audits passed: True; checks: 4940; unique execution units: 40.
