# Grounded retrieval / IS: complete results

F1 is lexical overlap, not factual accuracy. Question means average seeds; regression and fresh cohorts remain separate.

| Cohort | Arm | Questions | F1 % | Work | Total generated | Seconds | PFLOPs | Empty | Forced close |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| smoke | dynamic_anchor_sc | 2 | 22.450 | 899.5 | 1017.0 | 37.33 | 0.580 | 0 | 0 |
| smoke | dynamic_legacy_sc | 2 | 17.404 | 4383.0 | 4602.5 | 134.09 | 1.118 | 0 | 0 |
| smoke | dynamic_verified_is | 2 | 15.357 | 1470.0 | 1470.0 | 42.88 | 0.673 | 0 | 0 |
| smoke | dynamic_verified_noise | 2 | 21.126 | 4066.5 | 4066.5 | 94.48 | 1.215 | 0 | 0 |
| smoke | static_anchor_sc | 2 | 18.985 | 755.5 | 897.5 | 47.08 | 0.543 | 0 | 0 |
| smoke | static_legacy_sc | 2 | 32.216 | 2288.0 | 2506.0 | 91.31 | 0.839 | 0 | 0 |
| smoke | static_verified_is | 2 | 15.357 | 1326.0 | 1326.0 | 55.98 | 0.616 | 0 | 0 |
| smoke | static_verified_noise | 2 | 21.126 | 3922.5 | 3922.5 | 112.25 | 1.158 | 0 | 0 |

## Realized token allocation

Per-condition means. Probe tokens include main drafts and retrieval auxiliaries, so this column overlaps retrieval auxiliaries; do not sum those two columns. Candidate answers and verifiers are paid inside verified-IS work.

| Cohort | Arm | Probe total | Search thinking | Candidate answers | Verifiers | Retrieval auxiliaries | Discarded confirmed prefix |
|---|---|---:|---:|---:|---:|---:|---:|
| smoke | dynamic_anchor_sc | 173.0 | 726.5 | 0.0 | 0.0 | 77.0 | 47.5 |
| smoke | dynamic_legacy_sc | 174.5 | 4208.5 | 0.0 | 0.0 | 46.5 | 0.0 |
| smoke | dynamic_verified_is | 173.0 | 748.5 | 409.0 | 139.5 | 77.0 | 47.5 |
| smoke | dynamic_verified_noise | 173.0 | 2460.5 | 1289.0 | 144.0 | 77.0 | 47.5 |
| smoke | static_anchor_sc | 29.0 | 726.5 | 0.0 | 0.0 | 29.0 | 0.0 |
| smoke | static_legacy_sc | 0.0 | 2288.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| smoke | static_verified_is | 29.0 | 748.5 | 409.0 | 139.5 | 29.0 | 0.0 |
| smoke | static_verified_noise | 29.0 | 2460.5 | 1289.0 | 144.0 | 29.0 | 0.0 |

## Paired question bootstrap

Differences and 95% intervals are F1 percentage points, descriptive and unadjusted.

- smoke: dynamic_verified_is − dynamic_legacy_sc: -2.048 [-2.880, -1.215], n=2.
- smoke: dynamic_verified_is − dynamic_anchor_sc: -7.093 [-8.345, -5.842], n=2.
- smoke: dynamic_verified_is − static_verified_is: +0.000 [+0.000, +0.000], n=2.
- smoke: dynamic_verified_is − static_legacy_sc: -16.860 [-25.748, -7.971], n=2.
- smoke: dynamic_anchor_sc − dynamic_legacy_sc: +5.045 [+2.961, +7.130], n=2.
- smoke: static_verified_is − static_anchor_sc: -3.628 [-7.551, +0.294], n=2.
- smoke: dynamic_verified_is − dynamic_verified_noise: -5.769 [-7.691, -3.847], n=2.
- smoke: static_verified_is − static_verified_noise: -5.769 [-7.691, -3.847], n=2.

## Stops in all executed calls

Each native execution unit is counted once, including unselected candidates. A first-token close in a later search call may follow a long existing prefix. The injected-root subset starts exactly at the immutable evidence/search boundary; it also includes static reference roots. Candidate-answer truncation is the deliberate answer cap, not thinking EOS. These are call diagnostics, not independent trials.

| Diagnostic | Count |
|---|---:|
| thinking_search_calls | 144 |
| thinking_search_calls_with_eos | 0 |
| search_calls_first_close | 0 |
| search_calls_first_eos | 0 |
| injected_root_search_calls | 44 |
| injected_root_first_close | 0 |
| injected_root_first_eos | 0 |
| candidate_answer_calls | 36 |
| empty_candidate_answer_calls | 0 |
| truncated_candidate_answer_calls | 0 |

Audits passed: True; checks: 2446; unique execution units: 22.
