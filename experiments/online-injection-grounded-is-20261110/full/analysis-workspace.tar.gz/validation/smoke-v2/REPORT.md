# Grounded retrieval / IS: complete results

F1 is lexical overlap, not factual accuracy. Question means average seeds; regression and fresh cohorts remain separate.

| Cohort | Arm | Questions | F1 % | Work | Total generated | Seconds | PFLOPs | Empty | Forced close |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| smoke | dynamic_anchor_sc | 1 | 25.806 | 2379.0 | 2531.0 | 73.53 | 0.784 | 0 | 0 |
| smoke | dynamic_verified_is | 1 | 27.848 | 3823.0 | 3823.0 | 105.47 | 1.163 | 0 | 0 |
| smoke | dynamic_verified_noise | 1 | 27.848 | 3823.0 | 3823.0 | 105.47 | 1.163 | 0 | 0 |
| smoke | static_anchor_sc | 1 | 28.188 | 2937.0 | 3076.0 | 79.07 | 0.798 | 0 | 0 |
| smoke | static_verified_is | 1 | 29.008 | 3441.0 | 3441.0 | 78.64 | 0.910 | 0 | 0 |
| smoke | static_verified_noise | 1 | 29.008 | 3441.0 | 3441.0 | 78.64 | 0.910 | 0 | 0 |

## Realized token allocation

Per-condition means. Probe tokens include main drafts and retrieval auxiliaries, so this column overlaps retrieval auxiliaries; do not sum those two columns. Candidate answers and verifiers are paid inside verified-IS work.

| Cohort | Arm | Probe total | Search thinking | Candidate answers | Verifiers | Retrieval auxiliaries | Discarded confirmed prefix |
|---|---|---:|---:|---:|---:|---:|---:|
| smoke | dynamic_anchor_sc | 260.0 | 2119.0 | 0.0 | 0.0 | 164.0 | 0.0 |
| smoke | dynamic_verified_is | 260.0 | 2119.0 | 1252.0 | 192.0 | 164.0 | 0.0 |
| smoke | dynamic_verified_noise | 260.0 | 2119.0 | 1252.0 | 192.0 | 164.0 | 0.0 |
| smoke | static_anchor_sc | 55.0 | 2882.0 | 0.0 | 0.0 | 55.0 | 0.0 |
| smoke | static_verified_is | 55.0 | 2367.0 | 875.0 | 144.0 | 55.0 | 0.0 |
| smoke | static_verified_noise | 55.0 | 2367.0 | 875.0 | 144.0 | 55.0 | 0.0 |

## Paired question bootstrap

Differences and 95% intervals are F1 percentage points, descriptive and unadjusted.

- smoke: dynamic_verified_is − dynamic_anchor_sc: +2.042 [+2.042, +2.042], n=1.
- smoke: dynamic_verified_is − static_verified_is: -1.160 [-1.160, -1.160], n=1.
- smoke: static_verified_is − static_anchor_sc: +0.820 [+0.820, +0.820], n=1.
- smoke: dynamic_verified_is − dynamic_verified_noise: +0.000 [+0.000, +0.000], n=1.
- smoke: static_verified_is − static_verified_noise: +0.000 [+0.000, +0.000], n=1.

## Stops in all executed calls

Each native execution unit is counted once, including unselected candidates. A first-token close in a later search call may follow a long existing prefix. The injected-root subset starts exactly at the immutable evidence/search boundary; it also includes static reference roots. Candidate-answer truncation is the deliberate answer cap, not thinking EOS. These are call diagnostics, not independent trials.

| Diagnostic | Count |
|---|---:|
| thinking_search_calls | 47 |
| thinking_search_calls_with_eos | 0 |
| search_calls_first_close | 0 |
| search_calls_first_eos | 0 |
| injected_root_search_calls | 0 |
| injected_root_first_close | 0 |
| injected_root_first_eos | 0 |
| candidate_answer_calls | 14 |
| empty_candidate_answer_calls | 0 |
| truncated_candidate_answer_calls | 0 |

Audits passed: True; checks: 775; unique execution units: 6.
