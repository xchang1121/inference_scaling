#!/usr/bin/env bash
set -e
export USER=changxiangyu LOGNAME=changxiangyu
export HF_HOME=/cache/huggingface XDG_CACHE_HOME=/results/cache
export TORCHINDUCTOR_CACHE_DIR=/results/cache/torchinductor TRITON_CACHE_DIR=/results/cache/triton
export ASCEND_PROCESS_LOG_PATH=/results/cache/ascend-log
source /usr/local/Ascend/ascend-toolkit/set_env.sh
source /usr/local/Ascend/cann-9.1.0/share/info/ascendnpu-ir/bin/set_env.sh
source /usr/local/Ascend/nnal/atb/set_env.sh --cxx_abi=1
export PYTHONPATH="/deployment/online-injection-grounded-is-20261110/source/src:/deployment/online-injection-grounded-is-20261110/source/scripts:${PYTHONPATH:-}"
exec "$@"
