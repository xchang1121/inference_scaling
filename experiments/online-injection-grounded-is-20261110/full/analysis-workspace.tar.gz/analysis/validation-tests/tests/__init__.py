"""Portable CPU validation support."""
