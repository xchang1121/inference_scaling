from pathlib import Path
import subprocess,json,time
c='aps-p1v4-goalplus-p1v4_1011-server'
d=json.loads(subprocess.check_output(['docker','inspect',c],text=True))[0]
assert not d['State']['Running']
inventory=subprocess.check_output(['/usr/local/bin/npu-smi','info'],text=True)
value={'time':time.time(),'authorization':'User requested stop all tasks on host198 cards0/1, then migrate this experiment to cards0/1',
 'container':c,'id':d['Id'],'state_after':d['State'],'inventory_after':inventory,
 'card0_idle':'No running processes found in NPU 0' in inventory,'card1_idle':'No running processes found in NPU 1' in inventory,
 'shutdown_note':'docker stop initially reported no exit event; subsequent inspection confirmed container exited'}
assert value['card0_idle'] and value['card1_idle']
path=Path('/data/disk/changxiangyu/agentic_scaling/deployment/ascend/online-injection-grounded-is-20261110/USER-STOP-A01.json')
assert not path.exists();path.write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value))
