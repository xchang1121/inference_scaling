"""Freeze document-disjoint unseen questions before any new model execution."""
from pathlib import Path
import hashlib
import json

base=Path(__file__).resolve().parent
old=base.parent/'online_injection_scaling_20261109'
source=base.parent/'online_injection_20261109/techqa_raw/train.json'
raw=json.loads(source.read_text(encoding='utf-8'))
byid={x['id']:x for x in raw}
manifest=json.loads((old/'data/manifest.json').read_text(encoding='utf-8'))
exclude=set(json.loads((old/'data/excluded-prior-groups.json').read_text(encoding='utf-8'))['prior_document_ids'])
prior=set(manifest['prior_ids'])|set(manifest['heldout_ids'])
for qid in prior:
    exclude.update(c['filename'] for c in byid[qid]['contexts'])
for line in (old/'handoff-roundtrip-complete/snapshot/formal.jsonl').read_text(encoding='utf-8').splitlines():
    row=json.loads(line)
    def visit(x):
        if isinstance(x,dict):
            exclude.update(x.get('parent_ids',[]))
            for v in x.values(): visit(v)
        elif isinstance(x,list):
            for v in x: visit(v)
    visit(row)
population=[x for x in raw if x['id'].startswith('DEV_') and not x['is_impossible'] and x['answer'].strip()]
ranked=sorted(population,key=lambda x:hashlib.sha256(('grounded-is-20261110:'+x['id']).encode()).hexdigest())
chosen=[];used=set(exclude)
for x in ranked:
    groups={c['filename'] for c in x['contexts']}
    if x['id'] in prior or groups&used: continue
    chosen.append(x['id']);used.update(groups)
    if len(chosen)==12: break
assert len(chosen)==12
regression=[json.loads(x) for x in (old/'data/questions.jsonl').read_text(encoding='utf-8').splitlines()]
questions=[{**x,'cohort':'regression'} for x in regression]
questions += [{'id':qid,'question':byid[qid]['question'],'dataset':'techqa','category':'technical_qa','cohort':'fresh'} for qid in chosen]
smoke=[json.loads(x) for x in (old/'data/smoke-questions.jsonl').read_text(encoding='utf-8').splitlines()]
for x in smoke: x['cohort']='smoke'
data=base/'data';data.mkdir(exist_ok=True)
def write(name,rows):
    (data/name).write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows),encoding='utf-8')
write('questions.jsonl',questions)
write('smoke-questions.jsonl',smoke)
write('gold.jsonl',[{'id':x['id'],'answer':byid[x['id']]['answer'],'document_ids':[c['filename'] for c in byid[x['id']]['contexts']]} for x in questions+smoke])
write('selection-population.jsonl',[{'id':x['id'],'document_ids':[c['filename'] for c in x['contexts']]} for x in population])
(data/'excluded-groups.json').write_text(json.dumps(sorted(exclude),indent=2)+'\n',encoding='utf-8')
protocol={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'fresh_ids':chosen,'regression_ids':[x['id'] for x in regression],
    'fresh_selection':'First 12 SHA256 grounded-is-20261110:id; nonempty answerable DEV; gold document groups disjoint from all prior gold/retrieved parent groups and each other',
    'excluded_groups':len(exclude),'population':len(population),'seeds':[20261110,20261111],
    'gold_runtime_visibility':False,'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in data.iterdir() if p.name!='manifest.json'}}
(data/'manifest.json').write_text(json.dumps(protocol,indent=2)+'\n',encoding='utf-8')
print(json.dumps(protocol,indent=2))
