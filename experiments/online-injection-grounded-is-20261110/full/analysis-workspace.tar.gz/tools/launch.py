"""Launch immutable question blocks; hold a per-device lock and release own jobs."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import argparse
import json
import subprocess
import sys

base=Path(__file__).resolve().parent
transport=base.parent/'online_injection_scaling_20261109/remote.py'
p=argparse.ArgumentParser();p.add_argument('stage',choices=['smoke','formal']);p.add_argument('--workers',nargs='+',default=['a0','a1']);a=p.parse_args()
retest_arms=['static_anchor_sc','dynamic_anchor_sc','static_verified_is','dynamic_verified_is','static_verified_noise','dynamic_verified_noise']
questions=[json.loads(x)['id'] for x in (base/'data/questions.jsonl').read_text(encoding='utf-8').splitlines()]
workers=['a0','a1']
assignments={w:questions[i::len(workers)] for i,w in enumerate(workers)}
smoke={'a0':['TRAIN_Q545'],'a1':['TRAIN_Q559'],'a3':['TRAIN_Q545'],'b4':['TRAIN_Q545'],'b5':['TRAIN_Q559'],'b6':['TRAIN_Q559'],'a6':['TRAIN_Q559'],'a7':['TRAIN_Q559']}
host_script=r'''
from pathlib import Path
import fcntl,hashlib,json,subprocess,time
root=Path('/data/disk/changxiangyu/agentic_scaling');name='online-injection-grounded-is-20261110'
dep=root/'deployment/ascend'/name;out=root/('results/'+name+'-'+worker);c='agentic-scaling-changxiangyu-grounded-is-'+worker
status=1;started=time.time()
with (root/'runtime'/('grounded-is-'+worker+'.lock')).open('a') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    try:
        frozen=json.loads((dep/'SOURCE-FROZEN.json').read_text())
        for n,h in {**frozen['hashes'],**frozen['source_files']}.items():
            assert hashlib.sha256((dep/n).read_bytes()).hexdigest()==h,n
        prepared=out/('prepared-'+stage+'.json')
        assert not (out/(stage+'.jsonl')).exists() and not (out/(stage+'.exit')).exists()
        inventory=subprocess.check_output(['/usr/local/bin/npu-smi','info'],text=True)
        (out/(stage+'-npu-before.txt')).write_text(inventory)
        assert f'No running processes found in NPU {worker[1:]}' in inventory,'device became occupied'
        active=subprocess.check_output(['docker','ps','-q'],text=True).split()
        conflicts=[]
        if active:
            for other in json.loads(subprocess.check_output(['docker','inspect',*active],text=True)):
                if other['Name'].lstrip('/') != c and f'/dev/davinci{worker[1:]}' in {d['PathOnHost'] for d in other['HostConfig'].get('Devices',[])}:
                    conflicts.append(other['Name'])
        assert not conflicts,('another container has reserved this device',conflicts)
        if stage=='formal':
            assert (out/'smoke.exit').read_text().strip()=='0'
            assert (dep/'FORMAL-APPROVED.json').exists(),'native audit must pass before formal'
        record={'worker':worker,'stage':stage,'cases':cases,'seeds':seeds,'source_commit':frozen['source_commit'],
            'prepared_sha256':hashlib.sha256(prepared.read_bytes()).hexdigest(),'started':started,'arms':arms}
        (out/(stage+'-frozen.json')).write_text(json.dumps(record,indent=2)+'\n')
        subprocess.run(['docker','start',c],check=True,capture_output=True)
        command=['docker','exec',c,'bash','/deployment/'+name+'/env.sh','python3','/deployment/'+name+'/source/scripts/benchmark_grounded_retrieval.py',
            '--settings','/deployment/'+name+'/settings.json','--corpus','/deployment/'+name+'/data/corpus.jsonl',
            '--prepared','/results/'+prepared.name,'--output','/results/'+stage+'.jsonl','--worker',worker,
            '--case-ids',*cases,'--seeds',*[str(s) for s in seeds]]
        if arms:command.extend(['--arms',*arms])
        with (out/(stage+'.log')).open('wb') as log:
            r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
        status=r.returncode
    finally:
        (out/(stage+'.exit')).write_text(str(status)+'\n')
        subprocess.run(['docker','stop',c],capture_output=True,timeout=45)
        info=json.loads(subprocess.check_output(['docker','inspect',c],text=True))[0]
        (out/(stage+'-finish.json')).write_text(json.dumps({'generation_exit':status,'started':started,'finished':time.time(),
            'state':info['State'],'image':info['Image'],'devices':info['HostConfig']['Devices']},indent=2)+'\n')
        (out/(stage+'-npu-after.txt')).write_text(subprocess.check_output(['/usr/local/bin/npu-smi','info'],text=True))
'''

def launch(worker):
    cases=smoke[worker] if a.stage=='smoke' else assignments[worker]
    seeds=[20261110] if a.stage=='smoke' else [20261110,20261111]
    arms=[]
    job='worker='+repr(worker)+'\nstage='+repr(a.stage)+'\ncases='+repr(cases)+'\nseeds='+repr(seeds)+'\narms='+repr(arms)+'\n'+host_script
    remote='job='+repr(job)+'\nworker='+repr(worker)+'\nstage='+repr(a.stage)+'\n'+r'''
from pathlib import Path
import json,subprocess
root=Path('/data/disk/changxiangyu/agentic_scaling');name='online-injection-grounded-is-20261110'
dep=root/'deployment/ascend'/name;out=root/('results/'+name+'-'+worker)
path=dep/(stage+'-launch-'+worker+'.py')
assert not path.exists() and not (out/(stage+'.jsonl')).exists()
path.write_text(job)
with (out/(stage+'-launch.log')).open('wb') as log:
    proc=subprocess.Popen(['python3',str(path)],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(out/(stage+'.pid')).write_text(str(proc.pid)+'\n')
print(json.dumps({'worker':worker,'stage':stage,'pid':proc.pid}))
'''
    path=base/(a.stage+'-launch-'+worker+'-remote.py');path.write_text(remote,encoding='utf-8')
    r=subprocess.run([sys.executable,'-X','utf8',str(transport),worker[0],'--file',str(path)],capture_output=True,timeout=110)
    (base/(a.stage+'-launch-'+worker+'.log')).write_bytes(r.stdout+r.stderr)
    return {'worker':worker,'exit':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()}

with ThreadPoolExecutor(max_workers=4) as pool:
    for result in pool.map(launch,a.workers): print(json.dumps(result),flush=True)
