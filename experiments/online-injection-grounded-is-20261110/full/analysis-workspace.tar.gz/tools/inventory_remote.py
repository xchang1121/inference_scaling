"""Read-only accelerator inventory; no process changes or device reservations."""
import json
import shutil
import subprocess
import time


def run(args):
    p = subprocess.run(args, text=True, capture_output=True, timeout=25)
    return {"returncode": p.returncode, "stdout": p.stdout, "stderr": p.stderr}


out = {"timestamp": time.time(), "hostname": run(["hostname"])}
for name, args in {
    "npu": ["/usr/local/bin/npu-smi", "info"],
    "memory": ["free", "-h"],
    "disk": ["df", "-h", "/data/disk/changxiangyu/agentic_scaling"],
    "identity": ["id"],
}.items():
    out[name] = run(args)
ids = run(["docker", "ps", "-q"])
containers = []
if ids["returncode"] == 0 and ids["stdout"].strip():
    details = run(["docker", "inspect", *ids["stdout"].split()])
    if details["returncode"] == 0:
        for x in json.loads(details["stdout"]):
            if not (x["HostConfig"].get("Devices") or x["HostConfig"].get("DeviceRequests") or x["HostConfig"].get("Privileged")):
                continue
            containers.append({"name": x["Name"], "image": x["Image"],
                "user": x["Config"]["User"], "pid": x["State"]["Pid"],
                "devices": x["HostConfig"].get("Devices"),
                "device_requests": x["HostConfig"].get("DeviceRequests"),
                "privileged": x["HostConfig"].get("Privileged"),
                "created": x["Created"]})
out["active_container_devices"] = containers
out["own_containers"] = run(["docker", "ps", "-a", "--filter", "name=agentic-scaling-changxiangyu", "--format", "{{.Names}} {{.Status}} {{.Image}}"])
out["pinned_image"] = run(["docker", "image", "inspect", "sha256:e288ad4ffb99e8d956a241c5489ad526f33741a16faa5783763a7e63a624b525", "--format", "{{.Id}}"])
out["model_path"] = run(["ls", "-ld", "/data/disk/models/Qwen3.8-27B", "/data/disk/changxiangyu/agentic_scaling/deployment/ascend"])
print(json.dumps(out, indent=2))
