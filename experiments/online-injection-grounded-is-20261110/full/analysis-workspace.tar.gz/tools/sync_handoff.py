"""Fast-forward only this task's two worktrees; verify every packaged byte."""
from pathlib import Path
import argparse
import base64
import gzip
import hashlib
import io
import json
import subprocess
import sys
import tarfile

BASE=Path(__file__).resolve().parent
REPO=BASE.parent/'online_injection_20261109/source'
REPORT=BASE.parents[1]/'outputs/online-injection-grounded-is-20261110'
BRANCH='codex/online-knowledge-injection-20261109'


def main():
    p=argparse.ArgumentParser();p.add_argument('replica',choices=['a','b']);a=p.parse_args()
    assert not subprocess.check_output(['git','-C',str(REPO),'status','--porcelain'],text=True).strip()
    head=subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip()
    bundle=BASE/('branch-final-'+head[:12]+'.bundle')
    if not bundle.exists():
        subprocess.run(['git','-C',str(REPO),'bundle','create',str(bundle),'852d6d0..'+BRANCH],check=True)
    memory=io.BytesIO()
    with gzip.GzipFile(fileobj=memory,mode='wb',filename='',mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w') as tar:
        for path in sorted(REPORT.rglob('*')):
            if path.is_file():
                data=path.read_bytes();member=tarfile.TarInfo(path.relative_to(REPORT).as_posix());member.size=len(data);member.mode=0o644;tar.addfile(member,io.BytesIO(data))
    reports=memory.getvalue()
    (BASE/('reports-final-'+head[:12]+'.tar.gz')).write_bytes(reports)
    payload={'replica':a.replica,'branch':BRANCH,'head':head,
        'bundle':base64.b64encode(bundle.read_bytes()).decode(),'bundle_sha256':hashlib.sha256(bundle.read_bytes()).hexdigest(),
        'reports':base64.b64encode(reports).decode(),'reports_sha256':hashlib.sha256(reports).hexdigest()}
    script='payload='+repr(payload)+r'''
from pathlib import Path,PurePosixPath
import base64,hashlib,io,json,subprocess,tarfile,time
root=Path('/data/disk/changxiangyu/agentic_scaling');name='online-injection-20261109-a3' if payload['replica']=='a' else 'online-injection-20261109';dep=root/'deployment/ascend'/name;source=dep/'git-source'
def git(path,*args):return subprocess.check_output(['git','-C',str(path),*args],text=True).strip()
assert git(source,'branch','--show-current')==payload['branch'] and not git(source,'status','--porcelain')
previous=git(source,'rev-parse','HEAD');main_before=git(root/'inference_scaling','rev-parse','HEAD')
bundle=base64.b64decode(payload['bundle']);reports=base64.b64decode(payload['reports'])
assert hashlib.sha256(bundle).hexdigest()==payload['bundle_sha256'] and hashlib.sha256(reports).hexdigest()==payload['reports_sha256']
path=dep/('branch-final-'+payload['head'][:12]+'.bundle')
if path.exists():assert path.read_bytes()==bundle
else:path.write_bytes(bundle)
subprocess.run(['git','-C',str(source),'bundle','verify',str(path)],check=True,capture_output=True)
subprocess.run(['git','-C',str(source),'fetch','--no-tags',str(path),'refs/heads/'+payload['branch']],check=True,capture_output=True)
subprocess.run(['git','-C',str(source),'merge-base','--is-ancestor',previous,payload['head']],check=True)
subprocess.run(['git','-C',str(source),'merge','--ff-only',payload['head']],check=True,capture_output=True)
assert git(source,'rev-parse','HEAD')==payload['head'] and not git(source,'status','--porcelain')
target=root/'results'/'online-injection-grounded-is-20261110'/('reports-final-'+payload['head'][:12]);target.mkdir(parents=True,exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(reports),mode='r:gz') as tar:
 for m in tar:
  p=PurePosixPath(m.name);assert m.isfile() and not p.is_absolute() and '..' not in p.parts
  dest=target/Path(*p.parts);dest.resolve().relative_to(target.resolve());data=tar.extractfile(m).read();dest.parent.mkdir(parents=True,exist_ok=True)
  if dest.exists():assert dest.read_bytes()==data
  else:dest.write_bytes(data)
canonical=source/'experiments/online-injection-grounded-is-20261110';manifest=json.loads((canonical/'MANIFEST.json').read_text())
for e in manifest['files']:
 p=canonical/e['path'];assert p.stat().st_size==e['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==e['sha256'],e['path']
expected={e['path']:e for e in manifest['members']};seen=set()
with tarfile.open(canonical/manifest['archive']['path']) as tar:
 for m in tar:
  assert m.isfile() and m.name in expected and m.name not in seen
  p=PurePosixPath(m.name);assert not p.is_absolute() and '..' not in p.parts
  data=tar.extractfile(m).read();e=expected[m.name];assert len(data)==e['bytes'] and hashlib.sha256(data).hexdigest()==e['sha256'];seen.add(m.name)
assert seen==set(expected)
main_after=git(root/'inference_scaling','rev-parse','HEAD');assert main_before==main_after
receipt={'replica':payload['replica'],'head':payload['head'],'previous_head':previous,'main_before':main_before,'main_after':main_after,'package_files_verified':len(manifest['files']),'archive_members_verified':len(seen),'bundle_sha256':payload['bundle_sha256'],'reports_sha256':payload['reports_sha256'],'reports_directory':str(target),'time':time.time()}
(target/'server-mirror-receipt.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt))
'''
    path=BASE/('sync-'+a.replica+'-remote.py');path.write_text(script,encoding='utf-8',newline='\n')
    result=subprocess.run([sys.executable,'-X','utf8',str(BASE.parent/'online_injection_scaling_20261109/remote.py'),a.replica,'--timeout','600','--file',str(path)],capture_output=True,timeout=620)
    assert result.returncode==0,result.stderr.decode(errors='replace')
    receipt=json.loads(result.stdout);(BASE/('server-mirror-'+a.replica+'.json')).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(receipt))


if __name__=='__main__':
    main()
