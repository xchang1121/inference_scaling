import json, subprocess
for name in ['sha256:e288ad4ffb99e8d956a241c5489ad526f33741a16faa5783763a7e63a624b525','sha256:660ce23a83574fdcd28ba126b07615829c06770c06fbdf6533f03cc4d90acdb1','agentic-scaling-qwen38-runtime:20261102']:
    r=subprocess.run(['docker','image','inspect',name],text=True,capture_output=True)
    if r.returncode: continue
    x=json.loads(r.stdout)[0]
    print(json.dumps({'name':name,'id':x['Id'],'rootfs':x['RootFS'],'size':x['Size'],'history':subprocess.check_output(['docker','history','--no-trunc',name,'--format','{{json .}}'],text=True).splitlines()[:6]}))
