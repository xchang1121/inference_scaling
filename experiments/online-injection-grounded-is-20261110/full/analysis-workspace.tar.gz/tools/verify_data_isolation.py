"""Audit fixed question/document-group isolation without reading model outputs."""
from pathlib import Path
import argparse
import hashlib
import json

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--data', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
manifest = json.loads((args.data/'manifest.json').read_text(encoding='utf-8'))
gold = {row['id']: row for line in (args.data/'gold.jsonl').read_text(encoding='utf-8').splitlines() if (row := json.loads(line))}
fresh, regression = manifest['fresh_ids'], manifest['regression_ids']
smoke = [json.loads(line)['id'] for line in (args.data/'smoke-questions.jsonl').read_text(encoding='utf-8').splitlines()]


def groups(ids):
    return {doc for qid in ids for doc in gold[qid]['document_ids']}


fg, rg, sg = groups(fresh), groups(regression), groups(smoke)
excluded = set(json.loads((args.data/'excluded-groups.json').read_text(encoding='utf-8')))
checks = {
    'expected_unique_sample_sizes': len(set(fresh)) == len(fresh) == 12 and len(set(regression)) == len(regression) == 8 and len(set(smoke)) == len(smoke) == 2,
    'fresh_regression_questions_disjoint': set(fresh).isdisjoint(regression),
    'fresh_regression_document_groups_disjoint': fg.isdisjoint(rg),
    'fresh_smoke_document_groups_disjoint': fg.isdisjoint(sg),
    'fresh_prior_excluded_groups_disjoint': fg.isdisjoint(excluded),
    'fresh_pairwise_document_groups_disjoint': all(set(gold[q]['document_ids']).isdisjoint(gold[r]['document_ids']) for i, q in enumerate(fresh) for r in fresh[i+1:]),
    'input_manifest_hashes_match': all(hashlib.sha256((args.data/name).read_bytes()).hexdigest() == digest for name, digest in manifest['files'].items()),
}
result = {'passed': all(checks.values()), 'checks': checks, 'fresh_questions': len(fresh),
    'regression_questions': len(regression), 'train_smoke_questions': len(smoke),
    'fresh_document_groups': len(fg), 'prior_excluded_groups': len(excluded),
    'fresh_smoke_overlap': sorted(fg & sg), 'model_outputs_read': False}
args.output.parent.mkdir(parents=True, exist_ok=True)
args.output.write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
print(json.dumps(result))
raise SystemExit(0 if result['passed'] else 1)
