"""Task-scoped SSH transport using the current WLAN address, without editing SSH config."""
import argparse
import ipaddress
import json
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument('replica', choices=('a', 'b'))
parser.add_argument('--file')
parser.add_argument('--timeout', type=int, default=90)
parser.add_argument('--via-jump', action='store_true')
args = parser.parse_args()
sys.stdin.reconfigure(encoding='utf-8')
sys.stdout.reconfigure(encoding='utf-8')
interface = json.loads(subprocess.check_output(['powershell', '-NoProfile', '-Command',
    "Get-NetIPAddress -AddressFamily IPv4 -InterfaceAlias WLAN | Select-Object IPAddress,InterfaceIndex | ConvertTo-Json -Compress"], text=True))
source = interface['IPAddress']
ipaddress.IPv4Address(source)
ssh = 'C:/Windows/System32/OpenSSH/ssh.exe'
config = Path(__file__).resolve().parent/'ssh-task-config'
socket_proxy = Path(__file__).resolve().parent/'ssh_socket.py'
config.write_text(f'Host 159.138.54.61\n    ProxyCommand {Path(sys.executable).as_posix()} {socket_proxy.as_posix()} --interface-index {interface["InterfaceIndex"]} --source {source} %h %p\nHost *\n    Include C:/Users/singm/.ssh/config\n', encoding='utf-8')
proxy = (f'{ssh} -F {config.as_posix()} -o BindAddress={source} -o BatchMode=yes -o ConnectTimeout=15 -W %h:%p 159.138.54.61'
         if args.via_jump else f'{Path(sys.executable).as_posix()} {socket_proxy.as_posix()} --interface-index {interface["InterfaceIndex"]} --source {source} %h %p')
script = Path(args.file).read_text(encoding='utf-8') if args.file else sys.stdin.read()
command = [ssh, '-T', '-o', 'BindAddress=' + source, '-o', 'ProxyCommand=' + proxy,
    '-o', 'BatchMode=yes', '-o', 'IdentityAgent=none', '-o', 'StrictHostKeyChecking=yes',
    '-o', 'ConnectTimeout=20', '-o', 'ServerAliveInterval=10', '-o', 'ServerAliveCountMax=3',
    {'a': '27.106.124.198', 'b': '189.1.227.167'}[args.replica], 'python3 -']
raise SystemExit(subprocess.run(command, input=script.replace('\r\n', '\n').encode(), timeout=args.timeout).returncode)
