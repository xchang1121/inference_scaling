"""Task-scoped TCP proxy bound to WLAN; binary pipes avoid shutdown locks."""
import argparse
import os
import socket
import threading

p = argparse.ArgumentParser()
p.add_argument('--interface-index', type=int, required=True)
p.add_argument('--source', required=True)
p.add_argument('host')
p.add_argument('port', type=int)
a = p.parse_args()
if os.name == 'nt':
    import msvcrt
    msvcrt.setmode(0, os.O_BINARY)
    msvcrt.setmode(1, os.O_BINARY)
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.settimeout(15)
s.setsockopt(socket.IPPROTO_IP, 31, socket.htonl(a.interface_index))
s.bind((a.source, 0))
s.connect((a.host, a.port))
s.settimeout(None)


def send():
    try:
        while data := os.read(0, 65536):
            s.sendall(data)
        s.shutdown(socket.SHUT_WR)
    except OSError:
        pass


threading.Thread(target=send, daemon=True).start()
status = 0
try:
    while data := s.recv(65536):
        view = memoryview(data)
        while view:
            view = view[os.write(1, view):]
except OSError:
    status = 1
finally:
    s.close()
os._exit(status)
