"""Create own per-device containers; do not start accelerator jobs yet."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import base64
import hashlib
import json
import subprocess
import sys

base=Path(__file__).resolve().parent
transport=base.parent/'online_injection_scaling_20261109/remote.py'
files={p.name:base64.b64encode(p.read_bytes()).decode() for p in [base/'runtime-0.tar.gz',base/'runtime-1.tar.gz']}
ops_manifest=json.loads((base.parent/'online_injection_20261109/formal-provenance/runtime-ops-file-manifest.json').read_text(encoding='utf-8'))
remote=r'''
from pathlib import Path
import base64,gzip,hashlib,io,json,os,subprocess,tarfile,time
root=Path('/data/disk/changxiangyu/agentic_scaling')
dep=root/'deployment/ascend/online-injection-grounded-is-20261110'
dep.mkdir(exist_ok=True)
assert not (dep/'RUNTIME-READY.json').exists(),'preserve existing runtime'
for name,value in files.items():
    (dep/name).write_bytes(base64.b64decode(value))
runtime=dep/'runtime';runtime.mkdir(exist_ok=True)
for name in files:
    with tarfile.open(dep/name,'r:gz') as tar:
        # Docker copy archives consist only of these two explicit runtime roots.
        for m in tar:
            assert not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
        tar.extractall(runtime,filter='data')
runner=runtime/'model_runner_v1.py';ops=runtime/'_cann_ops_custom'
assert hashlib.sha256(runner.read_bytes()).hexdigest()=='60b10f97333df49c4bb2a6b5673d13d2d3b964056564c50681984b16fd84d049'
actual={p.relative_to(ops).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in ops.rglob('*') if p.is_file()}
assert actual==ops_manifest,'operator runtime differs from validated A'
oldname='agentic-scaling-changxiangyu-injection-scaling-a3' if replica=='a' else 'agentic-scaling-changxiangyu-injection-b'
old=json.loads(subprocess.check_output(['docker','inspect',oldname],text=True))[0]
assert not old['State']['Running']
image='sha256:660ce23a83574fdcd28ba126b07615829c06770c06fbdf6533f03cc4d90acdb1'
checks=[]
for device in devices:
    assert f'No running processes found in NPU {device}' in subprocess.check_output(['/usr/local/bin/npu-smi','info'],text=True)
    c=f'agentic-scaling-changxiangyu-grounded-is-{replica}{device}'
    out=root/f'results/online-injection-grounded-is-20261110-{replica}{device}';out.mkdir()
    cache=out/'cache';cache.mkdir()
    command=['docker','create','--name',c,'--user',old['Config']['User'],'--group-add','1001','--shm-size','34359738368',
        '--label','inference_scaling.owner=changxiangyu','--label','inference_scaling.task=online-injection-grounded-is-20261110',
        '-e','OMP_NUM_THREADS=4','-e','VLLM_WORKER_MULTIPROC_METHOD=spawn']
    for d in [f'/dev/davinci{device}','/dev/davinci_manager','/dev/devmm_svm','/dev/hisi_hdc']:
        command+=['--device',d+':'+d]
    for m in old['Mounts']:
        source=str(out) if m['Destination']=='/results' else m['Source']
        command+=['--mount','type=bind,source='+source+',target='+m['Destination']+('' if m['RW'] else ',readonly')]
    for source,target in [(runner,'/vllm-workspace/vllm-ascend/vllm_ascend/worker/model_runner_v1.py'),(ops,'/vllm-workspace/vllm-ascend/vllm_ascend/_cann_ops_custom')]:
        command+=['--mount','type=bind,source='+str(source)+',target='+target+',readonly']
    command += [image,'sleep','infinity']
    subprocess.run(command,check=True,capture_output=True)
    # A device is exposed, but no accelerator is initialized in this CPU-only check.
    subprocess.run(['docker','start',c],check=True,capture_output=True)
    code="import importlib.metadata as m,json,platform;print(json.dumps({'python':platform.python_version(),'packages':{p:m.version(p) for p in ['vllm','vllm-ascend','torch','torch-npu','transformers','tokenizers']}}))"
    versions=json.loads(subprocess.check_output(['docker','exec',c,'python3','-c',code],text=True))
    assert versions['packages']=={'vllm':'0.23.0+empty','vllm-ascend':'0.23.0','torch':'2.10.0+cpu','torch-npu':'2.10.0.post4','transformers':'5.5.4','tokenizers':'0.22.2'},versions
    checks.append({'container':c,'device':device,'versions':versions,'image':image,'output':str(out)})
receipt={'replica':replica,'time':time.time(),'devices':devices,'runtime_files':len(actual),'runtime_bytes':sum(x['bytes'] for x in actual.values()),'checks':checks}
(dep/'RUNTIME-READY.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
'''

def one(replica,devices):
    script='files='+repr(files)+'\nops_manifest='+repr(ops_manifest)+'\nreplica='+repr(replica)+'\ndevices='+repr(devices)+'\n'+remote
    p=base/f'runtime-bootstrap-{replica}.py';p.write_text(script,encoding='utf-8')
    r=subprocess.run([sys.executable,'-X','utf8',str(transport),replica,'--timeout','180','--file',str(p)],capture_output=True,timeout=200)
    (base/f'runtime-bootstrap-{replica}.log').write_bytes(r.stdout+r.stderr)
    return {'replica':replica,'exit':r.returncode,'output':r.stdout.decode()[-3500:],'stderr':r.stderr.decode()[-1500:]}

with ThreadPoolExecutor(max_workers=2) as pool:
    for result in pool.map(lambda x:one(*x),[('a',[3]),('b',[4,5,6])]):
        print(json.dumps(result),flush=True)
