"""Collect and audit the full frozen formal run; never grade a partial queue."""
from pathlib import Path
import json
import os
import subprocess
import sys

base = Path(__file__).resolve().parent
repo = base.parent/'online_injection_20261109/source'
output = base.parents[1]/'outputs/online-injection-grounded-is-20261110'
env = {**os.environ, 'PYTHONPATH': os.pathsep.join([
    str(base.parent/'online_injection_20261109/devdeps'), str(repo/'src'), str(repo/'scripts')])}


def run(arguments):
    result = subprocess.run([sys.executable, '-X', 'utf8', *map(str, arguments)],
        env=env, capture_output=True, encoding='utf-8')
    if result.returncode:
        raise RuntimeError(result.stdout+'\n'+result.stderr)
    print(result.stdout.strip(), flush=True)


run([base/'collect.py', 'formal'])
for worker in ['a0', 'a1']:
    folder = base/'snapshot/formal'/worker
    assert (folder/'formal.exit').read_text().strip() == '0'
    records = [json.loads(line) for line in (folder/'formal.jsonl').read_text(encoding='utf-8').splitlines()]
    assert sum(row['kind'] == 'measurement' for row in records) == 160
    assert records[-1] == {'kind': 'completed', 'conditions': 160}
snapshot = base/'snapshot/formal'
gold = base/'data/gold.jsonl'
run([repo/'scripts/summarize_grounded_retrieval.py', '--snapshot', snapshot,
    '--stage', 'formal', '--gold', gold, '--output', output])
run([repo/'scripts/export_grounded_retrieval.py', '--snapshot', snapshot,
    '--stage', 'formal', '--output', output/'traces'])
run([repo/'scripts/diagnose_grounded_retrieval.py', '--snapshot', snapshot,
    '--stage', 'formal', '--gold', gold, '--output', output])
review_bytes = (base/'manual-case-notes.jsonl').read_bytes()
review_target = output/'manual-case-notes.jsonl'
if review_target.exists():
    assert review_target.read_bytes() == review_bytes, 'preserve existing manual review'
else:
    review_target.write_bytes(review_bytes)
run([repo/'scripts/validate_grounded_review.py', '--notes', review_target,
    '--cases', output/'fixed-case-review.jsonl', '--manifest', base/'data/manifest.json',
    '--diagnostics', output/'evidence-diagnostics.json', '--output', output/'manual-review-audit.json'])
run([repo/'scripts/evaluate_grounded_route.py', '--snapshot', snapshot,
    '--graded', output/'graded.jsonl', '--registration', base/'adaptive-policy-preregistration.json', '--output', output])
run([repo/'scripts/plot_grounded_retrieval.py', '--summary', output/'summary.json', '--output', output/'figures'])
print(json.dumps({'completed_analysis': str(output)}), flush=True)
