"""Read complete seed blocks from the fixed qualitative review sample only."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys

base = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--ids', nargs='+', required=True)
parser.add_argument('--fixed-fresh', action='store_true')
args = parser.parse_args()
manifest = json.loads((base/'data/manifest.json').read_text(encoding='utf-8'))
allowed = {'DEV_Q016', 'DEV_Q008', 'DEV_Q022'} if args.fixed_fresh else set(manifest['regression_ids'])
assert set(args.ids) <= allowed
remote = 'requested='+repr(args.ids)+'\nexpected_cohort='+repr('fresh' if args.fixed_fresh else 'regression')+r'''
from pathlib import Path
import hashlib,json
root=Path('/data/disk/changxiangyu/agentic_scaling')
tokenizer=json.loads((root/'runtime/models/Qwen3.8-27B/tokenizer.json').read_text())
vocab={v:k for k,v in tokenizer['model']['vocab'].items()}
vocab.update({t['id']:t['content'] for t in tokenizer['added_tokens']})
alphabet=list(range(33,127))+list(range(161,173))+list(range(174,256))
codes=alphabet.copy();extra=0
for byte in range(256):
    if byte not in alphabet:
        alphabet.append(byte);codes.append(256+extra);extra+=1
mapping=dict(zip(map(chr,codes),alphabet))
def decode(ids):return bytes(mapping[c] for c in ''.join(vocab[i] for i in ids)).decode('utf-8',errors='replace')
cases=[]
for worker in ['a0','a1']:
    folder=root/('results/online-injection-grounded-is-20261110-'+worker)
    data=(folder/'formal.jsonl').read_bytes();rows=[]
    for line in data.splitlines():
        try:row=json.loads(line)
        except ValueError:continue
        if row['kind']=='measurement' and row['question_id'] in requested:rows.append(row)
    for qid in requested:
        block=[r for r in rows if r['question_id']==qid]
        if sum(r['seed']==20261110 for r in block)!=8:continue
        assert all(r['cohort']==expected_cohort for r in block)
        selected=[]
        arms=['static_verified_is','dynamic_legacy_sc','dynamic_anchor_sc','dynamic_verified_is','dynamic_verified_noise']
        for row in block:
            if row['seed']!=20261110 or row['arm'] not in arms:continue
            r=row['result'];injections=[e for e in r['events'] if e['kind']=='injection']
            evidence=[]
            if injections:
                event=injections[-1]
                for body in event['packet']['bodies']:
                    evidence.append({'id':body['id'],'title':body['title'],
                        'actual_text':decode(event['payload_ids'][body['start']:body['stop']])})
            selected.append({'arm':row['arm'],'answer':r['answer_text'],
                'answer_sha256':hashlib.sha256(r['answer_text'].encode()).hexdigest(),
                'evidence':evidence,'selected_verdict':row['search'].get('selected_verdict'),
                'prefix_reset':any('discarded_confirmed_ids' in e for e in r['events'])})
        cases.append({'question_id':qid,'worker':worker,'seed':20261110,'reviewed_seed_all8_complete':True,'all16conditions_complete':len(block)==16,
            'partial_run_prefix_sha256':hashlib.sha256(data).hexdigest(),'conditions':selected})
print(json.dumps(cases,ensure_ascii=False))
'''
result = subprocess.run([sys.executable, '-X', 'utf8', str(base.parent/'online_injection_scaling_20261109/remote.py'), 'a'],
    input=remote.encode(), capture_output=True, timeout=110)
assert result.returncode == 0, result.stderr.decode()
gold = {r['id']:r for line in (base/'data/gold.jsonl').read_text(encoding='utf-8').splitlines() if (r:=json.loads(line))}
questions = {r['id']:r['question'] for line in (base/'data/questions.jsonl').read_text(encoding='utf-8').splitlines() if (r:=json.loads(line))}
for case in json.loads(result.stdout):
    qid=case['question_id']
    print(json.dumps({**case,'question':questions[qid],'gold':gold[qid]},ensure_ascii=False),flush=True)
