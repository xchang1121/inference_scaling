"""Package the completed study, resource migration and exact offline audit inputs."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import shutil
import tarfile

BASE=Path(__file__).resolve().parent
PILOT=BASE.parent/'online_injection_20261109'
REPO=PILOT/'source'
REPORT=BASE.parents[1]/'outputs/online-injection-grounded-is-20261110'
DEST=REPO/'experiments/online-injection-grounded-is-20261110'


def sha(data):return hashlib.sha256(data).hexdigest()


def main():
    summary=json.loads((REPORT/'summary.json').read_text(encoding='utf-8'))
    assert summary['audit_passed'] and summary['unique_execution']['conditions']==320
    adaptive=json.loads((REPORT/'adaptive-summary.json').read_text(encoding='utf-8'))
    assert adaptive['audit_passed'] and adaptive['native_conditions']==320 and adaptive['derived_views']==160
    review=json.loads((REPORT/'manual-review-audit.json').read_text(encoding='utf-8'))
    assert review['references_verified'] and review['questions']==11
    assert json.loads((BASE/'data-isolation-audit.json').read_text(encoding='utf-8'))['passed']
    for host in ['a','b']:
        state=json.loads((BASE/f'resource-release-{host}.json').read_text(encoding='utf-8'))
        assert not state['changed_source_or_inputs'] and not state['gold_runtime_files']
        assert all(w['stopped'] and not w['oom'] and w['generation_exit']==0 for w in state['workers'])
    assert not DEST.exists(),'preserve existing canonical package'
    entries={}

    def add(name,path):
        data=path.read_bytes()
        if name in entries:assert entries[name]==data,name
        entries[name]=data

    for folder,prefix in [('snapshot','snapshot'),('reports-smoke','validation/smoke-v3'),('reports-smoke-v1','validation/smoke-v1'),('reports-smoke-v2','validation/smoke-v2')]:
        for path in (BASE/folder).rglob('*'):
            if path.is_file():add(prefix+'/'+path.relative_to(BASE/folder).as_posix(),path)
    for path in (BASE/'data').iterdir():
        if path.is_file():add('data/'+path.name,path)
    for path in BASE.glob('*.json'):
        if not path.name.startswith(('sync-','offline-verification','server-mirror')):
            add('protocol/'+path.name,path)
    for name in ['settings.json','runtime-0.tar.gz','runtime-1.tar.gz']:
        add('protocol/'+name,BASE/name)
    add('protocol/unrelated-prose.txt',BASE.parent/'online_injection_scaling_20261109/unrelated-prose.txt')
    add('protocol/runtime-ops-file-manifest.json',PILOT/'formal-provenance/runtime-ops-file-manifest.json')
    add('data/DATASET_CARD.md',PILOT/'techqa_raw/README.md')
    add('data/LICENSE-Apache-2.0.txt',PILOT/'NVIDIA-LICENSE-Apache-2.0.txt')
    for filename,prefix in [('source-frozen.tgz','generation-source'),('source-frozen-v1.tgz','generation-source-smoke-v1'),('source-frozen-v2.tgz','generation-source-smoke-v2')]:
        add('protocol/'+filename,BASE/filename)
        with tarfile.open(BASE/filename) as tar:
            for member in tar:
                if member.isfile():
                    assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
                    entries[prefix+'/'+member.name]=tar.extractfile(member).read()
    for name in ['summarize_grounded_retrieval.py','summarize_flare_gap.py','plot_grounded_retrieval.py','export_grounded_retrieval.py','diagnose_grounded_retrieval.py','evaluate_grounded_route.py','validate_grounded_review.py']:
        add('analysis/'+name,REPO/'scripts'/name)
    add('analysis/grounded_route.py',REPO/'src/inference_scaling/retrieval/grounded_route.py')
    analysis_environment=json.loads((BASE/'analysis-environment.json').read_text(encoding='utf-8'))
    entries['analysis/requirements-offline.txt']=(''.join(f'{package}=={version}\n' for package,version in analysis_environment['packages'].items())).encode()
    add('analysis/PROTOCOL.md',REPO/'docs/reports/GROUNDED_RETRIEVAL_PROTOCOL.md')
    for name in ['test_grounded_retrieval.py','test_retrieval_scaling.py','test_stepwise_injection.py','test_conditional_is.py']:
        add('analysis/validation-tests/'+name,REPO/'tests'/name)
    entries['analysis/validation-tests/tests/__init__.py']=b'"""Portable CPU validation support."""\n'
    add('analysis/validation-tests/tests/tabular.py',REPO/'tests/tabular.py')
    tool_names=['inventory_remote.py','inventory.py','runtime_inspect_remote.py','image_layers_remote.py',
        'fetch_runtime.py','bootstrap_runtime.py','deploy.py','deploy_revision.py','prepare_data.py',
        'verify_weights.py','launch.py','monitor.py','collect.py','fix_container_dirs.py',
        'archive_failed_init.py','approve_formal.py','verify_resources.py','inspect_progress.py',
        'add_a_workers.py','add_a01_workers.py','deploy_indexed_revision.py','stop_a01_remote.py','finish_stop_a01_remote.py','stop_conflict_and_launch.py',
        'verify_registration.py','verify_data_isolation.py','review_regression_progress.py','analyze_completed.py','watch_formal.py','package_results.py','verify_handoff.py','sync_handoff.py']
    for name in tool_names:
        if (BASE/name).exists():add('tools/'+name,BASE/name)
    for name in ['remote.py','ssh_socket.py']:
        add('tools/transport/'+name,BASE.parent/'online_injection_scaling_20261109'/name)
    for path in REPORT.rglob('*'):
        if path.is_file():add('reports/'+path.relative_to(REPORT).as_posix(),path)
    needed=set()

    def visit(value):
        if isinstance(value,dict):
            needed.update(value.get('parent_ids',[]))
            for item in value.values():visit(item)
        elif isinstance(value,list):
            for item in value:visit(item)
    for name,data in list(entries.items()):
        if name.startswith('snapshot/') and name.endswith('.jsonl'):
            for line in data.splitlines():visit(json.loads(line))
        elif name.startswith('snapshot/') and '/prepared-' in name:visit(json.loads(data))
    for line in entries['data/gold.jsonl'].splitlines():needed.update(json.loads(line)['document_ids'])
    documents=[]
    with (PILOT/'data/techqa/corpus.jsonl').open(encoding='utf-8') as source:
        for line in source:
            if json.loads(line)['id'] in needed:documents.append(line.rstrip('\n'))
    assert len(documents)==len(needed)
    entries['data/retrieved-and-gold-documents.jsonl']=('\n'.join(documents)+'\n').encode()
    frozen=json.loads(entries['snapshot/formal/a0/protocol/SOURCE-FROZEN.json'])
    for name,digest in frozen['source_files'].items():
        assert sha(entries['generation-source/'+name.removeprefix('source/')])==digest,name
    (DEST/'full').mkdir(parents=True)
    archive=DEST/'full/analysis-workspace.tar.gz';members=[]
    with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,filename='',mode='wb',mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w') as tar:
        for name,data in sorted(entries.items()):
            members.append({'path':name,'bytes':len(data),'sha256':sha(data)})
            member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644
            tar.addfile(member,io.BytesIO(data))
    for path in REPORT.rglob('*'):
        if path.is_file():
            target=DEST/'reports'/path.relative_to(REPORT);target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(path,target)
    shutil.copyfile(REPO/'scripts/unpack_retrieval_scaling.py',DEST/'unpack.py')
    readme='''# Grounded dynamic retrieval + inference scaling

See `reports/OBSERVATIONS.md` for interpretation and `reports/REPORT.md` for all
320 formal conditions. After multi-card smokes and host failures, the user moved
host198 experiments to A0/A1, two isolated TP1 replicas; each paired question
block stayed on one device. The independent fresh sample is12 questions,
with two seeds, and the8 old regressions are reported separately.

The archive preserves every formal candidate, auxiliary call, score and selected
answer, all three native smoke versions, initialization failures, frozen generation
source, model/runtime hashes, the exact patched runner and804 custom operators,
offline gold, evidence provenance and all retrieved/gold parent documents.
Full BM25 re-retrieval requires the pinned full public corpus; the included parent
subset is for inspection only. Model weights are hash-pinned, not redistributed.

Run `python unpack.py --output NEW_DIRECTORY` to verify and extract every member.
Python3.12+, NumPy and Matplotlib suffice for offline analysis; pytest also runs
the CPU contracts. The actual local CPU versions are recorded separately in
`protocol/analysis-environment.json`, with package pins in
`analysis/requirements-offline.txt`. Byte-identical replay is verified in that
environment; plot bytes may differ with other versions or platforms.
Set PYTHONPATH to `generation-source/src;analysis` on Windows,
or `generation-source/src:analysis` on POSIX. From the extracted root:

```sh
python analysis/summarize_grounded_retrieval.py --snapshot snapshot/formal --stage formal --gold data/gold.jsonl --output rebuilt
python analysis/export_grounded_retrieval.py --snapshot snapshot/formal --stage formal --output rebuilt/traces
python analysis/diagnose_grounded_retrieval.py --snapshot snapshot/formal --stage formal --gold data/gold.jsonl --output rebuilt
python analysis/evaluate_grounded_route.py --snapshot snapshot/formal --graded rebuilt/graded.jsonl --registration protocol/adaptive-policy-preregistration.json --output rebuilt
python analysis/validate_grounded_review.py --notes reports/manual-case-notes.jsonl --cases rebuilt/fixed-case-review.jsonl --manifest data/manifest.json --diagnostics rebuilt/evidence-diagnostics.json --output rebuilt/manual-review-audit.json
python analysis/plot_grounded_retrieval.py --summary rebuilt/summary.json --output rebuilt/figures
```

Rebuilding the first smoke uses `generation-source-smoke-v1/src` on PYTHONPATH,
because its original quote parser allowed longer excerpts. The second smoke uses
`generation-source-smoke-v2/src`. The final native
generation source commit is recorded in `protocol/generation-revision.json` and
every worker's `protocol/SOURCE-FROZEN.json`. The final two-worker assignment
overrides the initial three-worker plan in `protocol/FORMAL-WORKER-PLAN.json`
inside each formal snapshot. Analysis may have later commits.
No model, network, tokenizer package or accelerator is needed for offline replay.
Native re-execution is a separate operation with the pinned weights, corpus,
base container image, operator overlays and CANN environment shown in the records.

Same8,192 generated-work cap does not mean equal realized FLOPs. Verified IS pays
candidate answers and checkers inside that cap; SC arms pay one final answer
separately. F1 measures lexical overlap, not factual correctness.

The eight reused regression questions retain a concise-answer suffix; the twelve
fresh questions use the original benchmark wording without that suffix. All arms
for a given question share identical wording. This frozen difference, discovered
during the fixed case review, limits comparisons of answer length, truncation and
F1 between cohorts. See `protocol/prompt-scope-audit.json`; no prompt or selection
rule was changed after inspecting fresh answers.

SC final answers use the inherited32-token chunks and call-counter-based seeds;
verified leaves use one call of up to512 tokens with a suffix-based seed.
Dynamic probes can therefore change an SC answer's sampling seed even when its
final input matches the static arm. Context diagnostics expose exact prefix,
suffix and first-answer-seed comparisons; do not attribute those answer changes
to retrieval timing alone.

`reports/ADAPTIVE.md` evaluates a supplementary gate-based policy registered
before any fresh model unit: accepted evidence selects verified IS; otherwise
anchored SC. Its160 outputs are exact derived views of the320 native conditions,
not additional trials. The registration's append-only log prefixes are verified
during offline replay. `analysis/grounded_route.py` is a later policy module;
it is not part of the frozen native generation source.
'''
    (DEST/'README.md').write_text(readme,encoding='utf-8',newline='\n')
    manifest={'generation_source_commit':frozen['source_commit'],
        'archive':{'path':archive.relative_to(DEST).as_posix(),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},
        'members':members,'included_parent_documents':len(needed),'files':[]}
    for path in sorted(DEST.rglob('*')):
        if path.is_file():manifest['files'].append({'path':path.relative_to(DEST).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())})
    (DEST/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps({'archive':manifest['archive'],'members':len(members),'parent_documents':len(needed)}))


if __name__=='__main__':main()
