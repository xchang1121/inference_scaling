"""Freeze indexed extraction and user-requested A0/1 migration before formal data."""
from pathlib import Path
import argparse
import base64
import hashlib
import json
import subprocess
import sys

base=Path(__file__).resolve().parent;repo=base.parent/'online_injection_20261109/source'
p=argparse.ArgumentParser();p.add_argument('replica',choices=['a','b']);a=p.parse_args()
assert not subprocess.check_output(['git','-C',str(repo),'status','--porcelain'],text=True).strip()
head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
paths=['src','settings','pyproject.toml','scripts/benchmark_is_gpu.py','scripts/benchmark_flare_gap.py',
       'scripts/benchmark_retrieval_scaling.py','scripts/benchmark_grounded_retrieval.py',
       'tests/test_grounded_retrieval.py','docs/reports/GROUNDED_RETRIEVAL_PROTOCOL.md']
data=subprocess.check_output(['git','-C',str(repo),'archive','--format=tar.gz','HEAD',*paths])
questions=[json.loads(x)['id'] for x in (base/'data/questions.jsonl').read_text().splitlines()]
plan={'workers':['a0','a1','b4'],'assignments':{w:questions[i::3] for i,w in enumerate(['a0','a1','b4'])},
      'reason':'User requested host198 experiments migrate to physical0/1; B5 externally occupied; B6 host allocation failures',
      'formal_conditions':320,'source_commit':head,'smoke_arms':8,'smoke_conditions':24}
payload={'commit':head,'data':base64.b64encode(data).decode(),'sha256':hashlib.sha256(data).hexdigest(),'plan':plan}
remote=r'''
from pathlib import Path
import base64,hashlib,json,subprocess,tarfile,time
root=Path('/data/disk/changxiangyu/agentic_scaling');name='online-injection-grounded-is-20261110';dep=root/'deployment/ascend'/name
previous=json.loads((dep/'SOURCE-FROZEN.json').read_text());assert previous['source_commit']=='9f20af7ce38c8f8875e5ef864259790997c0e847'
assert not (dep/'FORMAL-APPROVED.json').exists()
for worker in (['a0','a1','a3','a6','a7'] if replica=='a' else ['b4','b5','b6']):
    c='agentic-scaling-changxiangyu-grounded-is-'+worker
    assert not json.loads(subprocess.check_output(['docker','inspect',c],text=True))[0]['State']['Running']
    out=root/('results/'+name+'-'+worker);assert not (out/'formal.jsonl').exists()
    if (out/'smoke.jsonl').exists():
        assert (out/'smoke.exit').read_text().strip()=='0'
        rows=[json.loads(x) for x in (out/'smoke.jsonl').read_text().splitlines()]
        assert sum(r['kind']=='measurement' for r in rows)==6
        archive=out/'attempts/smoke-quote-v2';archive.mkdir(parents=True)
        for path in list(out.glob('smoke*')):
            assert path.is_file() and path.resolve().is_relative_to(out.resolve());path.rename(archive/path.name)
        path=dep/('smoke-launch-'+worker+'.py');path.rename(dep/('smoke-launch-'+worker+'-quote-v2.py'))
for path in [dep/'source',dep/'source-frozen.tgz',dep/'SOURCE-FROZEN.json']:
    assert path.resolve().is_relative_to(dep.resolve());path.rename(path.with_name(path.name+'-quote-v2'))
data=base64.b64decode(payload['data']);assert hashlib.sha256(data).hexdigest()==payload['sha256']
(dep/'source-frozen.tgz').write_bytes(data)
with tarfile.open(dep/'source-frozen.tgz') as tar:tar.extractall(dep/'source',filter='data')
(dep/'WORKER-PLAN.json').write_text(json.dumps(payload['plan'],indent=2)+'\n')
frozen={**previous,'source_commit':payload['commit'],'created':time.time(),'previous_source_commit':previous['source_commit'],
    'revision_reason':'TRAIN smoke copying remained unreliable; select exact numbered source spans before formal execution',
    'hashes':{**previous['hashes'],'source-frozen.tgz':payload['sha256'],'WORKER-PLAN.json':hashlib.sha256((dep/'WORKER-PLAN.json').read_bytes()).hexdigest()},
    'source_files':{p.relative_to(dep).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (dep/'source').rglob('*') if p.is_file()}}
for name,digest in frozen['hashes'].items():assert hashlib.sha256((dep/name).read_bytes()).hexdigest()==digest,name
(dep/'SOURCE-FROZEN.json').write_text(json.dumps(frozen,indent=2)+'\n')
print(json.dumps({'replica':replica,'source_commit':payload['commit'],'source_tar_sha256':payload['sha256']}))
'''
script='replica='+repr(a.replica)+'\npayload='+repr(payload)+'\n'+remote
result=subprocess.run([sys.executable,'-X','utf8',str(base.parent/'online_injection_scaling_20261109/remote.py'),a.replica,'--timeout','180'],input=script.encode(),capture_output=True,timeout=200)
(base/f'deploy-indexed-{a.replica}.log').write_bytes(result.stdout+result.stderr)
assert result.returncode==0,result.stderr.decode()
if not (base/'source-frozen-v2.tgz').exists():
    (base/'source-frozen-v2.tgz').write_bytes((base/'source-frozen.tgz').read_bytes())
    (base/'generation-revision-v2.json').write_bytes((base/'generation-revision.json').read_bytes())
(base/'source-frozen.tgz').write_bytes(data)
(base/'generation-revision.json').write_text(json.dumps({'commit':head,'tar_sha256':payload['sha256'],'plan':plan},indent=2)+'\n')
(base/'worker-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for worker in (['a3'] if a.replica=='a' else ['b4']):
    source=base/'snapshot/smoke'/worker;dest=base/'snapshot/smoke-quote-v2'/worker
    if not source.exists():continue
    assert source.is_dir() and not dest.exists() and source.resolve().is_relative_to(base) and dest.resolve().is_relative_to(base)
    dest.parent.mkdir(parents=True,exist_ok=True);source.rename(dest)
print(result.stdout.decode().strip())
