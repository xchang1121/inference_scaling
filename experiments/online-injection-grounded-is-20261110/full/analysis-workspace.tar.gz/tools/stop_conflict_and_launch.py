"""Honor the user's A0/1 stop/migration request and immediately launch this study."""
from pathlib import Path
import ast
import json
import subprocess
import sys

base=Path(__file__).resolve().parent
tree=ast.parse((base/'launch.py').read_text())
host_script=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='host_script' for t in n.targets))
questions=[json.loads(x)['id'] for x in (base/'data/questions.jsonl').read_text().splitlines()]
jobs={w:'worker='+repr(w)+'\nstage="formal"\ncases='+repr(questions[i::2])+'\nseeds=[20261110,20261111]\narms=[]\n'+host_script for i,w in enumerate(['a0','a1'])}
remote=r'''
from pathlib import Path
import json,subprocess,time
root=Path('/data/disk/changxiangyu/agentic_scaling');name='online-injection-grounded-is-20261110';dep=root/'deployment/ascend'/name
target='0787144598f64c061193f30b7689fe87db66e2dbdf49d7e637ae419950b9bb5a'
d=json.loads(subprocess.check_output(['docker','inspect',target],text=True))[0]
assert d['Name']=='/aps-p1v4-goalplus-p1v4_1011-native_failure_diagnostic_retry1-server'
assert {x['PathOnHost'] for x in d['HostConfig']['Devices']}=={'/dev/davinci0','/dev/davinci1','/dev/davinci_manager','/dev/devmm_svm','/dev/hisi_hdc'}
for worker in jobs:
    out=root/('results/'+name+'-'+worker)
    assert not (out/'formal.jsonl').exists() and not (out/'formal.exit').exists()
    assert not (dep/('formal-launch-'+worker+'.py')).exists()
before=subprocess.check_output(['/usr/local/bin/npu-smi','info'],text=True)
stop=subprocess.run(['docker','stop','--time','20',target],capture_output=True,text=True,timeout=80)
deadline=time.monotonic()+90
while True:
    state=json.loads(subprocess.check_output(['docker','inspect',target],text=True))[0]['State']
    if not state['Running']:break
    if time.monotonic()>=deadline:raise RuntimeError('target container still stopping; preserve all tasks')
    time.sleep(2)
inventory=subprocess.check_output(['/usr/local/bin/npu-smi','info'],text=True)
assert all(f'No running processes found in NPU {i}' in inventory for i in [0,1])
receipt={'time':time.time(),'authorization':'User requested stopping any task on198 cards0/1 and migrating this study there',
    'container':d['Name'],'id':target,'restart_policy':d['HostConfig']['RestartPolicy'],'stop_exit':stop.returncode,
    'stop_stderr':stop.stderr,'state_after':state,'inventory_before':before,'inventory_after':inventory,'launched':[]}
lease={'owner':'changxiangyu','task':name,'cards':[0,1],'reason':'Explicit user requested allocation; formal study in progress',
       'containers':['agentic-scaling-changxiangyu-grounded-is-'+w for w in jobs],'created':time.time()}
(root/'runtime/grounded-is-a01-reservation.json').write_text(json.dumps(lease,indent=2)+'\n')
for worker,job in jobs.items():
    path=dep/('formal-launch-'+worker+'.py');path.write_text(job)
    out=root/('results/'+name+'-'+worker)
    with (out/'formal-launch.log').open('wb') as log:
        proc=subprocess.Popen(['python3',str(path)],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    (out/'formal.pid').write_text(str(proc.pid)+'\n')
    receipt['launched'].append({'worker':worker,'pid':proc.pid})
(dep/'USER-STOP-A01-RETRY1.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
'''
script='jobs='+repr(jobs)+'\n'+remote
result=subprocess.run([sys.executable,'-X','utf8',str(base.parent/'online_injection_scaling_20261109/remote.py'),'a','--timeout','240'],input=script.encode(),capture_output=True,timeout=260)
(base/'stop-retry1-and-launch.log').write_bytes(result.stdout+result.stderr)
assert result.returncode==0,result.stderr.decode()
(base/'user-stop-a01-retry1.json').write_bytes(result.stdout)
value=json.loads(result.stdout);print(json.dumps({k:value[k] for k in ['container','state_after','launched']}))
