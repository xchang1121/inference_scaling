from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json
import subprocess
import sys

base = Path(__file__).resolve().parent
transport = base.parent / 'online_injection_scaling_20261109/remote.py'

def one(replica):
    r = subprocess.run([sys.executable, '-X', 'utf8', str(transport), replica, '--timeout', '120', '--file', str(base/'inventory_remote.py')], capture_output=True, timeout=140)
    (base/f'inventory-{replica}.json').write_bytes(r.stdout)
    (base/f'inventory-{replica}.stderr').write_bytes(r.stderr)
    if r.returncode:
        return {'replica': replica, 'exit': r.returncode, 'stderr': r.stderr.decode()[-1000:]}
    data = json.loads(r.stdout)
    return {'replica': replica, 'npu': data['npu']['stdout'], 'disk': data['disk']['stdout'],
        'image': data['pinned_image'], 'models': data['model_path'],
        'own_containers': data['own_containers']['stdout'],
        'containers': [{**x, 'devices': [d['PathOnHost'] for d in x.get('devices') or []]} for x in data['active_container_devices']]}

with ThreadPoolExecutor(max_workers=2) as pool:
    for result in pool.map(one, ['a', 'b']):
        print(json.dumps(result, ensure_ascii=False), flush=True)
