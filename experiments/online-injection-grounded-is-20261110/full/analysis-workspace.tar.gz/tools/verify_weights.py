from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import subprocess
import sys

base=Path(__file__).resolve().parent
transport=base.parent/'online_injection_scaling_20261109/remote.py'
remote=r'''
from pathlib import Path
import hashlib,json,time
root=Path('/data/disk/changxiangyu/agentic_scaling')
model=root/'runtime/models/Qwen3.8-27B';dep=root/'deployment/ascend/online-injection-grounded-is-20261110'
started=time.time();files={}
for p in sorted(model.iterdir()):
    if not p.is_file():continue
    h=hashlib.sha256()
    with p.open('rb') as f:
        while b:=f.read(8*1024*1024): h.update(b)
    files[p.name]={'bytes':p.stat().st_size,'sha256':h.hexdigest()}
value={'started':started,'finished':time.time(),'files':files}
(dep/'WEIGHT-VERIFICATION.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value))
'''
def one(replica):
    r=subprocess.run([sys.executable,'-X','utf8',str(transport),replica,'--timeout','900'],input=remote.encode(),capture_output=True,timeout=920)
    if r.returncode: raise RuntimeError(r.stderr.decode())
    d=json.loads(r.stdout);(base/f'weights-{replica}.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
    return d
with ThreadPoolExecutor(max_workers=2) as pool:
    values=list(pool.map(one,['a','b']))
assert values[0]['files']==values[1]['files'],'A/B weights differ'
print(json.dumps({'identical':True,'files':len(values[0]['files']),'bytes':sum(x['bytes'] for x in values[0]['files'].values()),'seconds':[x['finished']-x['started'] for x in values]}))
