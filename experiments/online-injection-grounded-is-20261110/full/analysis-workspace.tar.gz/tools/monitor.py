from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import argparse
import json
import subprocess
import sys

base=Path(__file__).resolve().parent
transport=base.parent/'online_injection_scaling_20261109/remote.py'
p=argparse.ArgumentParser();p.add_argument('stage',choices=['smoke','formal']);p.add_argument('--workers',nargs='+',default=['a0','a1']);p.add_argument('--verbose',action='store_true');a=p.parse_args()
remote=r'''
from pathlib import Path
import json,time
root=Path('/data/disk/changxiangyu/agentic_scaling/results')
for worker in workers:
    out=root/('online-injection-grounded-is-20261110-'+worker)
    path=out/(stage+'.jsonl');counts={};last=None;errors=[];max_work=0;empty=0;eos=0
    if path.exists():
        for line in path.read_text().splitlines():
            try:r=json.loads(line)
            except ValueError:continue
            counts[r['kind']]=counts.get(r['kind'],0)+1
            if r['kind']=='measurement':
                last={k:r[k] for k in ['question_id','seed','arm']}
                max_work=max(max_work,r['result']['work_tokens']);empty+=r['result']['empty_answer'];eos+=r['result']['eos_inside_thinking']
            if r['kind']=='failed_unit':errors.append(r['error'])
    exitfile=out/(stage+'.exit');log=out/(stage+'.log');launchlog=out/(stage+'-launch.log')
    generation_exit=exitfile.read_text().strip() if exitfile.exists() else None
    finish=out/(stage+'-finish.json');after=out/(stage+'-npu-after.txt')
    cleanup_complete=finish.exists() and after.exists() and after.stat().st_size>0
    if generation_exit=='0' and not cleanup_complete and time.time()-exitfile.stat().st_mtime>120:
        errors.append('generation complete but launcher cleanup has not completed after120seconds')
    code=None if generation_exit=='0' and not cleanup_complete else generation_exit
    value={'worker':worker,'counts':counts,'last':last,'exit':code,'generation_exit':generation_exit,'cleanup_complete':cleanup_complete,'failed':errors,'max_work':max_work,'empty_answers':empty,'thinking_eos':eos}
    if verbose or code not in {None,'0'} or errors:
        value.update({'log_tail':log.read_text(errors='replace')[-650:] if log.exists() else '',
            'launcher':launchlog.read_text(errors='replace')[-650:] if launchlog.exists() else ''})
    print(json.dumps(value))
'''
def one(replica):
    script='stage='+repr(a.stage)+'\nworkers='+repr([w for w in a.workers if w.startswith(replica)])+'\nverbose='+repr(a.verbose)+'\n'+remote
    r=subprocess.run([sys.executable,'-X','utf8',str(transport),replica],input=script.encode(),capture_output=True,timeout=110)
    return r.stdout.decode() if r.returncode==0 else r.stderr.decode()
with ThreadPoolExecutor(max_workers=2) as pool:
    for result in pool.map(one,sorted({w[0] for w in a.workers})): print(result,flush=True)
