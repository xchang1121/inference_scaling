from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import base64
import hashlib
import json
import subprocess
import sys

base=Path(__file__).resolve().parent
old=base.parent/'online_injection_scaling_20261109'
repo=base.parent/'online_injection_20261109/source'
head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
paths=['src','settings','pyproject.toml','scripts/benchmark_is_gpu.py','scripts/benchmark_flare_gap.py',
       'scripts/benchmark_retrieval_scaling.py','scripts/benchmark_grounded_retrieval.py',
       'tests/test_grounded_retrieval.py','docs/reports/GROUNDED_RETRIEVAL_PROTOCOL.md']
source=subprocess.check_output(['git','-C',str(repo),'archive','--format=tar.gz','HEAD',*paths])
(base/'source-frozen.tgz').write_bytes(source)
settings=json.loads((old/'settings-a3.json').read_text(encoding='utf-8'))
settings['run']['seed']=20261110
# Cache output is per worker; model path and all generation settings are unchanged.
settings['run']['hash_cache_dir']='/results/cache/model-hashes'
(base/'settings.json').write_text(json.dumps(settings,indent=2)+'\n',encoding='utf-8')
files={'source-frozen.tgz':source,'settings.json':(base/'settings.json').read_bytes(),
    'unrelated-prose.txt':(old/'unrelated-prose.txt').read_bytes(),
    **{'data/'+n:(base/'data'/n).read_bytes() for n in ['questions.jsonl','smoke-questions.jsonl']}}
corpus=base.parent/'online_injection_20261109/data/techqa/corpus.jsonl'
payload={'head':head,'files':{n:base64.b64encode(b).decode() for n,b in files.items()},
    'hashes':{n:hashlib.sha256(b).hexdigest() for n,b in files.items()},'corpus_hash':hashlib.sha256(corpus.read_bytes()).hexdigest()}
env='''#!/usr/bin/env bash
set -e
export USER=changxiangyu LOGNAME=changxiangyu
export HF_HOME=/cache/huggingface XDG_CACHE_HOME=/results/cache
export TORCHINDUCTOR_CACHE_DIR=/results/cache/torchinductor TRITON_CACHE_DIR=/results/cache/triton
export ASCEND_PROCESS_LOG_PATH=/results/cache/ascend-log
source /usr/local/Ascend/ascend-toolkit/set_env.sh
source /usr/local/Ascend/cann-9.1.0/share/info/ascendnpu-ir/bin/set_env.sh
source /usr/local/Ascend/nnal/atb/set_env.sh --cxx_abi=1
export PYTHONPATH="/deployment/online-injection-grounded-is-20261110/source/src:/deployment/online-injection-grounded-is-20261110/source/scripts:${PYTHONPATH:-}"
exec "$@"
'''
remote=r'''
from pathlib import Path
import base64,hashlib,io,json,shutil,subprocess,tarfile,time
root=Path('/data/disk/changxiangyu/agentic_scaling');name='online-injection-grounded-is-20261110'
dep=root/'deployment/ascend'/name
assert (dep/'RUNTIME-READY.json').exists()
if (dep/'SOURCE-FROZEN.json').exists():
    attempt=len(list(dep.glob('SOURCE-FROZEN-before-env-fix*.json')))+1
    prior=json.loads((dep/'SOURCE-FROZEN.json').read_text())
    assert prior['source_commit']==payload['head']
    assert not any((root/'results').glob(name+'-*/prepared-formal.json'))
    (dep/'SOURCE-FROZEN.json').rename(dep/f'SOURCE-FROZEN-before-env-fix-{attempt}.json')
    (dep/'env.sh').rename(dep/f'env-before-fix-{attempt}.sh')
    for oldlog in (root/'results').glob(name+'-*/prepare-formal.log'):
        oldlog.rename(oldlog.with_name(f'prepare-formal-env-error-{attempt}.log'))
for n,b64 in payload['files'].items():
    data=base64.b64decode(b64);assert hashlib.sha256(data).hexdigest()==payload['hashes'][n]
    p=dep/n;p.parent.mkdir(exist_ok=True,parents=True);p.write_bytes(data)
with tarfile.open(dep/'source-frozen.tgz') as tar:
    tar.extractall(dep/'source',filter='data')
corpora=[]
for folder in ['online-injection-flare-gap-20261109-a3','online-injection-scaling-20261109-a3','online-injection-20261109']:
    for relative in ['data/corpus.jsonl','data/techqa/corpus.jsonl']:
        p=root/'deployment/ascend'/folder/relative
        if p.is_file(): corpora.append(p)
src=next((p for p in corpora if hashlib.sha256(p.read_bytes()).hexdigest()==payload['corpus_hash']),None)
assert src is not None,[(str(p),p.stat().st_size) for p in corpora]
shutil.copyfile(src,dep/'data/corpus.jsonl')
(dep/'env.sh').write_text(env)
frozen={'source_commit':payload['head'],'replica':replica,'created':time.time(),
    'hashes':{**payload['hashes'],'data/corpus.jsonl':payload['corpus_hash'],'env.sh':hashlib.sha256(env.encode()).hexdigest()},
    'source_files':{p.relative_to(dep).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (dep/'source').rglob('*') if p.is_file()}}
(dep/'SOURCE-FROZEN.json').write_text(json.dumps(frozen,indent=2)+'\n')
c='agentic-scaling-changxiangyu-grounded-is-'+('a3' if replica=='a' else 'b4')
out=root/('results/'+name+'-'+('a3' if replica=='a' else 'b4'))
for stage,question in [('formal','questions.jsonl'),('smoke','smoke-questions.jsonl')]:
    args=['docker','exec',c,'bash','/deployment/'+name+'/env.sh','python3',
        '/deployment/'+name+'/source/scripts/benchmark_grounded_retrieval.py',
        '--settings','/deployment/'+name+'/settings.json','--corpus','/deployment/'+name+'/data/corpus.jsonl',
        '--questions','/deployment/'+name+'/data/'+question,'--noise','/deployment/'+name+'/unrelated-prose.txt',
        '--prepared','/results/prepared-'+stage+'.json','--prepare-only']
    with (out/('prepare-'+stage+'.log')).open('wb') as log:
        r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=240)
    assert r.returncode==0,(out/('prepare-'+stage+'.log')).read_text()[-2500:]
    for dev in ([3] if replica=='a' else [5,6]):
        target=root/('results/'+name+'-'+replica+str(dev))/('prepared-'+stage+'.json')
        if target != out/target.name: shutil.copyfile(out/target.name,target)
print(json.dumps({'replica':replica,'source_commit':payload['head'],'prepared':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.glob('prepared-*.json')}}))
'''

def one(replica):
    script='payload='+repr(payload)+'\nenv='+repr(env)+'\nreplica='+repr(replica)+'\n'+remote
    p=base/f'deploy-{replica}-remote.py';p.write_text(script,encoding='utf-8')
    r=subprocess.run([sys.executable,'-X','utf8',str(old/'remote.py'),replica,'--timeout','540','--file',str(p)],capture_output=True,timeout=560)
    (base/f'deploy-{replica}.log').write_bytes(r.stdout+r.stderr)
    return {'replica':replica,'exit':r.returncode,'output':r.stdout.decode()[-3000:],'stderr':r.stderr.decode()[-3000:]}

with ThreadPoolExecutor(max_workers=2) as pool:
    for result in pool.map(one,['a','b']): print(json.dumps(result),flush=True)
