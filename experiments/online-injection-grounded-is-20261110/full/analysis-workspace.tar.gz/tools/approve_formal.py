"""Machine validation barrier; no new user permission is required."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import subprocess
import sys

base=Path(__file__).resolve().parent
report=json.loads((base/'reports-smoke/summary.json').read_text(encoding='utf-8'))
audit=json.loads((base/'reports-smoke/audit.json').read_text(encoding='utf-8'))
assert report['audit_passed'] and audit['passed'] and not audit['failed']
assert report['unique_execution']['conditions']==16
gates=[json.loads(x) for x in (base/'reports-smoke/unique-gates.jsonl').read_text(encoding='utf-8').splitlines()]
assert {g['question_id'] for g in gates if g['accepted']}=={'TRAIN_Q545','TRAIN_Q559'},'exercise accepted evidence on both native fixtures'
assert all(not g['error'] for g in gates),'resolve native evidence format failures before formal'
assert all(r['empty_answer']==0 and r['eos_inside_thinking']==0 for r in report['summary'])
v1=json.loads((base/'reports-smoke-v1/summary.json').read_text(encoding='utf-8'))
assert v1['audit_passed'] and v1['unique_execution']['conditions']==32
revision=json.loads((base/'generation-revision.json').read_text(encoding='utf-8'))
wa=json.loads((base/'weights-a.json').read_text(encoding='utf-8'))
wb=json.loads((base/'weights-b.json').read_text(encoding='utf-8'))
assert wa['files']==wb['files']
payload={'smoke_summary_sha256':hashlib.sha256((base/'reports-smoke/summary.json').read_bytes()).hexdigest(),
    'smoke_audit_sha256':hashlib.sha256((base/'reports-smoke/audit.json').read_bytes()).hexdigest(),
    'smoke_conditions':16,'smoke_audit_checks':audit['checks'],'weights_identical':True,
    'legacy_v1_smoke_conditions':32,'legacy_v1_smoke_sha256':hashlib.sha256((base/'reports-smoke-v1/summary.json').read_bytes()).hexdigest(),
    'weights_a_sha256':hashlib.sha256((base/'weights-a.json').read_bytes()).hexdigest(),
    'weights_b_sha256':hashlib.sha256((base/'weights-b.json').read_bytes()).hexdigest(),
    'generation_source_commit':revision['commit'],
    'prepared_formal_sha256':'0651b132ce0992a83cf5e903d9fea66eb15dd7f5f838f7ee91e142a530076972',
    'worker_plan':{'workers':['a0','a1'],'assignments':{w:[json.loads(x)['id'] for x in (base/'data/questions.jsonl').read_text().splitlines()][i::2] for i,w in enumerate(['a0','a1'])},
        'reason':'User requested host198 cards0/1; B4 repeatedly failed pinned-host allocation, including32bytes; leaveBstopped',
        'conditions':320,'seeds':[20261110,20261111]}}
remote=r'''
from pathlib import Path
import hashlib,json,time
root=Path('/data/disk/changxiangyu/agentic_scaling');name='online-injection-grounded-is-20261110';dep=root/'deployment/ascend'/name
assert not (dep/'FORMAL-APPROVED.json').exists()
frozen=json.loads((dep/'SOURCE-FROZEN.json').read_text());assert frozen['source_commit']==payload['generation_source_commit']
for worker in workers:
    out=root/('results/'+name+'-'+worker)
    assert (out/'smoke.exit').read_text().strip()=='0'
    assert hashlib.sha256((out/'prepared-formal.json').read_bytes()).hexdigest()==payload['prepared_formal_sha256']
    assert not (out/'formal.jsonl').exists()
value={**payload,'validated_at':time.time(),'workers':workers}
(dep/'FORMAL-WORKER-PLAN.json').write_text(json.dumps(payload['worker_plan'],indent=2)+'\n')
(dep/'FORMAL-APPROVED.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value))
'''
def one(replica):
    script='payload='+repr(payload)+'\nworkers='+repr(['a0','a1'] if replica=='a' else ['b4'])+'\n'+remote
    r=subprocess.run([sys.executable,'-X','utf8',str(base.parent/'online_injection_scaling_20261109/remote.py'),replica],input=script.encode(),capture_output=True,timeout=110)
    (base/f'formal-barrier-{replica}.json').write_bytes(r.stdout)
    return {'replica':replica,'exit':r.returncode,'output':r.stdout.decode(),'stderr':r.stderr.decode()}
with ThreadPoolExecutor(max_workers=2) as pool:
    for result in pool.map(one,['a']):print(json.dumps(result),flush=True)
