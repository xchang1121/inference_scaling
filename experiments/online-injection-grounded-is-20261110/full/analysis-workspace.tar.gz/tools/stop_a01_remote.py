from pathlib import Path
import subprocess,json,time
name='aps-p1v4-goalplus-p1v4_1011-server'
expected='bcc12a4a526f6753bba8758072a667cc66ef96534968fee67a1ab1cbf6a52e8e'
d=json.loads(subprocess.check_output(['docker','inspect',name],text=True))[0]
assert d['Id']==expected
assert {x['PathOnHost'] for x in d['HostConfig']['Devices']}=={'/dev/davinci0','/dev/davinci1','/dev/davinci_manager','/dev/devmm_svm','/dev/hisi_hdc'}
before=subprocess.check_output(['/usr/local/bin/npu-smi','info'],text=True)
result=subprocess.run(['docker','stop','--time','20',expected],text=True,capture_output=True,timeout=45)
assert result.returncode==0,result.stderr
after=json.loads(subprocess.check_output(['docker','inspect',expected],text=True))[0]
assert not after['State']['Running']
inventory=subprocess.check_output(['/usr/local/bin/npu-smi','info'],text=True)
value={'time':time.time(),'authorization':'User explicitly requested stopping any tasks on host198 physical cards0 and1',
 'container':name,'id':expected,'before':before,'state_after':after['State'],'inventory_after':inventory,
 'card0_idle':'No running processes found in NPU 0' in inventory,'card1_idle':'No running processes found in NPU 1' in inventory}
assert value['card0_idle'] and value['card1_idle']
path=Path('/data/disk/changxiangyu/agentic_scaling/deployment/ascend/online-injection-grounded-is-20261110/USER-STOP-A01.json')
assert not path.exists();path.write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value))
