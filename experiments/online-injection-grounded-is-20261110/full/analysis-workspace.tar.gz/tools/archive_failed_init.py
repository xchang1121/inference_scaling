"""Preserve a zero-measurement initialization failure before a same-source retry."""
from pathlib import Path
import argparse
import json
import subprocess
import sys

base=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('stage',choices=['smoke','formal']);p.add_argument('label');p.add_argument('--workers',nargs='+',required=True);a=p.parse_args()
assert a.label.replace('-','').isalnum()
remote=r'''
from pathlib import Path
import json,subprocess
root=Path('/data/disk/changxiangyu/agentic_scaling');name='online-injection-grounded-is-20261110';dep=root/'deployment/ascend'/name
out=root/('results/'+name+'-'+worker)
assert (out/(stage+'.exit')).read_text().strip()!='0'
rows=[json.loads(x) for x in (out/(stage+'.jsonl')).read_text().splitlines()]
assert not any(r['kind'] in {'execution_unit','measurement'} for r in rows)
state=json.loads(subprocess.check_output(['docker','inspect','agentic-scaling-changxiangyu-grounded-is-'+worker],text=True))[0]['State']
assert not state['Running']
archive=out/'attempts'/label;archive.mkdir(parents=True)
for path in list(out.glob(stage+'*')):
    assert path.is_file() and path.resolve().is_relative_to(out.resolve())
    path.rename(archive/path.name)
path=dep/(stage+'-launch-'+worker+'.py');path.rename(dep/(stage+'-launch-'+worker+'-'+label+'.py'))
print(json.dumps({'worker':worker,'archived':label,'measurement_count':0}))
'''
for worker in a.workers:
    assert worker in ['a0','a1','a3','b4','b5','b6','a6','a7']
    source=base/'snapshot'/a.stage/worker;dest=base/'snapshot'/a.label/worker
    assert source.is_dir() and not dest.exists()
    script='worker='+repr(worker)+'\nstage='+repr(a.stage)+'\nlabel='+repr(a.label)+'\n'+remote
    result=subprocess.run([sys.executable,'-X','utf8',str(base.parent/'online_injection_scaling_20261109/remote.py'),worker[0]],input=script.encode(),capture_output=True,timeout=110)
    assert result.returncode==0,result.stderr.decode()
    assert source.resolve().is_relative_to(base) and dest.resolve().is_relative_to(base)
    dest.parent.mkdir(parents=True,exist_ok=True);source.rename(dest)
    (base/(a.label+'-'+worker+'.json')).write_bytes(result.stdout)
    print(result.stdout.decode().strip())
