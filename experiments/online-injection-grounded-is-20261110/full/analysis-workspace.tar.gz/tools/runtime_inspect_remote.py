import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

names = subprocess.check_output(['docker','ps','-a','--filter','name=agentic-scaling-changxiangyu','--format','{{.Names}}'],text=True).split()
name = next((n for n in names if n.endswith('injection-scaling-a3')), None) or next(n for n in names if n.endswith('injection-b'))
x = json.loads(subprocess.check_output(['docker','inspect',name],text=True))[0]
runner = subprocess.check_output(['docker','cp',name+':/vllm-workspace/vllm-ascend/vllm_ascend/worker/model_runner_v1.py','-'])
with tarfile.open(fileobj=io.BytesIO(runner)) as tar:
    m = next(m for m in tar if m.isfile())
    data = tar.extractfile(m).read()
mounts = x['Mounts']
out = {'name':name,'image':x['Image'],'user':x['Config']['User'],'mounts':mounts,'runner_sha256':hashlib.sha256(data).hexdigest(),'state':x['State'],'entrypoint':x['Config']['Entrypoint']}
for m in mounts:
    if m['Destination']=='/cache':
        p=Path(m['Source'])/'models/Qwen3.8-27B'
        out['model_realpath']=str(p.resolve())
        out['model_files']={q.name:{'size':q.stat().st_size,'symlink':q.is_symlink(),'sha256':hashlib.sha256(q.read_bytes()).hexdigest() if q.suffix=='.json' else None} for q in p.iterdir() if q.is_file()}
print(json.dumps(out,indent=2))
