"""Verify the existing registration; normalize only an accidental final escape."""
from pathlib import Path
import json
import subprocess
import sys

base = Path(__file__).resolve().parent
expected = json.loads((base/'adaptive-policy-preregistration.json').read_text(encoding='utf-8'))
script = 'expected='+repr(expected)+r'''
from pathlib import Path
import hashlib,json
root=Path('/data/disk/changxiangyu/agentic_scaling')
path=root/'deployment/ascend/online-injection-grounded-is-20261110/ADAPTIVE-POLICY-PREREGISTRATION.json'
data=path.read_bytes()
try:
    value=json.loads(data)
    changed=False
except json.JSONDecodeError:
    assert data.endswith(b'\\n')
    value=json.loads(data[:-2])
    assert value==expected
    backup=path.with_suffix('.literal-newline-original')
    if backup.exists():assert backup.read_bytes()==data
    else:backup.write_bytes(data)
    path.write_bytes(data[:-2]+b'\n')
    changed=True
assert value==expected
for record in value['records']:
    raw=(root/('results/online-injection-grounded-is-20261110-'+record['worker'])/'formal.jsonl').read_bytes()
    assert hashlib.sha256(raw[:record['prefix_bytes']]).hexdigest()==record['prefix_sha256']
print(json.dumps({'matches_local_registration':True,'native_prefixes_verified':True,
    'normalized_literal_final_newline':changed,'time_utc':value['time_utc'],
    'registration_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}))
'''
result = subprocess.run([sys.executable, '-X', 'utf8', str(base.parent/'online_injection_scaling_20261109/remote.py'), 'a'],
    input=script.encode(), capture_output=True, timeout=110)
assert result.returncode == 0, result.stderr.decode()
receipt = json.loads(result.stdout)
(base/'adaptive-registration-verification.json').write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')
print(json.dumps(receipt))
