"""Use newly idle A6/A7 in separate containers; leave the old pair untouched."""
from pathlib import Path
import json
import subprocess
import sys

base=Path(__file__).resolve().parent
remote=r'''
from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
root=Path('/data/disk/changxiangyu/agentic_scaling');name='online-injection-grounded-is-20261110';dep=root/'deployment/ascend'/name
old=json.loads(subprocess.check_output(['docker','inspect','agentic-scaling-changxiangyu-grounded-is-a3'],text=True))[0]
pair=subprocess.check_output(['docker','top','agentic-scaling-changxiangyu-ascend-pair','-eo','pid,comm,etime'],text=True)
assert len(pair.strip().splitlines())==2 and 'sleep' in pair
before=subprocess.check_output(['/usr/local/bin/npu-smi','info'],text=True)
records=[]
for device in [6,7]:
    assert f'No running processes found in NPU {device}' in subprocess.check_output(['/usr/local/bin/npu-smi','info'],text=True)
    worker='a'+str(device);c='agentic-scaling-changxiangyu-grounded-is-'+worker
    out=root/('results/'+name+'-'+worker);out.mkdir();(out/'cache').mkdir()
    command=['docker','create','--name',c,'--user',old['Config']['User'],'--group-add','1001','--shm-size','34359738368',
        '--label','inference_scaling.owner=changxiangyu','--label','inference_scaling.task='+name,
        '-e','OMP_NUM_THREADS=4','-e','VLLM_WORKER_MULTIPROC_METHOD=spawn']
    for device_path in [f'/dev/davinci{device}','/dev/davinci_manager','/dev/devmm_svm','/dev/hisi_hdc']:command+=['--device',device_path+':'+device_path]
    for mount in old['Mounts']:
        source=str(out) if mount['Destination']=='/results' else mount['Source']
        command+=['--mount','type=bind,source='+source+',target='+mount['Destination']+('' if mount['RW'] else ',readonly')]
    command += [old['Image'],'sleep','infinity']
    subprocess.run(command,check=True,capture_output=True)
    subprocess.run(['docker','start',c],check=True,capture_output=True)
    uid,gid=map(int,old['Config']['User'].split(':'))
    code='from pathlib import Path; import os\nfor value in ["/ascend","/.config"]:\n p=Path(value);p.mkdir(exist_ok=True);os.chown(p,'+str(uid)+','+str(gid)+')'
    subprocess.run(['docker','exec','--user','0:0',c,'python3','-c',code],check=True,capture_output=True)
    code="import importlib.metadata as m,json,platform;print(json.dumps({'python':platform.python_version(),'packages':{p:m.version(p) for p in ['vllm','vllm-ascend','torch','torch-npu','transformers','tokenizers']}}))"
    versions=json.loads(subprocess.check_output(['docker','exec',c,'python3','-c',code],text=True))
    assert versions['packages']=={'vllm':'0.23.0+empty','vllm-ascend':'0.23.0','torch':'2.10.0+cpu','torch-npu':'2.10.0.post4','transformers':'5.5.4','tokenizers':'0.22.2'}
    subprocess.run(['docker','stop',c],check=True,capture_output=True,timeout=45)
    for stage in ['smoke','formal']:
        shutil.copyfile(root/('results/'+name+'-a3')/('prepared-'+stage+'.json'),out/('prepared-'+stage+'.json'))
    records.append({'worker':worker,'container':c,'versions':versions,'image':old['Image'],'prepared':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.glob('prepared-*.json')}})
value={'created':time.time(),'reason':'A6/A7 now have no accelerator processes; old pair contains only sleep; B5 became occupied externally',
       'old_pair_unchanged':True,'old_pair_processes':pair,'inventory_before':before,'workers':records}
(dep/'ADDED-WORKERS.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value))
'''
result=subprocess.run([sys.executable,'-X','utf8',str(base.parent/'online_injection_scaling_20261109/remote.py'),'a','--timeout','180'],input=remote.encode(),capture_output=True,timeout=200)
assert result.returncode==0,result.stderr.decode()
(base/'added-workers.json').write_bytes(result.stdout)
value=json.loads(result.stdout);value.pop('inventory_before');print(json.dumps(value))
