"""Repair only the four task containers' writable log/config directories."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import subprocess
import sys

base=Path(__file__).resolve().parent
old=base/'snapshot/smoke';dest=base/'snapshot/smoke-init-permission'
assert old.resolve().is_relative_to(base) and dest.resolve().is_relative_to(base)
assert old.is_dir() and not dest.exists()
old.rename(dest)
remote=r'''
from pathlib import Path
import json,subprocess
root=Path('/data/disk/changxiangyu/agentic_scaling');name='online-injection-grounded-is-20261110';dep=root/'deployment/ascend'/name
results=[]
for worker in workers:
    c='agentic-scaling-changxiangyu-grounded-is-'+worker;out=root/('results/'+name+'-'+worker)
    assert (out/'smoke.exit').read_text().strip()=='1'
    assert not any(json.loads(line)['kind']=='measurement' for line in (out/'smoke.jsonl').read_text().splitlines())
    d=json.loads(subprocess.check_output(['docker','inspect',c],text=True))[0]
    assert not d['State']['Running']
    uid,gid=map(int,d['Config']['User'].split(':'))
    subprocess.run(['docker','start',c],check=True,capture_output=True)
    code='from pathlib import Path; import os; uid='+str(uid)+'; gid='+str(gid)+'\nfor value in ["/ascend","/.config"]:\n p=Path(value);p.mkdir(exist_ok=True);os.chown(p,uid,gid)\nprint("created own writable log/config directories")'
    answer=subprocess.check_output(['docker','exec','--user','0:0',c,'python3','-c',code],text=True)
    subprocess.run(['docker','stop',c],check=True,capture_output=True,timeout=45)
    archive=out/'attempts/smoke-init-permission';archive.mkdir(parents=True)
    for p in list(out.glob('smoke*')):
        assert p.is_file() and p.resolve().is_relative_to(out.resolve())
        p.rename(archive/p.name)
    p=dep/('smoke-launch-'+worker+'.py');p.rename(dep/('smoke-launch-'+worker+'-init-permission.py'))
    results.append({'worker':worker,'action':answer.strip(),'no_measurements_in_initialization_failure':True})
print(json.dumps(results))
'''
def one(replica):
    script='workers='+repr(['a3'] if replica=='a' else ['b4','b5','b6'])+'\n'+remote
    r=subprocess.run([sys.executable,'-X','utf8',str(base.parent/'online_injection_scaling_20261109/remote.py'),replica,'--timeout','180'],input=script.encode(),capture_output=True,timeout=200)
    (base/f'fix-dirs-{replica}.log').write_bytes(r.stdout+r.stderr)
    return {'replica':replica,'exit':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()}
with ThreadPoolExecutor(max_workers=2) as pool:
    for result in pool.map(one,['a','b']):print(json.dumps(result),flush=True)
