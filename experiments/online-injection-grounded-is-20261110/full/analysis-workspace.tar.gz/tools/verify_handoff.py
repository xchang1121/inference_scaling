"""Verify every packaged byte and rebuild all measurements without model/network."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys

BASE=Path(__file__).resolve().parent
DEST=BASE.parent/'online_injection_20261109/source/experiments/online-injection-grounded-is-20261110'


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p=argparse.ArgumentParser();p.add_argument('--workdir',type=Path,required=True);a=p.parse_args()
    assert not a.workdir.exists(),'preserve previous verification'
    workspace=a.workdir.resolve()
    manifest=json.loads((DEST/'MANIFEST.json').read_text(encoding='utf-8'))
    for entry in manifest['files']:
        path=DEST/entry['path'];assert path.stat().st_size==entry['bytes'] and sha(path)==entry['sha256'],entry['path']
    result=subprocess.run([sys.executable,'-X','utf8',str(DEST/'unpack.py'),'--output',str(workspace)],capture_output=True,encoding='utf-8')
    assert result.returncode==0,result.stdout+result.stderr
    print(result.stdout)
    for worker in ['a0','a1']:
        folder=workspace/'snapshot/formal'/worker
        frozen=json.loads((folder/'protocol/SOURCE-FROZEN.json').read_text(encoding='utf-8'))
        for name,digest in frozen['source_files'].items():
            assert sha(workspace/'generation-source'/name.removeprefix('source/'))==digest,name
        for name,digest in frozen['hashes'].items():
            # Worker snapshots own frozen deployment names. On Windows a later
            # local worker-plan.json aliases WORKER-PLAN.json in global protocol.
            options=[folder/'protocol'/name,workspace/name,workspace/'protocol'/name]
            found=next((p for p in options if p.is_file()),None)
            if found:assert sha(found)==digest,name
            else:assert name=='data/corpus.jsonl',name
        frozen_run=json.loads((folder/'formal-frozen.json').read_text(encoding='utf-8'))
        assert sha(folder/'prepared-formal.json')==frozen_run['prepared_sha256']
    env={**os.environ,'PYTHONPATH':os.pathsep.join([str(workspace/'generation-source/src'),str(workspace/'analysis'),str(BASE.parent/'online_injection_20261109/devdeps')]),
         'PYTHONDONTWRITEBYTECODE':'1','PYTHONHASHSEED':'7'}
    checked=[]
    isolation=workspace/'rebuilt/data-isolation-audit.json'
    run=subprocess.run([sys.executable,'-X','utf8',str(workspace/'tools/verify_data_isolation.py'),'--data',str(workspace/'data'),'--output',str(isolation)],capture_output=True,encoding='utf-8')
    assert run.returncode==0,run.stdout+run.stderr
    assert sha(isolation)==sha(workspace/'protocol/data-isolation-audit.json')
    checked.append({'path':'protocol/data-isolation-audit.json','bytes':isolation.stat().st_size,'sha256':sha(isolation)})
    jobs=[('formal','snapshot/formal','generation-source','reports'),
          ('smoke','snapshot/smoke','generation-source','validation/smoke-v3'),
          ('smoke','snapshot/smoke-quote-v1','generation-source-smoke-v1','validation/smoke-v1'),
          ('smoke','snapshot/smoke-quote-v2','generation-source-smoke-v2','validation/smoke-v2')]
    for stage,snapshot,source,reference in jobs:
        output=workspace/'rebuilt'/reference
        current_env={**env,'PYTHONPATH':os.pathsep.join([str(workspace/source/'src'),str(workspace/'analysis'),str(BASE.parent/'online_injection_20261109/devdeps')])}
        commands=[
            [sys.executable,'-X','utf8',str(workspace/'analysis/summarize_grounded_retrieval.py'),'--snapshot',str(workspace/snapshot),'--stage',stage,'--gold',str(workspace/'data/gold.jsonl'),'--output',str(output)],
            [sys.executable,'-X','utf8',str(workspace/'analysis/export_grounded_retrieval.py'),'--snapshot',str(workspace/snapshot),'--stage',stage,'--output',str(output/'traces')],
            [sys.executable,'-X','utf8',str(workspace/'analysis/diagnose_grounded_retrieval.py'),'--snapshot',str(workspace/snapshot),'--stage',stage,'--gold',str(workspace/'data/gold.jsonl'),'--output',str(output)],
        ]
        if stage=='formal':
            commands.append([sys.executable,'-X','utf8',str(workspace/'analysis/evaluate_grounded_route.py'),'--snapshot',str(workspace/snapshot),'--graded',str(output/'graded.jsonl'),'--registration',str(workspace/'protocol/adaptive-policy-preregistration.json'),'--output',str(output)])
            commands.append([sys.executable,'-X','utf8',str(workspace/'analysis/validate_grounded_review.py'),'--notes',str(workspace/'reports/manual-case-notes.jsonl'),'--cases',str(output/'fixed-case-review.jsonl'),'--manifest',str(workspace/'data/manifest.json'),'--diagnostics',str(output/'evidence-diagnostics.json'),'--output',str(output/'manual-review-audit.json')])
            commands.append([sys.executable,'-X','utf8',str(workspace/'analysis/plot_grounded_retrieval.py'),'--summary',str(output/'summary.json'),'--output',str(output/'figures')])
        for command in commands:
            run=subprocess.run(command,env=current_env,cwd=workspace,capture_output=True,encoding='utf-8')
            assert run.returncode==0,run.stdout+run.stderr
            print(run.stdout[-1800:])
        files=['summary.json','audit.json','graded.jsonl','raw-stop-events.jsonl','summary.csv','REPORT.md',
               'evidence-diagnostics.json','evidence-conditions.jsonl','unique-gates.jsonl','fixed-case-review.jsonl','context-comparisons.jsonl','traces/manifest.json','traces/gate-events.jsonl']
        traces=json.loads((workspace/reference/'traces/manifest.json').read_text(encoding='utf-8'))
        files+=['traces/'+entry['path'] for entry in traces['files']]
        if stage=='formal':files+=['adaptive-summary.json','adaptive-graded.jsonl','ADAPTIVE.md','manual-review-audit.json','figures/grounded-retrieval-is.png','figures/grounded-retrieval-is.svg','figures/manifest.json']
        for name in files:
            assert sha(output/name)==sha(workspace/reference/name),(reference,name)
            checked.append({'path':reference+'/'+name,'bytes':(output/name).stat().st_size,'sha256':sha(output/name)})
    run=subprocess.run([sys.executable,'-X','utf8','-m','pytest',str(workspace/'analysis/validation-tests'),'-q','--tb=short'],
        env=env,cwd=workspace/'generation-source',capture_output=True,encoding='utf-8')
    assert run.returncode==0,run.stdout+run.stderr
    print(run.stdout)
    receipt={'offline_rebuild_byte_identical':True,'model_or_network_used':False,'generation_source_commit':manifest['generation_source_commit'],
        'archive':manifest['archive'],'archive_members_verified':len(manifest['members']),'cpu_tests':47,'files':checked}
    (BASE/'offline-verification.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps({'byte_identical_files':len(checked),'archive_members_verified':len(manifest['members']),'cpu_tests':47}))


if __name__=='__main__':main()
