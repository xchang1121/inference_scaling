"""Copy only the previously validated native runner/operators and A env to B."""
from pathlib import Path
import base64
import hashlib
import json
import subprocess
import sys

base=Path(__file__).resolve().parent
transport=base.parent/'online_injection_scaling_20261109/remote.py'
script=r'''
import base64,gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path
c='agentic-scaling-changxiangyu-injection-scaling-a3'
paths=['/vllm-workspace/vllm-ascend/vllm_ascend/worker/model_runner_v1.py','/vllm-workspace/vllm-ascend/vllm_ascend/_cann_ops_custom']
out={}
for path in paths:
 p=subprocess.run(['docker','cp',c+':'+path,'-'],capture_output=True)
 if p.returncode: out[path]={'error':p.stderr.decode()};continue
 data=gzip.compress(p.stdout)
 out[path]={'bytes':len(p.stdout),'gzip_sha256':hashlib.sha256(data).hexdigest(),'data':base64.b64encode(data).decode()}
out['env.sh']={'text':Path('/data/disk/changxiangyu/agentic_scaling/deployment/ascend/env.sh').read_text()}
print(json.dumps(out))
'''
(base/'fetch-runtime-remote.py').write_text(script,encoding='utf-8')
r=subprocess.run([sys.executable,'-X','utf8',str(transport),'a','--file',str(base/'fetch-runtime-remote.py'),'--timeout','180'],capture_output=True,timeout=200)
if r.returncode: raise RuntimeError(r.stderr.decode())
data=json.loads(r.stdout)
for i,(name,value) in enumerate(data.items()):
 if 'data' in value:
  blob=base64.b64decode(value.pop('data'))
  assert hashlib.sha256(blob).hexdigest()==value['gzip_sha256']
  path=base/f'runtime-{i}.tar.gz';path.write_bytes(blob);value['file']=path.name
 if 'text' in value: (base/'env-a.sh').write_text(value['text'],encoding='utf-8',newline='\n')
(base/'runtime-transfer.json').write_text(json.dumps(data,indent=2),encoding='utf-8')
print(json.dumps(data,indent=2))
