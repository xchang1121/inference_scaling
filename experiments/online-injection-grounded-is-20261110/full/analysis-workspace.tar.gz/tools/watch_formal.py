"""Bounded foreground monitoring of our two queues; no restarts or mutations."""
from pathlib import Path
import argparse
import json
import subprocess
import sys
import time

base = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--analyze-on-completion', action='store_true')
parser.add_argument('--hours', type=float, default=8)
args = parser.parse_args()
deadline = time.monotonic()+3600*args.hours
last, errors = None, 0
while time.monotonic() < deadline:
    result = subprocess.run([sys.executable, '-X', 'utf8', str(base/'monitor.py'), 'formal'],
        capture_output=True, encoding='utf-8', timeout=125)
    try:
        rows = [json.loads(line) for line in result.stdout.splitlines() if line.strip()]
        assert result.returncode == 0 and {row['worker'] for row in rows} == {'a0', 'a1'}
    except (ValueError, AssertionError):
        errors += 1
        print(json.dumps({'monitor_transport_error': errors, 'stdout': result.stdout[-600:], 'stderr': result.stderr[-600:]}), flush=True)
        if errors >= 3:
            raise RuntimeError('three monitor transport errors; inspect without restarting jobs')
        time.sleep(45)
        continue
    errors = 0
    fingerprint = json.dumps(rows, sort_keys=True)
    if fingerprint != last:
        print(json.dumps({'time_utc': time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime()),
            'completed_conditions': sum(row['counts'].get('measurement', 0) for row in rows), 'workers': rows}), flush=True)
        last = fingerprint
    if any(row['failed'] or row['exit'] not in {None, '0'} for row in rows):
        raise RuntimeError('a native queue failed; preserve it for diagnosis')
    if all(row['exit'] == '0' for row in rows):
        assert all(row['counts'].get('measurement') == 160 for row in rows)
        if args.analyze_on_completion:
            subprocess.run([sys.executable, '-X', 'utf8', str(base/'analyze_completed.py')], check=True)
        break
    time.sleep(45)
else:
    raise TimeoutError('monitor deadline reached; native jobs were left untouched')
