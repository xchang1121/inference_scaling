"""Archive the completed v1 smoke and freeze the pre-formal quote correction."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import base64
import hashlib
import json
import subprocess
import sys

base = Path(__file__).resolve().parent
repo = base.parent / 'online_injection_20261109/source'
assert not subprocess.check_output(['git', '-C', str(repo), 'status', '--porcelain'], text=True).strip()
v1 = json.loads((base / 'reports-smoke-v1/summary.json').read_text())
assert v1['audit_passed'] and v1['unique_execution']['conditions'] == 32
head = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip()
paths = ['src', 'settings', 'pyproject.toml', 'scripts/benchmark_is_gpu.py', 'scripts/benchmark_flare_gap.py',
         'scripts/benchmark_retrieval_scaling.py', 'scripts/benchmark_grounded_retrieval.py',
         'tests/test_grounded_retrieval.py', 'docs/reports/GROUNDED_RETRIEVAL_PROTOCOL.md']
blob = subprocess.check_output(['git', '-C', str(repo), 'archive', '--format=tar.gz', 'HEAD', *paths])
payload = {'commit': head, 'data': base64.b64encode(blob).decode(), 'sha256': hashlib.sha256(blob).hexdigest()}
remote = r'''
from pathlib import Path
import base64, hashlib, json, subprocess, tarfile, time
root=Path('/data/disk/changxiangyu/agentic_scaling'); name='online-injection-grounded-is-20261110'
dep=root/'deployment/ascend'/name
previous=json.loads((dep/'SOURCE-FROZEN.json').read_text())
assert previous['source_commit']=='aa10b87a2a55b4c14df8850bfe3b00a41824f7b3'
assert not (dep/'FORMAL-APPROVED.json').exists()
for worker in workers:
    out=root/('results/'+name+'-'+worker)
    assert (out/'smoke.exit').read_text().strip()=='0'
    assert not (out/'formal.jsonl').exists()
    state=json.loads(subprocess.check_output(['docker','inspect','agentic-scaling-changxiangyu-grounded-is-'+worker],text=True))[0]['State']
    assert not state['Running']
    rows=[json.loads(x) for x in (out/'smoke.jsonl').read_text().splitlines()]
    assert sum(x['kind']=='measurement' for x in rows)==8
    archive=out/'attempts/smoke-quote-v1'; archive.mkdir(parents=True)
    for path in list(out.glob('smoke*')):
        assert path.is_file() and path.resolve().is_relative_to(out.resolve())
        path.rename(archive/path.name)
    path=dep/('smoke-launch-'+worker+'.py')
    path.rename(dep/('smoke-launch-'+worker+'-quote-v1.py'))
for path in [dep/'source',dep/'source-frozen.tgz',dep/'SOURCE-FROZEN.json']:
    assert path.resolve().is_relative_to(dep.resolve())
    path.rename(path.with_name(path.name+'-quote-v1'))
data=base64.b64decode(payload['data']);assert hashlib.sha256(data).hexdigest()==payload['sha256']
(dep/'source-frozen.tgz').write_bytes(data)
with tarfile.open(dep/'source-frozen.tgz') as tar:tar.extractall(dep/'source',filter='data')
frozen={**previous,'source_commit':payload['commit'],'created':time.time(),'previous_source_commit':previous['source_commit'],
    'revision_reason':'TRAIN smoke copied long URL and truncated JSON; constrain quotes before formal execution',
    'hashes':{**previous['hashes'],'source-frozen.tgz':payload['sha256']},
    'source_files':{p.relative_to(dep).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (dep/'source').rglob('*') if p.is_file()}}
for name,digest in frozen['hashes'].items():assert hashlib.sha256((dep/name).read_bytes()).hexdigest()==digest,name
(dep/'SOURCE-FROZEN.json').write_text(json.dumps(frozen,indent=2)+'\n')
print(json.dumps({'replica':replica,'source_commit':payload['commit'],'workers':workers,'source_tar_sha256':payload['sha256']}))
'''

def one(replica):
    script='payload='+repr(payload)+'\nreplica='+repr(replica)+'\nworkers='+repr(['a3'] if replica=='a' else ['b4','b5','b6'])+'\n'+remote
    result=subprocess.run([sys.executable,'-X','utf8',str(base.parent/'online_injection_scaling_20261109/remote.py'),replica,
                           '--timeout','180'],input=script.encode(),capture_output=True,timeout=200)
    (base/f'deploy-revision-{replica}.log').write_bytes(result.stdout+result.stderr)
    assert result.returncode==0,result.stderr.decode()
    return json.loads(result.stdout)

with ThreadPoolExecutor(max_workers=2) as pool:
    receipts=list(pool.map(one,['a','b']))
for path,name in [(base/'snapshot/smoke','smoke-quote-v1'),(base/'source-frozen.tgz','source-frozen-v1.tgz')]:
    assert path.resolve().is_relative_to(base) and not path.with_name(name).exists()
    path.rename(path.with_name(name))
(base/'source-frozen.tgz').write_bytes(blob)
(base/'generation-revision.json').write_text(json.dumps({'commit':head,'tar_sha256':payload['sha256'],'receipts':receipts},indent=2)+'\n')
for receipt in receipts:print(json.dumps(receipt))
