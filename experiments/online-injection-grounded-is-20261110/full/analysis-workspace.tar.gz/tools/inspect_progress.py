"""Read complete written units for diagnostics; never grade or alter running jobs."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import subprocess
import sys

base=Path(__file__).resolve().parent
remote=r'''
from pathlib import Path
import json
root=Path('/data/disk/changxiangyu/agentic_scaling/results')
for worker in workers:
    p=root/('online-injection-grounded-is-20261110-'+worker)/'smoke.jsonl'
    if not p.exists():continue
    units=[]
    for line in p.read_text().splitlines():
        try:r=json.loads(line)
        except ValueError:continue
        if r['kind']!='execution_unit':continue
        d=r['detail'] or {};result=r['result']
        gates=[{k:e.get(k) for k in ['kind','raw','support','error','rollback_to','confirmed_offset']} for e in result['events'] if e['kind'] in ['grounded_evidence','anchored_gap']]
        if not r['unit_id'].endswith(':probe'):gates=[]
        units.append({'id':r['unit_id'],'seconds':round(r['seconds'],2),'work':result['work_tokens'],'evidence':result['evidence_tokens'],
            'empty':result['empty_answer'],'gates':gates,'verifier_count':len(d.get('verdicts',[])),
            'invalid_verifiers':sum(v['error'] is not None for v in d.get('verdicts',[])),
            'selected_verdict':d.get('selected_verdict')})
    print(json.dumps({'worker':worker,'units':units}))
'''
def one(replica):
    script='workers='+repr(['a0','a1'] if replica=='a' else ['b4'])+'\n'+remote
    r=subprocess.run([sys.executable,'-X','utf8',str(base.parent/'online_injection_scaling_20261109/remote.py'),replica],input=script.encode(),capture_output=True,timeout=110)
    return r.stdout.decode() if r.returncode==0 else r.stderr.decode()
with ThreadPoolExecutor(max_workers=2) as pool:
    for result in pool.map(one,['a','b']):print(result,flush=True)
