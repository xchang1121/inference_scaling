"""Verify completed workers, immutable source/runtime, and released devices."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import subprocess
import sys

base=Path(__file__).resolve().parent
remote=r'''
from pathlib import Path
import hashlib,io,json,subprocess,tarfile,time
root=Path('/data/disk/changxiangyu/agentic_scaling');name='online-injection-grounded-is-20261110';dep=root/'deployment/ascend'/name
frozen=json.loads((dep/'SOURCE-FROZEN.json').read_text())
changed=[n for n,h in {**frozen['hashes'],**frozen['source_files']}.items() if hashlib.sha256((dep/n).read_bytes()).hexdigest()!=h]
inventory=subprocess.check_output(['/usr/local/bin/npu-smi','info'],text=True)
results=[]
for worker in workers:
    out=root/('results/'+name+'-'+worker);c='agentic-scaling-changxiangyu-grounded-is-'+worker
    d=json.loads(subprocess.check_output(['docker','inspect',c],text=True))[0]
    assert (out/'formal.exit').read_text().strip()=='0' and not d['State']['Running']
    assert not d['State']['OOMKilled']
    devices=[x['PathOnHost'] for x in d['HostConfig']['Devices']]
    assert set(devices)=={f'/dev/davinci{worker[1:]}','/dev/davinci_manager','/dev/devmm_svm','/dev/hisi_hdc'}
    blob=subprocess.check_output(['docker','cp',c+':/vllm-workspace/vllm-ascend/vllm_ascend/worker/model_runner_v1.py','-'])
    with tarfile.open(fileobj=io.BytesIO(blob)) as tar:
        m=next(m for m in tar if m.isfile());runner_hash=hashlib.sha256(tar.extractfile(m).read()).hexdigest()
    assert runner_hash=='60b10f97333df49c4bb2a6b5673d13d2d3b964056564c50681984b16fd84d049'
    results.append({'worker':worker,'generation_exit':0,'stopped':True,'oom':False,'devices':devices,
        'runner_sha256':runner_hash,'idle_at_check':f'No running processes found in NPU {worker[1:]}' in inventory,
        'formal_finish':json.loads((out/'formal-finish.json').read_text())})
assert not changed,changed
for p in (dep/'data').iterdir():assert p.name in {'questions.jsonl','smoke-questions.jsonl','corpus.jsonl'}
inactive=[]
for worker in (['a3','a6','a7'] if replica=='a' else ['b4','b5','b6']):
    info=json.loads(subprocess.check_output(['docker','inspect','agentic-scaling-changxiangyu-grounded-is-'+worker],text=True))[0]
    assert not info['State']['Running']
    inactive.append({'worker':worker,'stopped':True,'state':info['State']})
value={'replica':replica,'time':time.time(),'changed_source_or_inputs':changed,'gold_runtime_files':False,'workers':results,'inactive_attempt_workers':inactive,
    'shared_main':subprocess.check_output(['git','-C',str(root/'inference_scaling'),'rev-parse','HEAD'],text=True).strip(),
    'inventory':inventory}
(dep/'POST-RELEASE.json').write_text(json.dumps(value,indent=2)+'\n')
lease=root/'runtime/grounded-is-a01-reservation.json'
if replica=='a' and lease.exists():
    previous=json.loads(lease.read_text());assert previous['task']==name
    lease.write_text(json.dumps({**previous,'status':'released','released_at':time.time()},indent=2)+'\n')
print(json.dumps(value))
'''
def one(replica):
    script='replica='+repr(replica)+'\nworkers='+repr(['a0','a1'] if replica=='a' else [])+'\n'+remote
    r=subprocess.run([sys.executable,'-X','utf8',str(base.parent/'online_injection_scaling_20261109/remote.py'),replica,'--timeout','120'],input=script.encode(),capture_output=True,timeout=140)
    if r.returncode:raise RuntimeError(r.stderr.decode())
    result=json.loads(r.stdout);(base/f'resource-release-{replica}.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    result.pop('inventory');return result
with ThreadPoolExecutor(max_workers=2) as pool:
    for result in pool.map(one,['a','b']):print(json.dumps(result),flush=True)
