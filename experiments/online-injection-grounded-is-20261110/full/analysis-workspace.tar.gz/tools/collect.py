"""Collect finished immutable worker outputs, including exact token vocabulary."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import argparse
import base64
import gzip
import hashlib
import json
import subprocess
import sys

base=Path(__file__).resolve().parent
transport=base.parent/'online_injection_scaling_20261109/remote.py'
p=argparse.ArgumentParser();p.add_argument('stage',choices=['smoke','formal']);p.add_argument('--workers',nargs='+',default=['a0','a1']);a=p.parse_args()
remote=r'''
from pathlib import Path
import base64,gzip,hashlib,json,subprocess
root=Path('/data/disk/changxiangyu/agentic_scaling');name='online-injection-grounded-is-20261110'
dep=root/'deployment/ascend'/name;out=root/('results/'+name+'-'+worker)
assert (out/(stage+'.exit')).exists(),'stage still running'
assert (out/(stage+'-finish.json')).exists() and (out/(stage+'-npu-after.txt')).stat().st_size>0,'launcher cleanup incomplete'
container='agentic-scaling-changxiangyu-grounded-is-'+worker
info=json.loads(subprocess.check_output(['docker','inspect',container],text=True))[0]
assert not info['State']['Running'],'own worker still running'
files={}
for p in out.iterdir():
    if p.is_file() and (p.name.startswith(stage) or p.name.startswith('prepared-') or p.name.startswith('prepare-')):
        files[p.name]=p.read_bytes()
for n in ['SOURCE-FROZEN.json','RUNTIME-READY.json','ADDED-WORKERS.json','MIGRATED-WORKERS.json','USER-STOP-A01.json','USER-STOP-A01-RETRY1.json','WORKER-PLAN.json','FORMAL-WORKER-PLAN.json','WEIGHT-VERIFICATION.json','FORMAL-APPROVED.json','ADAPTIVE-POLICY-PREREGISTRATION.json','env.sh']:
    if (dep/n).exists():files['protocol/'+n]=(dep/n).read_bytes()
for p in dep.glob('*before-env-fix*.json'):files['protocol/'+p.name]=p.read_bytes()
needed=set()
def visit(value,key=''):
    if isinstance(value,dict):
        for k,v in value.items():visit(v,k)
    elif isinstance(value,list):
        if key.endswith('ids') and all(type(t) is int for t in value):needed.update(value)
        else:
            for v in value:visit(v)
for n,data in files.copy().items():
    if n.startswith('prepared-') and n.endswith('.json'):visit(json.loads(data))
    elif n==stage+'.jsonl':
        for line in data.splitlines():visit(json.loads(line))
raw=(root/'runtime/models/Qwen3.8-27B/tokenizer.json').read_bytes();d=json.loads(raw)
vocab={str(v):k for k,v in d['model']['vocab'].items() if v in needed}
for t in d['added_tokens']:
    if t['id'] in needed:vocab[str(t['id'])]=t['content']
assert set(map(int,vocab))==needed
files['trace-tokenizer-subset.json']=json.dumps({'tokenizer_sha256':hashlib.sha256(raw).hexdigest(),
    'decoder':d['decoder'],'vocab':vocab,'special_ids':[x['id'] for x in d['added_tokens'] if x['special']]},ensure_ascii=False).encode()
payload={n:{'sha256':hashlib.sha256(v).hexdigest(),'data':base64.b64encode(v).decode()} for n,v in files.items()}
print(base64.b64encode(gzip.compress(json.dumps(payload).encode())).decode())
'''
def one(worker):
    script='stage='+repr(a.stage)+'\nworker='+repr(worker)+'\n'+remote
    r=subprocess.run([sys.executable,'-X','utf8',str(transport),worker[0],'--timeout','180'],input=script.encode(),capture_output=True,timeout=200)
    if r.returncode: return {'worker':worker,'error':r.stderr.decode()[-1500:]}
    payload=json.loads(gzip.decompress(base64.b64decode(r.stdout.strip())))
    dest=base/'snapshot'/a.stage/worker;dest.mkdir(parents=True,exist_ok=True)
    receipts=[]
    for name, value in payload.items():
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        data=base64.b64decode(value['data']);assert hashlib.sha256(data).hexdigest()==value['sha256']
        path=dest/name;path.parent.mkdir(parents=True,exist_ok=True)
        if path.exists(): assert path.read_bytes()==data,'never overwrite a different finished run'
        else:path.write_bytes(data)
        receipts.append({'path':name,'bytes':len(data),'sha256':value['sha256']})
    (dest/'collection.json').write_text(json.dumps(receipts,indent=2)+'\n',encoding='utf-8')
    return {'worker':worker,'files':len(receipts),'bytes':sum(x['bytes'] for x in receipts)}
with ThreadPoolExecutor(max_workers=4) as pool:
    for result in pool.map(one,a.workers):print(json.dumps(result),flush=True)
