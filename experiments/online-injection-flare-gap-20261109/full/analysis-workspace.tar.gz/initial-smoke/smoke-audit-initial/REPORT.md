# FLARE-gap step-boundary experiment

Completed conditions: 18/18. Structural audit failures: 0.

Work cap 1024 (all previews/checks included), answer cap 512, evidence cap 256. Token F1 is a generative overlap diagnostic, not official TechQA accuracy. One seed per question; cohort sizes are small.

## smoke

| Arm | n | F1 % | Injected | EOS in thinking | Empty | Immediate close | Work tokens | Aux tokens | Seconds |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| closed.none | 0 | — | 0 | 0 | 0 | 0 | — | — | — |
| static.relevant | 0 | — | 0 | 0 | 0 | 0 | — | — | — |
| static.unrelated | 0 | — | 0 | 0 | 0 | 0 | — | — | — |
| legacy_sc.relevant | 0 | — | 0 | 0 | 0 | 0 | — | — | — |
| legacy_sc.unrelated | 0 | — | 0 | 0 | 0 | 0 | — | — | — |
| step_sc.relevant | 0 | — | 0 | 0 | 0 | 0 | — | — | — |
| step_sc.unrelated | 0 | — | 0 | 0 | 0 | 0 | — | — | — |
| flare_gap.relevant | 0 | — | 0 | 0 | 0 | 0 | — | — | — |
| flare_gap.unrelated | 0 | — | 0 | 0 | 0 | 0 | — | — | — |
| flare_gap_rebuild.relevant | 0 | — | 0 | 0 | 0 | 0 | — | — | — |
| flare_gap_rebuild.unrelated | 0 | — | 0 | 0 | 0 | 0 | — | — | — |


## Accounting and limits

Unique executed units: 22; measured unit time 709.6s, native padded dense FLOP estimate 15.202 PFLOP. Warmup is separate. Model load, smoke, failed prep and container lifetime appear in provenance receipts.

Each condition's cost includes its full common stem plus cold branch prefill. Study totals deduplicate shared execution. A no-intervention real/noise pair reuses one result and is not an independent replicate. Unrelated bodies are substituted after the real-evidence support gate. Primary FLARE-gap appends after a complete assistant step. Its rebuild companion shares the same common stem/payload and moves references to the user region. Step SC also reconstructs the user region; legacy SC retains assistant-inline placement. Query, timing and gating still differ between trigger policies.

Source labels and wrappers stay identical in paired content controls. EOS, empty answers, capped outputs, parse failures and unsupported retrievals remain in the denominator. Bootstrap intervals do not cover sampling-seed variability or generalization beyond this small sample.
