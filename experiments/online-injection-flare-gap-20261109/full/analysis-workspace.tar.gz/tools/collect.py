"""Read-only progress and bounded full snapshot collection."""
from pathlib import Path
import argparse,base64,gzip,hashlib,json,subprocess,sys
base=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('stage',choices=['smoke','formal']);p.add_argument('--snapshot',action='store_true');a=p.parse_args()
script='stage='+repr(a.stage)+'\nsnapshot='+repr(a.snapshot)+r'''
from pathlib import Path
import base64,gzip,hashlib,json,subprocess,time
root=Path('/data/disk/changxiangyu/agentic_scaling');name='online-injection-flare-gap-20261109-a3';out=root/'results'/name;dep=root/'deployment/ascend'/name
p=out/(stage+'.jsonl');raw=p.read_bytes() if p.exists() else b'';lines=raw.splitlines();rows=[]
for line in lines:
 try:rows.append(json.loads(line))
 except ValueError:pass
measurements=[r for r in rows if r.get('kind')=='measurement'];units=[r for r in rows if r.get('kind')=='execution_unit'];code=(out/(stage+'.exit')).read_text().strip() if (out/(stage+'.exit')).exists() else None
last=rows[-1] if rows else {}
info={'time':time.time(),'stage':stage,'conditions':len(measurements),'units':len(units),'last':{k:last.get(k) for k in ['kind','question_id','policy','arm','unit_id','error']},'exit':code,'log_tail':(out/(stage+'.log')).read_text(errors='replace')[-1000:] if (out/(stage+'.log')).exists() else None,'launch_tail':(out/(stage+'-launch.log')).read_text(errors='replace')[-1000:] if (out/(stage+'-launch.log')).exists() else None}
if snapshot:
 files={}
 for name in ['prepared.json','prepared-smoke.json',stage+'.jsonl','runtime-versions.json','runtime-model_runner_v1.py']:
  if (out/name).exists():files['snapshot/'+name]=base64.b64encode((out/name).read_bytes()).decode()
 for p in out.iterdir():
  if p.is_file() and (p.suffix in ['.log','.exit'] or 'finish' in p.name):files['provenance/'+p.name]=base64.b64encode(p.read_bytes()).decode()
 for p in dep.iterdir():
  if p.is_file() and p.suffix in ['.json','.sh','.py']:files['provenance/'+p.name]=base64.b64encode(p.read_bytes()).decode()
 frozen=json.loads((dep/('SMOKE-FROZEN.json' if stage=='smoke' else 'FROZEN.json')).read_text())
 info['changed_files']=[n for n,h in frozen['source_files'].items() if hashlib.sha256((dep/n).read_bytes()).hexdigest()!=h]
 if code is not None:
  info['changed_inputs']=[n for n,h in frozen['hashes'].items() if hashlib.sha256((dep/n).read_bytes()).hexdigest()!=h]
  info['prepared_matches_frozen']=hashlib.sha256((out/frozen['prepared_file']).read_bytes()).hexdigest()==frozen['prepared_sha256']
  info['runtime_runner_matches_frozen']=hashlib.sha256((out/'runtime-model_runner_v1.py').read_bytes()).hexdigest()==frozen['runtime_model_runner_sha256']
  info['gold_deployment_files']=[p.name for p in (dep/'data').iterdir() if 'gold' in p.name.lower()]
 print(base64.b64encode(gzip.compress(json.dumps({'info':info,'files':files}).encode())).decode())
else:print(json.dumps(info))
'''
r=subprocess.run([sys.executable,'-X','utf8',str(base/'remote.py'),'a','--timeout','600'],input=script.encode(),capture_output=True,timeout=610)
if r.returncode:raise RuntimeError(r.stderr.decode(errors='replace'))
if a.snapshot:
 val=json.loads(gzip.decompress(base64.b64decode(r.stdout.strip())));receipts=[]
 for name,b64 in val['files'].items():
  rel=Path(name);assert not rel.is_absolute() and '..' not in rel.parts
  data=base64.b64decode(b64);dest=base/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
  receipts.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 info=val['info'];(base/'snapshot'/('state-'+a.stage+'.json')).write_text(json.dumps(info,indent=2)+'\n');(base/'snapshot'/('receipts-'+a.stage+'.json')).write_text(json.dumps(receipts,indent=2)+'\n')
else:info=json.loads(r.stdout)
print(json.dumps(info,ensure_ascii=False))
