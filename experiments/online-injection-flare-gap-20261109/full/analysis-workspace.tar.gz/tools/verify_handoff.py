from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys,tempfile
base=Path(__file__).resolve().parent;repo=base.parent/'online_injection_20261109/source';dest=repo/'experiments/online-injection-flare-gap-20261109'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--workdir',type=Path,required=True);a=p.parse_args();assert not a.workdir.exists(),'preserve prior verification';a.workdir.mkdir(parents=True)
 r=subprocess.run([sys.executable,str(dest/'unpack.py'),'--output',str(a.workdir/'workspace')],capture_output=True,text=True);print(r.stdout);assert r.returncode==0,r.stderr
 workspace=a.workdir/'workspace'
 frozen=json.loads((workspace/'protocol/FROZEN.json').read_text(encoding='utf-8'))
 for name,expected in frozen['source_files'].items():assert digest(workspace/'generation-source'/name.removeprefix('source/'))==expected,name
 for name,expected in frozen['hashes'].items():
  path=workspace/name if name.startswith('data/') else workspace/'protocol'/name
  if path.exists():assert digest(path)==expected,name
  else:assert name=='data/corpus.jsonl',name
 assert digest(workspace/'snapshot/prepared.json')==frozen['prepared_sha256']
 assert digest(workspace/'snapshot/runtime-model_runner_v1.py')==frozen['runtime_model_runner_sha256']
 env={**os.environ,'PYTHONPATH':str(workspace/'generation-source/src')+os.pathsep+str(base.parent/'online_injection_20261109/devdeps'),'PYTHONDONTWRITEBYTECODE':'1','PYTHONHASHSEED':'7'};output=workspace/'rebuilt'
 commands=[[sys.executable,str(dest/'analysis/summarize_flare_gap.py'),'--generation',str(workspace/'snapshot/formal.jsonl'),'--prepared',str(workspace/'snapshot/prepared.json'),'--gold',str(workspace/'data/gold.jsonl'),'--output',str(output)],
 [sys.executable,str(dest/'analysis/plot_flare_gap.py'),'--summary',str(output/'summary.json'),'--output',str(output/'figures')],
 [sys.executable,str(dest/'analysis/export_flare_gap_traces.py'),'--snapshot',str(workspace/'snapshot'),'--output',str(output/'traces')],
 [sys.executable,str(dest/'analysis/export_flare_gap_traces.py'),'--snapshot',str(workspace/'snapshot'),'--output',str(output/'accepted-traces'),'--selection','accepted']]
 for command in commands:
  r=subprocess.run(command,env=env,capture_output=True,text=True);assert r.returncode==0,r.stdout+r.stderr;print(r.stdout[-1600:])
 expected=['summary.json','graded.jsonl','audit.jsonl','pair-audit.jsonl','gate-events.jsonl','unit-audit.json','comparison.csv','REPORT.md','figures/comparison.png','figures/comparison.svg','traces/manifest.json','traces/DEV_Q120-all-11-conditions.txt','traces/DEV_Q156-all-11-conditions.txt']
 accepted_manifest=json.loads((dest/'reports/accepted-traces/manifest.json').read_text(encoding='utf-8'))
 expected+=['accepted-traces/manifest.json']+['accepted-traces/'+f['path'] for f in accepted_manifest['files']]
 checked=[]
 for name in expected:
  reference=dest/'reports'/name;rebuilt=output/name;assert digest(reference)==digest(rebuilt),name
  checked.append({'path':name,'bytes':rebuilt.stat().st_size,'sha256':digest(rebuilt)})
 result={'offline_rebuild_byte_identical':True,'model_or_network_used':False,'files':checked,'source_generation_commit':json.loads((workspace/'protocol/FROZEN.json').read_text())['source_commit']}
 (base/'offline-verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps({'offline_rebuild_byte_identical':True,'files':len(checked)}))
if __name__=='__main__':main()
