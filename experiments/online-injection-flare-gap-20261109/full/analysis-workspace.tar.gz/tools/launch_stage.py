"""Freeze and launch a stage; all prior attempts remain on the server."""
from pathlib import Path
import argparse,base64,hashlib,json,subprocess,sys
base=Path(__file__).resolve().parent;repo=base.parent/'online_injection_20261109/source'
p=argparse.ArgumentParser();p.add_argument('stage',choices=['smoke','formal']);p.add_argument('--deploy-source',action='store_true');a=p.parse_args()
head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
paths=['src','settings','pyproject.toml','scripts/benchmark_is_gpu.py','scripts/benchmark_flare_gap.py','scripts/summarize_flare_gap.py','scripts/plot_flare_gap.py','scripts/export_flare_gap_traces.py','tests/test_stepwise_injection.py','docs/reports/FLARE_GAP_PROTOCOL.md']
source=subprocess.check_output(['git','-C',str(repo),'archive','--format=tar.gz','HEAD',*paths])
if a.deploy_source:
 oldfreeze=json.loads((base/'provenance/SMOKE-FROZEN.json').read_text()) if (base/'provenance/SMOKE-FROZEN.json').exists() else {'source_commit':'prepare-initial-1'}
 (base/('source-frozen-'+oldfreeze['source_commit'][:12]+'.tgz')).write_bytes((base/'source-frozen.tgz').read_bytes())
 (base/'source-frozen.tgz').write_bytes(source)
payload={'head':head,'stage':a.stage,'deploy':a.deploy_source,'source':base64.b64encode(source).decode() if a.deploy_source else None,'source_sha':hashlib.sha256(source).hexdigest()}
script='payload='+repr(payload)+r'''
from pathlib import Path
import base64,hashlib,io,json,subprocess,tarfile,time
root=Path('/data/disk/changxiangyu/agentic_scaling');name='online-injection-flare-gap-20261109-a3';dep=root/'deployment/ascend'/name;out=root/'results'/name;c='agentic-scaling-changxiangyu-injection-flare-gap-a3';stage=payload['stage']
assert (out/'prepare.exit').read_text().strip()=='0'
assert not (out/(stage+'.jsonl')).exists() and not (out/(stage+'.exit')).exists()
assert 'No running processes found in NPU 3' in subprocess.check_output(['/usr/local/bin/npu-smi','info'],text=True)
if payload['deploy']:
 assert stage=='smoke'
 oldhead=json.loads((dep/'SMOKE-FROZEN-initial-1.json').read_text())['source_commit']
 previous_source=dep/('source-frozen-'+oldhead[:12]+'.tgz');assert not previous_source.exists();(dep/'source-frozen.tgz').rename(previous_source)
 data=base64.b64decode(payload['source']);assert hashlib.sha256(data).hexdigest()==payload['source_sha'];(dep/'source-frozen.tgz').write_bytes(data)
 with tarfile.open(fileobj=io.BytesIO(data)) as tar:
  for m in tar:
   assert not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
   if m.isfile():
    dest=dep/'source'/m.name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(tar.extractfile(m).read())
   elif not m.isdir():raise RuntimeError('unexpected source archive member')
assert hashlib.sha256((dep/'source-frozen.tgz').read_bytes()).hexdigest()==payload['source_sha']
initial=json.loads((dep/'PREPARE-PROTOCOL.json').read_text())
frozen={**initial,'source_commit':payload['head'],'stage':stage,'frozen_time':time.time(),'source_files':{p.relative_to(dep).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (dep/'source').rglob('*') if p.is_file() and '__pycache__' not in p.parts},'hashes':{**initial['hashes'],'source-frozen.tgz':payload['source_sha']}}
prepared='prepared-smoke.json' if stage=='smoke' else 'prepared.json'
frozen['prepared_sha256']=hashlib.sha256((out/prepared).read_bytes()).hexdigest();frozen['prepared_file']=prepared
if stage=='formal':
 assert (out/'smoke.exit').read_text().strip()=='0'
 prev=json.loads((dep/'SMOKE-FROZEN.json').read_text());assert prev['source_commit']==payload['head']
 for n,h in prev['source_files'].items():assert hashlib.sha256((dep/n).read_bytes()).hexdigest()==h
frozenname='SMOKE-FROZEN.json' if stage=='smoke' else 'FROZEN.json'
(dep/frozenname).write_text(json.dumps(frozen,indent=2)+'\n')
start='#!/usr/bin/env bash\nset -eu\nexport PYTHONPATH="/deployment/'+name+'/source/src:/deployment/'+name+'/source/scripts:${PYTHONPATH:-}"\nexec python3 /deployment/'+name+'/source/scripts/benchmark_flare_gap.py --settings /deployment/'+name+'/settings-a3.json --prepared /results/'+prepared+' --corpus /deployment/'+name+'/data/corpus.jsonl --output /results/'+stage+'.jsonl'+(' --policies flare_gap --checker-contract-probe' if stage=='smoke' else '')+'\n'
(dep/(stage+'-start.sh')).write_text(start)
launch="stage="+repr(stage)+"\n"+r"""
from pathlib import Path
import hashlib,json,subprocess,time
root=Path('/data/disk/changxiangyu/agentic_scaling');name='online-injection-flare-gap-20261109-a3';dep=root/'deployment/ascend'/name;out=root/'results'/name;c='agentic-scaling-changxiangyu-injection-flare-gap-a3'
status=1;started=time.time()
try:
 frozen=json.loads((dep/('SMOKE-FROZEN.json' if stage=='smoke' else 'FROZEN.json')).read_text())
 for n,h in frozen['source_files'].items():assert hashlib.sha256((dep/n).read_bytes()).hexdigest()==h,n
 for n,h in frozen['hashes'].items():assert hashlib.sha256((dep/n).read_bytes()).hexdigest()==h,n
 assert hashlib.sha256((out/frozen['prepared_file']).read_bytes()).hexdigest()==frozen['prepared_sha256']
 assert 'No running processes found in NPU 3' in subprocess.check_output(['/usr/local/bin/npu-smi','info'],text=True)
 subprocess.run(['docker','start',c],check=True,capture_output=True)
 if not (out/'runtime-versions.json').exists():
  code="import importlib.metadata as m,json,platform;print(json.dumps({'python':platform.python_version(),'packages':{p:m.version(p) for p in ['vllm','vllm-ascend','torch','torch-npu','transformers','tokenizers']}}))"
  version=subprocess.check_output(['docker','exec',c,'bash','/deployment/env.sh','python3','-c',code]);(out/'runtime-versions.json').write_bytes(version)
 with (out/(stage+'.log')).open('wb') as log:
  result=subprocess.run(['docker','exec',c,'bash','/deployment/env.sh','bash','/deployment/'+name+'/'+stage+'-start.sh'],stdout=log,stderr=subprocess.STDOUT)
 status=result.returncode
finally:
 (out/(stage+'.exit')).write_text(str(status)+'\n')
 subprocess.run(['docker','stop',c],capture_output=True,text=True,timeout=45)
 d=json.loads(subprocess.check_output(['docker','inspect',c],text=True))[0]
 (out/(stage+'-container-finish.json')).write_text(json.dumps({'running':d['State']['Running'],'state':d['State'],'image':d['Image'],'started':started,'finished':time.time(),'generation_exit':status,'devices':d['HostConfig']['Devices']},indent=2)+'\n')
"""
(dep/(stage+'-launch.py')).write_text(launch)
with (out/(stage+'-launch.log')).open('wb') as log:proc=subprocess.Popen(['python3',str(dep/(stage+'-launch.py'))],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
print(json.dumps({'stage':stage,'pid':proc.pid,'source_commit':payload['head'],'prepared':prepared,'source_files':len(frozen['source_files']),'frozen':frozenname}))
'''
(base/(a.stage+'-launch-remote.py')).write_text(script,encoding='utf-8',newline='\n')
r=subprocess.run([sys.executable,'-X','utf8',str(base/'remote.py'),'a','--timeout','100','--file',str(base/(a.stage+'-launch-remote.py'))],capture_output=True,timeout=110)
(base/(a.stage+'-launch-result.txt')).write_bytes(r.stdout+r.stderr)
print(r.stdout.decode());print(r.stderr.decode());assert r.returncode==0
