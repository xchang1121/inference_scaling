#!/usr/bin/env bash
set -eu
export PYTHONPATH="/deployment/online-injection-flare-gap-20261109-a3/source/src:/deployment/online-injection-flare-gap-20261109-a3/source/scripts:${PYTHONPATH:-}"
exec python3 /deployment/online-injection-flare-gap-20261109-a3/source/scripts/benchmark_flare_gap.py --settings /deployment/online-injection-flare-gap-20261109-a3/settings-a3.json --prepared /results/prepared-smoke.json --corpus /deployment/online-injection-flare-gap-20261109-a3/data/corpus.jsonl --output /results/smoke.jsonl --policies flare_gap --checker-contract-probe
