#!/usr/bin/env bash
set -eu
export PYTHONPATH="/deployment/online-injection-flare-gap-20261109-a3/source/src:/deployment/online-injection-flare-gap-20261109-a3/source/scripts:${PYTHONPATH:-}"
python3 /deployment/online-injection-flare-gap-20261109-a3/source/scripts/benchmark_flare_gap.py --settings /deployment/online-injection-flare-gap-20261109-a3/settings-a3.json --prepared /results/prepared.json --data /deployment/online-injection-flare-gap-20261109-a3/data/techqa --noise /deployment/online-injection-flare-gap-20261109-a3/unrelated-prose.txt --prepare-only
python3 /deployment/online-injection-flare-gap-20261109-a3/source/scripts/benchmark_flare_gap.py --settings /deployment/online-injection-flare-gap-20261109-a3/settings-a3.json --prepared /results/prepared-smoke.json --data /deployment/online-injection-flare-gap-20261109-a3/data/techqa --noise /deployment/online-injection-flare-gap-20261109-a3/unrelated-prose.txt --prepare-only
