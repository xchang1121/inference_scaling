
from pathlib import Path
import fcntl,hashlib,json,subprocess,time
root=Path('/data/disk/changxiangyu/agentic_scaling');name='online-injection-literature-20261112'
dep=root/'deployment/ascend'/name;out=root/('results/'+name+'-a3')
c='agentic-scaling-changxiangyu-literature-a3';status=1
with (out/'job.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 try:
  assert (out/'smoke.exit').read_text().strip()=='0'
  assert not (out/'diagnostic.jsonl').exists() and not (out/'formal.jsonl').exists()
  frozen=json.loads((dep/'SOURCE-FROZEN.json').read_text())
  for n,h in frozen['hashes'].items():assert hashlib.sha256((dep/n).read_bytes()).hexdigest()==h,n
  assert 'No running processes found in NPU 3' in subprocess.check_output(['/usr/local/bin/npu-smi','info'],text=True)
  for n in subprocess.check_output(['docker','ps','--format','{{.Names}}'],text=True).split():
   x=json.loads(subprocess.check_output(['docker','inspect',n],text=True))[0]
   assert not any(d['PathOnHost']=='/dev/davinci3' for d in x['HostConfig']['Devices'] or []),n
  (out/'diagnostic-start.json').write_text(json.dumps({'started':time.time(),'source':frozen})+'\n')
  subprocess.run(['docker','start',c],check=True,capture_output=True)
  cmd=['docker','exec',c,'bash','/deployment/'+name+'/env.sh','python3','/deployment/'+name+'/diagnostics/native_diagnostic.py']
  with (out/'diagnostic.log').open('wb') as log:status=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT).returncode
 finally:
  subprocess.run(['docker','stop',c],capture_output=True,timeout=60)
  info=json.loads(subprocess.check_output(['docker','inspect',c],text=True))[0]
  (out/'diagnostic-finish.json').write_text(json.dumps({'finished':time.time(),'exit':status,'state':info['State']})+'\n')
  (out/'diagnostic.exit').write_text(str(status)+'\n')
