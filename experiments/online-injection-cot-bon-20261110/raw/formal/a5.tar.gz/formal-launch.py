worker='a5'
stage='formal'
cases=['DEV_Q213', 'DEV_Q221', 'DEV_Q048', 'DEV_Q154', 'DEV_Q141', 'DEV_Q025', 'DEV_Q296', 'DEV_Q218']
seeds=[20261112, 20261113]

from pathlib import Path
import fcntl,hashlib,json,subprocess,time
root=Path('/data/disk/changxiangyu/agentic_scaling');name='online-injection-cot-bon-20261110'
dep=root/'deployment/ascend'/name;out=root/('results/'+name+'-'+worker)
c='agentic-scaling-changxiangyu-cot-bon-'+worker
status=1
with (out/'job.lock').open('a') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    try:
        frozen=json.loads((dep/'SOURCE-FROZEN.json').read_text())
        for n,h in frozen['hashes'].items():assert hashlib.sha256((dep/n).read_bytes()).hexdigest()==h,n
        assert not (out/(stage+'.jsonl')).exists()
        if stage=='formal':assert (dep/'FORMAL-FROZEN.json').exists(),'smoke approval required'
        inventory=subprocess.check_output(['/usr/local/bin/npu-smi','info'],text=True)
        (out/(stage+'-npu-before.txt')).write_text(inventory)
        assert f'No running processes found in NPU {worker[1:]}' in inventory
        for n in subprocess.check_output(['docker','ps','--format','{{.Names}}'],text=True).split():
            x=json.loads(subprocess.check_output(['docker','inspect',n],text=True))[0]
            assert not any(d['PathOnHost']=='/dev/davinci'+worker[1:] for d in x['HostConfig']['Devices'] or []),n
        (out/(stage+'-start.json')).write_text(json.dumps({'worker':worker,'stage':stage,'cases':cases,'seeds':seeds,'started':time.time(),'source':frozen})+'\n')
        subprocess.run(['docker','start',c],check=True,capture_output=True)
        cmd=['docker','exec',c,'bash','/deployment/'+name+'/env.sh','python3','/deployment/'+name+'/source/scripts/benchmark_cot_guidance.py',
            '--settings','/deployment/'+name+'/settings.json','--prepared','/results/prepared-'+stage+'.json',
            '--corpus','/deployment/'+name+'/data/corpus.jsonl','--output','/results/'+stage+'.jsonl',
            '--case-ids',*cases,'--seeds',*map(str,seeds),'--worker',worker]
        with (out/(stage+'.log')).open('wb') as log:
            status=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT).returncode
    finally:
        subprocess.run(['docker','stop',c],capture_output=True,timeout=60)
        info=json.loads(subprocess.check_output(['docker','inspect',c],text=True))[0]
        (out/(stage+'-finish.json')).write_text(json.dumps({'exit':status,'finished':time.time(),'state':info['State']})+'\n')
        (out/(stage+'.exit')).write_text(str(status)+'\n')
