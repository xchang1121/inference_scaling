Historical A/B preflight with other GPU configurations and fictional API contracts. Excluded from every formal score and cost table.
