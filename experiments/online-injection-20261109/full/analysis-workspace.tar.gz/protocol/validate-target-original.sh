#!/usr/bin/env bash
set -eu
export PYTHONPATH="/deployment/online-injection-20261109-a3/git-source/src:/deployment/online-injection-20261109-a3/git-source/scripts:${PYTHONPATH:-}"
exec python3 /deployment/online-injection-20261109-a3/git-source/scripts/validate_injection_cache.py --settings /deployment/online-injection-20261109-a3/settings-a3.json --records /results/techqa.jsonl --output /results/target-cache-validation.json
