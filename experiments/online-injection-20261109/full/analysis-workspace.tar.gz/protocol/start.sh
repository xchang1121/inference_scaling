#!/usr/bin/env bash
set -eu
export PYTHONPATH="/deployment/online-injection-20261109-a3/source/src:/deployment/online-injection-20261109-a3/source/scripts:${PYTHONPATH:-}"
exec python3 /deployment/online-injection-20261109-a3/launch.py
