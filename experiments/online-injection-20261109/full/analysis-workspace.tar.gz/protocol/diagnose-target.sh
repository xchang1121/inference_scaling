#!/usr/bin/env bash
set -eu
export PYTHONPATH="/deployment/online-injection-20261109-a3/source/src:/deployment/online-injection-20261109-a3/analysis-scripts:${PYTHONPATH:-}"
exec python3 /deployment/online-injection-20261109-a3/analysis-scripts/diagnose_injection_cache.py --settings /deployment/online-injection-20261109-a3/settings-a3.json --validation /results/target-cache-validation.json --output /results/conditional-cache-diagnostic.json
