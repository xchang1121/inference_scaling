from pathlib import Path
import subprocess
root=Path('/data/disk/changxiangyu/agentic_scaling');dep=root/'deployment/ascend/online-injection-20261109-a3';out=root/'results/online-injection-20261109-a3';c='agentic-scaling-changxiangyu-injection-a3'
status=1
try:
 subprocess.run(['docker','start',c],check=True,capture_output=True)
 with (out/'conditional-cache-diagnostic.log').open('wb') as log:
  r=subprocess.run(['docker','exec',c,'bash','/deployment/env.sh','bash','/deployment/online-injection-20261109-a3/diagnose-target.sh'],stdout=log,stderr=subprocess.STDOUT,timeout=1200)
 status=r.returncode
finally:
 (out/'conditional-cache-diagnostic.exit').write_text(str(status)+'\n')
 subprocess.run(['docker','stop',c],capture_output=True,text=True,timeout=45)
