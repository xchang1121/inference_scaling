from pathlib import Path
import json,sys,traceback
if __name__ == '__main__':
 import benchmark_injection as bench
 from inference_scaling.app.settings import load_settings
 from inference_scaling.arllm.backends.loader import load_backend,close_backend
 root=Path('/deployment/online-injection-20261109-a3');out=Path('/results')
 raw=None;status=1
 try:
  s=load_settings(root/'settings-a3.json')
  raw=load_backend(s['ar']['model'],s['ar']['engine'],seed=20261109,logprobs=1)
  bench.load_backend=lambda *a,**k:raw
  bench.close_backend=lambda b:None
  (out/'engine-ready.json').write_text(json.dumps({'model_id':raw.model_id,'parameter_count':raw.parameter_count}))
  for dataset in ['techqa','api']:
   sys.argv=['benchmark_injection.py','--data',str(root/'data'/dataset),'--settings',str(root/'settings-a3.json'),'--output',str(out/(dataset+'.jsonl'))]
   try:bench.main()
   except BaseException:
    (out/(dataset+'.exit')).write_text('1\n');raise
   (out/(dataset+'.exit')).write_text('0\n')
  status=0
 except BaseException:
  traceback.print_exc();raise
 finally:
  try:close_backend(raw)
  except BaseException:
   status=1;raise
  finally:(out/'generation.exit').write_text(str(status)+'\n')
