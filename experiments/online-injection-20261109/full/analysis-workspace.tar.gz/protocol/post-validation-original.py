from pathlib import Path
import subprocess,json,time,hashlib,traceback
root=Path('/data/disk/changxiangyu/agentic_scaling');dep=root/'deployment/ascend/online-injection-20261109-a3';out=root/'results/online-injection-20261109-a3';c='agentic-scaling-changxiangyu-injection-a3'
try:
 while not (out/'generation.exit').exists():time.sleep(10)
 if (out/'generation.exit').read_text().strip()!='0':raise RuntimeError('Primary generation failed; validations not started')
 f=json.loads((dep/'FROZEN.json').read_text())
 for name,h in f['files'].items():
  if name.startswith('source/src/'):
   p=dep/'git-source'/name.removeprefix('source/')
   if hashlib.sha256(p.read_bytes()).hexdigest()!=h:raise RuntimeError('Validation core differs from frozen generation: '+name)
 for wait in range(120):
  info=subprocess.check_output(['/usr/local/bin/npu-smi','info'],text=True)
  if 'No running processes found in NPU 3' in info:break
  time.sleep(1)
 else:raise RuntimeError('Device3 not released after primary close; no other jobs stopped')
 with (out/'target-cache-validation.log').open('wb') as log:
  r=subprocess.run(['docker','exec',c,'bash','/deployment/env.sh','bash','/deployment/online-injection-20261109-a3/validate-target.sh'],stdout=log,stderr=subprocess.STDOUT,timeout=1200)
 (out/'target-cache-validation.exit').write_text(str(r.returncode)+'\n')
 with (out/'cpu-cache-reference.log').open('wb') as log:
  q=subprocess.run(['docker','exec',c,'bash','/deployment/env.sh','python3','-m','pytest','/deployment/online-injection-20261109-a3/git-source/tests/test_injection_kv_reference.py','-q'],stdout=log,stderr=subprocess.STDOUT,timeout=180)
 (out/'cpu-cache-reference.exit').write_text(str(q.returncode)+'\n')
 (out/'post-validation.exit').write_text(str(int(r.returncode!=0 or q.returncode!=0))+'\n')
finally:
 if (out/'generation.exit').exists() and (out/'generation.exit').read_text().strip()=='0':
  subprocess.run(['docker','stop',c],capture_output=True,text=True,timeout=45)
