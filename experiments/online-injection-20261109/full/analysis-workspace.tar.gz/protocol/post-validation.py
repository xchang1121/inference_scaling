"""Run the fixed cache checks against the exact frozen generation package."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

root = Path('/data/disk/changxiangyu/agentic_scaling')
dep = root/'deployment/ascend/online-injection-20261109-a3'
out = root/'results/online-injection-20261109-a3'
container = 'agentic-scaling-changxiangyu-injection-a3'

try:
    while not (out/'generation.exit').exists():
        time.sleep(10)
    if (out/'generation.exit').read_text().strip() != '0':
        raise RuntimeError('Primary generation failed; validations not started')
    frozen = json.loads((dep/'FROZEN.json').read_text())
    files = []
    for name, expected in frozen['files'].items():
        if name.startswith('source/src/'):
            original = (dep/name).read_bytes()
            checkout = (dep/'git-source'/name.removeprefix('source/')).read_bytes()
            assert hashlib.sha256(original).hexdigest() == expected, name
            equal = original.replace(b'\r\n', b'\n') == checkout.replace(b'\r\n', b'\n')
            assert equal, 'Validation core differs after newline normalization: '+name
            files.append({'path':name, 'frozen_sha256':expected,
                          'git_checkout_sha256':hashlib.sha256(checkout).hexdigest(),
                          'byte_equal':original == checkout, 'newline_normalized_equal':equal})
    (out/'validation-source-audit.json').write_text(json.dumps({
        'actual_import_source':'/deployment/online-injection-20261109-a3/source/src',
        'frozen_bytes_verified':True, 'checkout_text_verified':True, 'files':files}, indent=2)+'\n')
    for wait in range(120):
        info = subprocess.check_output(['/usr/local/bin/npu-smi', 'info'], text=True)
        if 'No running processes found in NPU 3' in info:
            break
        time.sleep(1)
    else:
        raise RuntimeError('Device3 not released after primary close; no other jobs stopped')
    with (out/'target-cache-validation.log').open('wb') as log:
        target = subprocess.run(['docker', 'exec', container, 'bash', '/deployment/env.sh',
                                 'bash', '/deployment/online-injection-20261109-a3/validate-target.sh'],
                                stdout=log, stderr=subprocess.STDOUT, timeout=1200)
    (out/'target-cache-validation.exit').write_text(str(target.returncode)+'\n')
    cpu_command = (
        'export PYTHONPATH="/deployment/online-injection-20261109-a3/source/src:${PYTHONPATH:-}"; '
        'exec python3 -m pytest /deployment/online-injection-20261109-a3/git-source/tests/test_injection_kv_reference.py -q')
    with (out/'cpu-cache-reference.log').open('wb') as log:
        cpu = subprocess.run(['docker', 'exec', container, 'bash', '/deployment/env.sh', 'bash', '-c', cpu_command],
                             stdout=log, stderr=subprocess.STDOUT, timeout=180)
    (out/'cpu-cache-reference.exit').write_text(str(cpu.returncode)+'\n')
    (out/'post-validation.exit').write_text(str(int(target.returncode != 0 or cpu.returncode != 0))+'\n')
except BaseException:
    if not (out/'post-validation.exit').exists():
        (out/'post-validation.exit').write_text('1\n')
    raise
finally:
    if (out/'generation.exit').exists() and (out/'generation.exit').read_text().strip() == '0':
        subprocess.run(['docker', 'stop', container], capture_output=True, text=True, timeout=45)
