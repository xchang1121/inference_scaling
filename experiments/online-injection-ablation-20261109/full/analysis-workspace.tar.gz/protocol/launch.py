from pathlib import Path
import hashlib,json,subprocess,time
root=Path('/data/disk/changxiangyu/agentic_scaling');dep=root/'deployment/ascend/online-injection-ablation-20261109-a3';out=root/'results/online-injection-ablation-20261109-a3';c='agentic-scaling-changxiangyu-injection-ablation-a3'
status=1
try:
 frozen=json.loads((dep/'FROZEN.json').read_text())
 for n,h in frozen['source_files'].items():assert hashlib.sha256((dep/n).read_bytes()).hexdigest()==h,n
 for n,h in frozen['hashes'].items():assert hashlib.sha256((dep/n).read_bytes()).hexdigest()==h,n
 assert hashlib.sha256((out/'prepared.json').read_bytes()).hexdigest()==frozen['prepared_sha256']
 assert 'No running processes found in NPU 3' in subprocess.check_output(['/usr/local/bin/npu-smi','info'],text=True)
 with (out/'generation.log').open('wb') as log:
  result=subprocess.run(['docker','exec',c,'bash','/deployment/env.sh','bash','/deployment/online-injection-ablation-20261109-a3/start.sh'],stdout=log,stderr=subprocess.STDOUT)
 status=result.returncode
finally:
 (out/'generation.exit').write_text(str(status)+chr(10))
 subprocess.run(['docker','stop',c],capture_output=True,text=True,timeout=45)
 d=json.loads(subprocess.check_output(['docker','inspect',c],text=True))[0]
 (out/'container-finish.json').write_text(json.dumps({'running':d['State']['Running'],'state':d['State'],'image':d['Image'],'time':time.time()},indent=2)+chr(10))
