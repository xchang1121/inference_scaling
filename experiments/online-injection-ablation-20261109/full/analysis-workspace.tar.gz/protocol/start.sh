#!/usr/bin/env bash
set -eu
export PYTHONPATH="/deployment/online-injection-ablation-20261109-a3/source/src:/deployment/online-injection-ablation-20261109-a3/source/scripts:${PYTHONPATH:-}"
exec python3 /deployment/online-injection-ablation-20261109-a3/source/scripts/benchmark_injection_ablation.py --settings /deployment/online-injection-ablation-20261109-a3/settings-a3.json --prepared /results/prepared.json --output /results/generation.jsonl --budgets 256 1024 4096
