#!/usr/bin/env bash
set -eu
export PYTHONPATH="/deployment/online-injection-ablation-20261109-a3/source/src:/deployment/online-injection-ablation-20261109-a3/source/scripts:${PYTHONPATH:-}"
exec python3 /deployment/online-injection-ablation-20261109-a3/source/scripts/benchmark_injection_ablation.py --settings /deployment/online-injection-ablation-20261109-a3/settings-a3.json --prepared /results/prepared.json --data /deployment/online-injection-ablation-20261109-a3/data/techqa --noise /deployment/online-injection-ablation-20261109-a3/unrelated-prose.txt --prepare-only
