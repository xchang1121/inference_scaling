from pathlib import Path
import subprocess
root=Path('/data/disk/changxiangyu/agentic_scaling');dep=root/'deployment/ascend/online-injection-ablation-20261109-a3';out=root/'results/online-injection-ablation-20261109-a3';c='agentic-scaling-changxiangyu-injection-ablation-a3'
status=1
try:
 subprocess.run(['docker','start',c],check=True,capture_output=True)
 with (out/'prepare.log').open('wb') as log:
  r=subprocess.run(['docker','exec',c,'bash','/deployment/env.sh','bash','/deployment/online-injection-ablation-20261109-a3/prepare.sh'],stdout=log,stderr=subprocess.STDOUT,timeout=300)
 status=r.returncode
finally:
 (out/'prepare.exit').write_text(str(status)+chr(10))
